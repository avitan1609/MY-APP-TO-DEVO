# SA · משמעת

> **גרסה להעלאה מיידית (מומלץ עכשיו):** התיקייה `site/` היא אתר סטטי מוכן — HTML, CSS ו־JS, בלי התקנות ובלי שלב בנייה. גוררים אותה ל־https://app.netlify.com/drop. הוראות מלאות: `site-UPLOAD-HE.txt`.
> הקוד שלה נמצא ב־`web/` ומשתמש באותה לוגיקה מ־`src/core`. בנייה מחדש: `node scripts/build-static.mjs` (דורש רק TypeScript).
> בגרסה הזו הנתונים נשמרים במכשיר (IndexedDB), עם ייצוא ושחזור גיבוי. גרסת React עם Supabase וסנכרון בין מכשירים נמצאת ב־`src/`.

מערכת אישית למשמעת עצמית, התמדה וניהול חיים: משימות, הרגלים, מטרות, תכנון יומי ושבועי, ציון יומי שקוף, סיכום סוף יום ונתונים. עברית מלאה ו־RTL, מצב כהה ובהיר, מחשב וטלפון, ועבודה ללא אינטרנט.

**סטטוס:** שלב 1 (MVP), גרסה 0.1.0. ללא AI וללא חיבורים לאפליקציות ספורט ובריאות. כל הנתונים מוזנים ידנית.

---

## טכנולוגיה

| שכבה | בחירה |
|---|---|
| Frontend | React 18, TypeScript, Vite 5 |
| עיצוב | Tailwind CSS 3, רכיבים נגישים בכתיבה עצמית, פונט Heebo מקומי |
| אחסון מקומי | IndexedDB באמצעות Dexie (local-first: כל פעולה נשמרת קודם במכשיר) |
| ענן ואימות | Supabase (PostgreSQL, Auth, RLS). אופציונלי: בלי הגדרה האפליקציה רצה במצב מקומי |
| גרפים | Recharts |
| PWA | vite-plugin-pwa (Workbox): התקנה למסך הבית ועבודה אופליין |
| פריסה | Netlify (ראה `netlify.toml`) |
| בדיקות | Vitest, Testing Library, fake-indexeddb, Playwright (e2e) |

כל השירותים בתוכנית החינמית. אין מפתחות API, אין שירותים בתשלום ואין תלות ב־AI.

## התקנה והרצה מקומית

דרישה: Node.js 20 ומעלה.

```bash
npm install
cp .env.example .env      # אפשר להשאיר ריק = מצב מקומי
npm run dev               # http://localhost:5173
```

### משתני סביבה

| משתנה | חובה | תיאור |
|---|---|---|
| `VITE_SUPABASE_URL` | לא | כתובת הפרויקט ב־Supabase. ריק = מצב מקומי בלבד |
| `VITE_SUPABASE_ANON_KEY` | לא | המפתח הציבורי (anon). בטוח לדפדפן, מוגן ב־RLS |
| `VITE_ENABLE_GOOGLE` | לא | `true` מציג כפתור התחברות עם Google (דורש הגדרה ב־Supabase) |

> **לעולם לא** לשים את מפתח ה־`service_role` במשתנה שמתחיל ב־`VITE_`, כי הוא ייחשף בדפדפן.

## חיבור Supabase (חינמי)

1. צור פרויקט ב־[supabase.com](https://supabase.com) בתוכנית Free.
2. ב־SQL Editor, הרץ את `supabase/migrations/0001_init.sql`.
3. **בדיקת אבטחה:** הרץ את `supabase/tests/rls_check.sql`. התוצאה הצפויה היא שורה אחת: `RLS OK`. הסקריפט עושה rollback, כך שלא נשאר בסיס הנתונים שום מידע מהבדיקה.
4. ב־Authentication ← URL Configuration, הגדר את Site URL ואת Redirect URLs לכתובת האתר, למשל `https://<site>.netlify.app` וגם `http://localhost:5173`.
5. העתק את Project URL ואת anon key אל `.env` (מקומית) או אל משתני הסביבה ב־Netlify.
6. **Google (אופציונלי):** הפעל את הספק Google ב־Authentication ← Providers, עם Client ID ו־Secret מ־Google Cloud Console. Redirect URI: `https://<project>.supabase.co/auth/v1/callback`. אחר כך הגדר `VITE_ENABLE_GOOGLE=true`.

**הערה:** פרויקט Free ב־Supabase מושהה אחרי 7 ימים ללא פעילות. בשימוש יומי זה לא קורה, ואם קרה, משחררים את ההשהיה בלחיצה בלוח הבקרה. הנתונים המקומיים לא נפגעים.

## העלאה ופריסה (GitHub ← Netlify)

**1. GitHub**
1. צור ריפו חדש ופרטי, למשל `sa-discipline`, **בלי** README.
2. העלה את כל תוכן התיקייה, כולל התיקייה הנסתרת `.github`:
   - **מהמחשב (מומלץ):** בתוך התיקייה הרץ `git init`, `git add -A`, `git commit -m "MVP"` ו־`git branch -M main`, ואחר כך `git remote add origin <כתובת הריפו>` ו־`git push -u origin main`.
   - **מהדפדפן:** Add file ← Upload files, וגרור את תוכן התיקייה. ודא שגם `.github` עלתה, כי במחשבי Mac היא מוסתרת (Cmd+Shift+. מציג אותה).
3. בלשונית **Actions** תופיע ריצה בשם CI. היא מתקינה את התלויות, מריצה בדיקת טיפוסים ובדיקות, בונה, ומריצה בדיקות דפדפן (RTL, נייד, ערכות נושא, אופליין). אם משהו נכשל, העתק את השגיאה ושלח לי.

**2. Netlify**
1. Add new site ← Import an existing project ← GitHub ← בחר את הריפו.
2. ההגדרות נקראות אוטומטית מ־`netlify.toml` (`npm run build`, תיקייה `dist`). לחץ Deploy.
3. אחרי 1–2 דקות תקבל כתובת כמו `https://<שם>.netlify.app`. כל push ל־main מעלה גרסה חדשה.
4. אם הבנייה נכשלה: Deploys ← הפריסה האחרונה ← העתק את סוף ה־log ושלח לי.

**3. Supabase (אופציונלי, לסנכרון בין מכשירים)**
בלי Supabase האפליקציה עובדת במצב מקומי, והנתונים נשמרים במכשיר. לחיבור, ראה את הסעיף "חיבור Supabase" למעלה. אחר כך הוסף ב־Netlify, תחת Site configuration ← Environment variables, את `VITE_SUPABASE_URL` ו־`VITE_SUPABASE_ANON_KEY`, והפעל Deploy מחדש.

**4. התקנה בטלפון**
פתח את הכתובת ב־Safari (iPhone) או ב־Chrome (Android), ובחר "הוסף למסך הבית". האפליקציה תיפתח במסך מלא ותעבוד גם בלי אינטרנט.

### בדיקה אחרי פריסה (2 דקות)
- [ ] מסך פתיחה עם הלוגו, ואז מסך התחברות או הגדרה ראשונית
- [ ] הוספת משימה, סימון כבוצעה, והציון עולה ל־100
- [ ] רענון הדף: המשימה נשארת
- [ ] מצב טיסה ורענון: האפליקציה נפתחת והמשימה שם
- [ ] הגדרות ← מראה: כהה ובהיר מתחלפים
- [ ] בטלפון: אין גלילה הצידה, הניווט התחתון עובד

`netlify.toml` כולל ניתוב SPA וכותרות אבטחה: CSP שמאפשר חיבור רק ל־Supabase, X-Frame-Options ו־Referrer-Policy.

## בדיקות

```bash
npm test            # Vitest: לוגיקה, שכבת נתונים, סנכרון, RTL, מיגרציה, רכיבים
npm run typecheck   # TypeScript strict
npm run test:e2e    # Playwright: RTL, רספונסיביות, ערכות נושא, אופליין (התקנה ראשונה: npx playwright install chromium)
```

| תחום | קובץ |
|---|---|
| נוסחת הציון | `src/core/__tests__/score.test.ts` |
| תדירויות ומשימות חוזרות | `src/core/__tests__/recurrence.test.ts` |
| תאריכים ואזורי זמן (כולל מעבר שעון בישראל) | `src/core/__tests__/dates.test.ts` |
| תכנון, עומס והעברות | `src/core/__tests__/planning.test.ts` |
| רצפים, דפוסים, סיכום יומי ומאמן | `src/core/__tests__/streaks-patterns.test.ts` |
| מטרות | `src/core/__tests__/goals.test.ts` |
| ולידציה, מיזוג סנכרון וגיבוי | `src/core/__tests__/validation-sync-backup.test.ts` |
| שמירה, סנכרון ומצב לא מקוון | `src/data/__tests__/repo-sync.test.ts` |
| הרשאות (סטטי) | `supabase/migration.test.ts` |
| הרשאות (חי, מול בסיס הנתונים) | `supabase/tests/rls_check.sql` |
| RTL | `src/ui/__tests__/rtl.test.ts` |
| רכיבים (smoke) | `src/ui/__tests__/app.test.tsx` |
| RTL, רספונסיביות ואופליין בדפדפן | `tests/e2e/app.spec.ts` |

## מבנה הפרויקט

```
src/
  core/      לוגיקה טהורה, ללא תלויות: ציון, תדירויות, תאריכים, תכנון, רצפים, דפוסים, ולידציה
  data/      IndexedDB (Dexie), ריפוזיטורי local-first, מנוע סנכרון, לקוח Supabase
  state/     Auth, הקשר אפליקציה (היום באזור הזמן של המשתמש, ערכת נושא, תזכורות), hooks חיים
  ui/        ערכת רכיבים, מעטפת וניווט, טופסי משימה, לוגו ואייקונים
  screens/   היום, שבוע, משימות, מטרות, נתונים, סיכום יום, הגדרות, התחברות
supabase/    מיגרציה (סכמה ו־RLS) ובדיקות הרשאות
docs/        ארכיטקטורה, ציון, אבטחה, הנחות ומגבלות
```

## מסמכים

- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md): ארכיטקטורה, מודל נתונים וסנכרון
- [docs/SCORING.md](docs/SCORING.md): הציון היומי, רצפים והעברות
- [docs/SECURITY.md](docs/SECURITY.md): אבטחה ופרטיות
- [docs/ASSUMPTIONS.md](docs/ASSUMPTIONS.md): הנחות שלא אושרו, מגבלות ידועות ומה עוד לא מומש
