#!/usr/bin/env node
/**
 * Builds the static site (no npm dependencies needed, only TypeScript's `tsc`).
 *   node scripts/build-static.mjs
 * Output: ./site — upload this folder as-is (Netlify Drop, GitHub Pages, any static host).
 */
import { execSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const web = join(root, 'web');
const out = join(web, '.out');
const site = join(root, 'site');

rmSync(out, { recursive: true, force: true });
rmSync(site, { recursive: true, force: true });

// 1) Compile TypeScript (app + shared core logic) to ES modules
execSync(`tsc -p "${join(web, 'tsconfig.json')}"`, { stdio: 'inherit', cwd: root });

// 2) Assemble the site
mkdirSync(site, { recursive: true });
cpSync(join(web, 'public'), site, { recursive: true });
mkdirSync(join(site, 'img'));
mkdirSync(join(site, 'icons'));
cpSync(join(root, 'public', 'logo-light.png'), join(site, 'img', 'logo-light.png'));
cpSync(join(root, 'public', 'logo-dark.png'), join(site, 'img', 'logo-dark.png'));
for (const f of ['icon-192.png', 'icon-512.png', 'icon-512-maskable.png', 'apple-touch-icon.png']) cpSync(join(root, 'public', f), join(site, 'icons', f));
cpSync(out, join(site, 'js'), { recursive: true });

const walk = (dir) => readdirSync(dir).flatMap((f) => (statSync(join(dir, f)).isDirectory() ? walk(join(dir, f)) : [join(dir, f)]));

// 3) Browsers need explicit ".js" on relative imports
for (const f of walk(join(site, 'js')).filter((f) => f.endsWith('.js'))) {
  const src = readFileSync(f, 'utf8').replace(/(from\s+|import\s*\(\s*|import\s+)(['"])(\.{1,2}\/[^'"]+?)(\2)/g, (m, kw, q, spec) =>
    spec.endsWith('.js') ? m : `${kw}${q}${spec}.js${q}`,
  );
  writeFileSync(f, src);
}

// 4) Version stamp + offline asset list
const files = walk(site).filter((f) => !f.endsWith('_headers') && !f.endsWith('sw.js'));
const hash = createHash('sha256');
for (const f of files.sort()) hash.update(relative(site, f)).update(readFileSync(f));
const version = hash.digest('hex').slice(0, 10);
const assets = ['./', ...files.map((f) => relative(site, f).split('\\').join('/'))];

for (const name of ['index.html', 'sw.js']) {
  const p = join(site, name);
  writeFileSync(p, readFileSync(p, 'utf8').replaceAll('__VERSION__', version).replace('__ASSETS__', JSON.stringify(assets)));
}
rmSync(out, { recursive: true, force: true });

const size = walk(site).reduce((a, f) => a + statSync(f).size, 0);
console.log(`site/ built — version ${version}, ${assets.length - 1} files, ${(size / 1024).toFixed(0)} KB`);
if (!existsSync(join(site, 'js', 'web', 'src', 'main.js'))) throw new Error('main.js missing');
