import { isISODate } from './dates.js';
export const BACKUP_FORMAT = 'sa-discipline-backup';
export const BACKUP_VERSION = 1;
export function makeBackup(data, now = new Date()) {
    return { format: BACKUP_FORMAT, version: BACKUP_VERSION, exportedAt: now.toISOString(), ...data };
}
const isObj = (x) => !!x && typeof x === 'object' && !Array.isArray(x);
const isStr = (x) => typeof x === 'string';
function rowsOk(arr, check) {
    return Array.isArray(arr) && arr.every((r) => isObj(r) && isStr(r.id) && isStr(r.updatedAt) && check(r));
}
export function parseBackup(text) {
    let data;
    try {
        data = JSON.parse(text);
    }
    catch {
        throw new Error('הקובץ אינו JSON תקין');
    }
    if (!isObj(data) || data.format !== BACKUP_FORMAT)
        throw new Error('זה לא קובץ גיבוי של האפליקציה');
    if (typeof data.version !== 'number' || data.version > BACKUP_VERSION)
        throw new Error('גרסת גיבוי לא נתמכת');
    const ok = rowsOk(data.categories, (r) => isStr(r.name)) &&
        rowsOk(data.goals, (r) => isStr(r.title)) &&
        rowsOk(data.tasks, (r) => isStr(r.title) && isStr(r.kind)) &&
        rowsOk(data.logs, (r) => isStr(r.taskId) && isISODate(r.date)) &&
        rowsOk(data.days, (r) => isISODate(r.date)) &&
        (data.settings === null || isObj(data.settings));
    if (!ok)
        throw new Error('מבנה הקובץ פגום — הייבוא בוטל');
    return data;
}
export function reownBackup(b, userId, now = new Date().toISOString()) {
    const re = (rows) => rows.map((r) => ({ ...r, userId, updatedAt: now }));
    return {
        categories: re(b.categories),
        goals: re(b.goals),
        tasks: re(b.tasks),
        logs: re(b.logs),
        days: re(b.days),
        settings: b.settings ? { ...b.settings, userId, id: 'settings', updatedAt: now } : null,
    };
}
