import { addDays, weekday } from './dates.js';
import { IMPORTANCE_RANK, dayLoad, isActiveOnDay } from './planning.js';
import { plannedItemsForDate } from './recurrence.js';
import { completionRatio, computeDailyScore, taskWeight } from './score.js';
export function scoreSeries(tasks, logs, dates, weights, snapshots) {
    const out = new Map();
    for (const d of dates) {
        if (snapshots?.has(d))
            out.set(d, snapshots.get(d));
        else
            out.set(d, computeDailyScore(plannedItemsForDate(tasks, logs, d), weights).score);
    }
    return out;
}
export function average(values) {
    const v = values.filter((x) => typeof x === 'number');
    return v.length ? Math.round((v.reduce((a, b) => a + b, 0) / v.length) * 10) / 10 : null;
}
export function averageOver(series, to, days, excludeTo = false) {
    const vals = [];
    for (let i = excludeTo ? 1 : 0; i < days + (excludeTo ? 1 : 0); i++)
        vals.push(series.get(addDays(to, -i)));
    return average(vals);
}
export function weekdayAverages(series) {
    const buckets = Array.from({ length: 7 }, () => []);
    for (const [d, s] of series)
        if (typeof s === 'number')
            buckets[weekday(d)].push(s);
    return buckets.map((b) => average(b));
}
export function categoryRates(tasks, logs, dates, weights) {
    const acc = new Map();
    for (const d of dates) {
        for (const item of plannedItemsForDate(tasks, logs, d)) {
            if (item.log?.status === 'not_relevant')
                continue;
            const w = taskWeight(item.task, weights);
            const a = acc.get(item.task.categoryId) ?? { w: 0, e: 0, n: 0 };
            a.w += w;
            a.e += w * completionRatio(item.task, item.log);
            a.n++;
            acc.set(item.task.categoryId, a);
        }
    }
    return [...acc.entries()]
        .map(([categoryId, a]) => ({ categoryId, planned: a.n, rate: a.w ? a.e / a.w : 0 }))
        .sort((a, b) => b.planned - a.planned);
}
export function frequentlyPostponed(logs, from, minMoves = 3) {
    const counts = new Map();
    for (const l of logs)
        if (!l.deleted && l.status === 'moved' && l.date >= from)
            counts.set(l.taskId, (counts.get(l.taskId) ?? 0) + 1);
    return [...counts.entries()]
        .filter(([, n]) => n >= minMoves)
        .map(([taskId, moves]) => ({ taskId, moves }))
        .sort((a, b) => b.moves - a.moves);
}
export function needsRecovery(series, today, threshold, days = 3) {
    for (let i = 1; i <= days; i++) {
        const s = series.get(addDays(today, -i));
        if (typeof s !== 'number' || s >= threshold)
            return false;
    }
    return true;
}
export function recoveryPlan(items, capacityMin, share = 0.6) {
    const budget = capacityMin > 0 ? capacityMin * share : Infinity;
    const active = items.filter(isActiveOnDay);
    const sorted = [...active].sort((a, b) => IMPORTANCE_RANK[b.task.importance] - IMPORTANCE_RANK[a.task.importance] || (a.task.estMinutes ?? 0) - (b.task.estMinutes ?? 0));
    const keep = [];
    const move = [];
    let used = 0;
    for (const i of sorted) {
        const est = i.task.estMinutes ?? 0;
        if (i.task.importance === 'critical' || used + est <= budget) {
            keep.push(i);
            used += est;
        }
        else
            move.push(i);
    }
    return { keep, move, keepLoad: dayLoad(keep) };
}
