import { addDays, parseHHMM } from './dates.js';
import { isScheduledOn, logId, plannedItemsForDate } from './recurrence.js';
import { isComplete } from './score.js';
export const IMPORTANCE_RANK = { normal: 1, important: 2, critical: 3 };
export const URGENCY_RANK = { low: 1, medium: 2, high: 3 };
export function isActiveOnDay(item) {
    const s = item.log?.status;
    return s !== 'not_relevant' && s !== 'moved';
}
export function sortItems(items) {
    const key = (i) => {
        const inactive = !isActiveOnDay(i) ? 2 : isComplete(i.task, i.log) ? 1 : 0;
        return inactive;
    };
    return [...items].sort((a, b) => {
        const k = key(a) - key(b);
        if (k)
            return k;
        const imp = IMPORTANCE_RANK[b.task.importance] - IMPORTANCE_RANK[a.task.importance];
        if (a.task.importance === 'critical' || b.task.importance === 'critical')
            if (imp)
                return imp;
        const urg = URGENCY_RANK[b.task.urgency] - URGENCY_RANK[a.task.urgency];
        if (urg)
            return urg;
        if (imp)
            return imp;
        const da = a.task.deadline ?? '9999-12-31';
        const db = b.task.deadline ?? '9999-12-31';
        if (da !== db)
            return da < db ? -1 : 1;
        return (a.task.estMinutes ?? 0) - (b.task.estMinutes ?? 0);
    });
}
export function dayLoad(items, remainingOnly = false) {
    let sum = 0;
    for (const i of items) {
        if (!isActiveOnDay(i))
            continue;
        if (remainingOnly && isComplete(i.task, i.log))
            continue;
        sum += Math.max(0, i.task.estMinutes ?? 0);
    }
    return sum;
}
export function isOverloaded(items, capacityMin) {
    return capacityMin > 0 && dayLoad(items) > capacityMin;
}
export function overloadAlternatives(items, capacityMin) {
    let load = dayLoad(items);
    if (capacityMin <= 0 || load <= capacityMin)
        return [];
    const candidates = items
        .filter((i) => isActiveOnDay(i) && !isComplete(i.task, i.log))
        .filter((i) => i.task.importance !== 'critical')
        .filter((i) => !(i.task.deadline && i.task.deadline <= i.date))
        .filter((i) => (i.task.estMinutes ?? 0) > 0)
        .sort((a, b) => {
        const imp = IMPORTANCE_RANK[a.task.importance] - IMPORTANCE_RANK[b.task.importance];
        if (imp)
            return imp;
        const urg = URGENCY_RANK[a.task.urgency] - URGENCY_RANK[b.task.urgency];
        if (urg)
            return urg;
        return (b.task.estMinutes ?? 0) - (a.task.estMinutes ?? 0);
    });
    const out = [];
    for (const c of candidates) {
        if (load <= capacityMin)
            break;
        out.push(c);
        load -= c.task.estMinutes ?? 0;
    }
    return out;
}
export function suggestDate(task, fromDate, loadFor, capacityMin, horizon = 14) {
    const est = Math.max(0, task.estMinutes ?? 0);
    const deadline = task.deadline;
    let best = null;
    let firstValid = null;
    for (let i = 1; i <= horizon; i++) {
        const d = addDays(fromDate, i);
        if (task.kind !== 'one_time' && isScheduledOn(task, d))
            continue;
        if (deadline && d > deadline)
            break;
        firstValid ?? (firstValid = d);
        const load = loadFor(d);
        if (capacityMin <= 0 || load + est <= capacityMin)
            return { date: d, fits: true, beforeDeadline: true };
        if (!best || load < best.load)
            best = { date: d, load };
    }
    if (best)
        return { date: best.date, fits: false, beforeDeadline: true };
    if (firstValid)
        return { date: firstValid, fits: false, beforeDeadline: true };
    for (let i = 1; i <= horizon * 2; i++) {
        const d = addDays(fromDate, i);
        if (task.kind !== 'one_time' && isScheduledOn(task, d))
            continue;
        return { date: d, fits: capacityMin <= 0 || loadFor(d) + est <= capacityMin, beforeDeadline: !deadline };
    }
    return { date: addDays(fromDate, 1), fits: false, beforeDeadline: !deadline };
}
export function loadForFactory(tasks, logs) {
    const cache = new Map();
    return (d) => {
        if (!cache.has(d))
            cache.set(d, dayLoad(plannedItemsForDate(tasks, logs, d)));
        return cache.get(d);
    };
}
export function isAfterTheFact(fromDate, today, minutesNow, summaryTime) {
    if (fromDate < today)
        return true;
    if (fromDate > today)
        return false;
    const s = parseHHMM(summaryTime);
    return s !== null && minutesNow >= s;
}
export function planMove(task, fromDate, toDate, afterTheFact) {
    if (toDate === fromDate)
        throw new Error('Target date equals source date');
    if (task.kind !== 'one_time' && isScheduledOn(task, toDate)) {
        throw new Error('The recurring task already occurs on the target date');
    }
    const fromLog = {
        id: logId(task.id, fromDate),
        taskId: task.id,
        date: fromDate,
        status: 'moved',
        movedTo: toDate,
        counted: afterTheFact,
    };
    if (task.kind === 'one_time') {
        return { taskPatch: { date: toDate }, logs: afterTheFact ? [fromLog] : [] };
    }
    return {
        taskPatch: null,
        logs: [
            fromLog,
            { id: logId(task.id, toDate), taskId: task.id, date: toDate, status: 'pending', extra: true, counted: false, movedTo: null },
        ],
    };
}
