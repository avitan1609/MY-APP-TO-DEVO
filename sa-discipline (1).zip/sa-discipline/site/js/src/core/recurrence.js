import { dayOfMonth, daysInMonth, diffDays, weekday } from './dates.js';
export function recurrenceMatches(rule, date) {
    if (date < rule.startDate)
        return false;
    if (rule.endDate && date > rule.endDate)
        return false;
    switch (rule.type) {
        case 'daily':
            return true;
        case 'weekly':
            return (rule.weekdays ?? []).includes(weekday(date));
        case 'interval': {
            const n = Math.max(1, Math.floor(rule.interval ?? 1));
            return diffDays(date, rule.startDate) % n === 0;
        }
        case 'monthly': {
            const wanted = Math.min(Math.max(1, rule.monthDay ?? 1), 31);
            return dayOfMonth(date) === Math.min(wanted, daysInMonth(date));
        }
        default:
            return false;
    }
}
export function isScheduledOn(task, date) {
    if (task.deleted || task.archived)
        return false;
    if (task.kind === 'one_time')
        return task.date === date;
    return task.recurrence ? recurrenceMatches(task.recurrence, date) : false;
}
export function logId(taskId, date) {
    return `${taskId}:${date}`;
}
export function plannedItemsForDate(tasks, logs, date) {
    const byId = new Map(tasks.map((t) => [t.id, t]));
    const dayLogs = new Map();
    for (const l of logs)
        if (l.date === date && !l.deleted)
            dayLogs.set(l.taskId, l);
    const out = [];
    const seen = new Set();
    for (const task of tasks) {
        if (!isScheduledOn(task, date))
            continue;
        const log = dayLogs.get(task.id) ?? null;
        if (log?.status === 'moved' && !log.counted)
            continue;
        out.push({ task, date, log });
        seen.add(task.id);
    }
    for (const [taskId, log] of dayLogs) {
        if (seen.has(taskId))
            continue;
        const task = byId.get(taskId);
        if (!task || task.deleted || task.archived)
            continue;
        if (log.extra || (log.status === 'moved' && log.counted))
            out.push({ task, date, log });
    }
    return out;
}
