export const FORMULA_VERSION = 'v1';
export const DEFAULT_WEIGHTS = { normal: 1, important: 2, critical: 3 };
export function taskWeight(task, weights) {
    const w = task.weightOverride ?? weights[task.importance] ?? 1;
    return Number.isFinite(w) && w > 0 ? w : 0;
}
export function completionRatio(task, log) {
    if (!log)
        return 0;
    if (log.status === 'moved' || log.status === 'not_relevant')
        return 0;
    if (task.measure === 'binary')
        return log.status === 'done' ? 1 : 0;
    const target = task.target ?? 0;
    if (target <= 0)
        return log.status === 'done' ? 1 : 0;
    const value = log.value ?? 0;
    if (!Number.isFinite(value) || value <= 0)
        return log.status === 'done' ? 1 : 0;
    return Math.min(value / target, 1);
}
export function isComplete(task, log) {
    return completionRatio(task, log) >= 1;
}
const round1 = (n) => Math.round(n * 10) / 10;
export function computeDailyScore(items, weights = DEFAULT_WEIGHTS, now = new Date()) {
    const lines = [];
    let total = 0;
    let earned = 0;
    for (const { task, log } of items) {
        const weight = taskWeight(task, weights);
        if (log?.status === 'not_relevant') {
            lines.push({ taskId: task.id, title: task.title, weight, ratio: 0, contribution: 0, excluded: true, reason: 'not_relevant' });
            continue;
        }
        const ratio = completionRatio(task, log);
        const contribution = weight * ratio;
        total += weight;
        earned += contribution;
        lines.push({
            taskId: task.id,
            title: task.title,
            weight,
            ratio: round1(ratio * 100) / 100,
            contribution: round1(contribution),
            excluded: false,
            reason: log?.status === 'moved' ? 'moved' : undefined,
        });
    }
    const score = total > 0 ? round1((100 * earned) / total) : null;
    return {
        score,
        earned: round1(earned),
        totalWeight: round1(total),
        lines,
        formulaVersion: FORMULA_VERSION,
        weights: { ...weights },
        computedAt: now.toISOString(),
    };
}
export function displayScore(score) {
    return score === null ? '—' : String(Math.round(score));
}
