import { addDays } from './dates.js';
import { isScheduledOn, logId } from './recurrence.js';
import { isComplete } from './score.js';
export function dayStreak(scores, threshold, today, maxDays = 400) {
    let streak = 0;
    for (let i = 0; i < maxDays; i++) {
        const d = addDays(today, -i);
        const s = scores.get(d);
        if (s === undefined) {
            if (i === 0)
                continue;
            break;
        }
        if (s === null)
            continue;
        if (s >= threshold)
            streak++;
        else if (i === 0)
            continue;
        else
            break;
    }
    return streak;
}
export function bestDayStreak(scores, threshold) {
    const dates = [...scores.keys()].sort();
    let best = 0;
    let cur = 0;
    let prev = null;
    for (const d of dates) {
        if (prev && addDays(prev, 1) !== d)
            cur = 0;
        prev = d;
        const s = scores.get(d);
        if (s === null || s === undefined)
            continue;
        if (s >= threshold)
            best = Math.max(best, ++cur);
        else
            cur = 0;
    }
    return best;
}
export function habitStreak(task, logs, today, maxDays = 400) {
    const byId = new Map(logs.filter((l) => l.taskId === task.id && !l.deleted).map((l) => [l.id, l]));
    let streak = 0;
    for (let i = 0; i < maxDays; i++) {
        const d = addDays(today, -i);
        const log = byId.get(logId(task.id, d)) ?? null;
        const scheduled = isScheduledOn(task, d) || !!log?.extra;
        if (!scheduled) {
            if (task.recurrence && d < task.recurrence.startDate)
                break;
            continue;
        }
        if (log?.status === 'not_relevant' || (log?.status === 'moved' && !log.counted))
            continue;
        if (isComplete(task, log))
            streak++;
        else if (i === 0)
            continue;
        else
            break;
    }
    return streak;
}
export function habitCompletionRate(task, logs, from, to) {
    const byId = new Map(logs.filter((l) => l.taskId === task.id && !l.deleted).map((l) => [l.id, l]));
    let scheduled = 0;
    let done = 0;
    for (let d = from; d <= to; d = addDays(d, 1)) {
        const log = byId.get(logId(task.id, d)) ?? null;
        if (!(isScheduledOn(task, d) || log?.extra))
            continue;
        if (log?.status === 'not_relevant' || (log?.status === 'moved' && !log.counted))
            continue;
        scheduled++;
        if (isComplete(task, log))
            done++;
    }
    return scheduled ? done / scheduled : null;
}
