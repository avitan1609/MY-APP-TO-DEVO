import { addDays } from './dates.js';
import { dayLoad, isActiveOnDay, isAfterTheFact, loadForFactory, suggestDate } from './planning.js';
import { averageOver, needsRecovery, scoreSeries } from './patterns.js';
import { plannedItemsForDate } from './recurrence.js';
import { completionRatio, computeDailyScore, isComplete } from './score.js';
import { dayStreak } from './streaks.js';
export function buildDaySummary(args) {
    const { date, today, tasks, logs, settings } = args;
    const items = plannedItemsForDate(tasks, logs, date);
    const snapshot = computeDailyScore(items, settings.weights, args.now);
    const active = items.filter(isActiveOnDay);
    const histDates = [];
    for (let i = 0; i <= 60; i++)
        histDates.push(addDays(date, -i));
    const snaps = new Map(args.snapshots ?? []);
    snaps.delete(date);
    const series = scoreSeries(tasks, logs, histDates, settings.weights, snaps);
    series.set(date, snapshot.score);
    const numeric = active
        .filter((i) => i.task.measure !== 'binary' && (i.task.target ?? 0) > 0)
        .map((i) => ({ task: i.task, value: i.log?.value ?? 0, target: i.task.target, met: completionRatio(i.task, i.log) >= 1 }));
    const importantOpen = active.filter((i) => i.task.importance !== 'normal' && !isComplete(i.task, i.log));
    const tomorrowDate = addDays(date, 1);
    const tomorrowItems = plannedItemsForDate(tasks, logs, tomorrowDate);
    const tomorrowLoad = dayLoad(tomorrowItems);
    const loadFor = loadForFactory(tasks, logs);
    const afterTheFact = isAfterTheFact(date, today, args.minutesNow, settings.summaryTime);
    const proposals = active
        .filter((i) => !isComplete(i.task, i.log))
        .map((item) => ({ item, suggestion: suggestDate(item.task, date, loadFor, settings.dailyCapacityMin), afterTheFact }));
    return {
        date,
        snapshot,
        planned: active.length,
        done: active.filter((i) => isComplete(i.task, i.log)).length,
        numeric,
        importantOpen,
        streak: dayStreak(series, settings.streakThreshold, date),
        avg7: averageOver(series, date, 7, true),
        avg30: averageOver(series, date, 30, true),
        recovery: needsRecovery(series, addDays(date, 1), settings.streakThreshold),
        tomorrow: {
            date: tomorrowDate,
            items: tomorrowItems,
            load: tomorrowLoad,
            overloaded: settings.dailyCapacityMin > 0 && tomorrowLoad > settings.dailyCapacityMin,
        },
        proposals,
    };
}
