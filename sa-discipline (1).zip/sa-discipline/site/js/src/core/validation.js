import { isISODate, isValidTimeZone, parseHHMM } from './dates.js';
const num = (n) => typeof n === 'number' && Number.isFinite(n);
export function validateTask(t) {
    const e = {};
    const title = t.title.trim();
    if (!title)
        e.title = 'חובה למלא שם משימה';
    else if (title.length > 120)
        e.title = 'עד 120 תווים';
    if (t.description.length > 2000)
        e.description = 'עד 2000 תווים';
    if (t.notes.length > 5000)
        e.notes = 'עד 5000 תווים';
    if (t.kind === 'one_time') {
        if (t.date !== null && !isISODate(t.date))
            e.date = 'תאריך לא תקין';
    }
    else {
        const r = t.recurrence;
        if (!r)
            e.recurrence = 'יש לבחור תדירות';
        else {
            if (!isISODate(r.startDate))
                e.recurrence = 'תאריך התחלה לא תקין';
            else if (r.endDate && (!isISODate(r.endDate) || r.endDate < r.startDate))
                e.recurrence = 'תאריך סיום חייב להיות אחרי ההתחלה';
            else if (r.type === 'weekly' && !(r.weekdays && r.weekdays.length))
                e.recurrence = 'יש לבחור לפחות יום אחד';
            else if (r.type === 'weekly' && r.weekdays.some((d) => !Number.isInteger(d) || d < 0 || d > 6))
                e.recurrence = 'יום לא תקין';
            else if (r.type === 'interval' && !(Number.isInteger(r.interval) && r.interval >= 1 && r.interval <= 365))
                e.recurrence = 'מרווח בין 1 ל־365 ימים';
            else if (r.type === 'monthly' && !(Number.isInteger(r.monthDay) && r.monthDay >= 1 && r.monthDay <= 31))
                e.recurrence = 'יום בחודש בין 1 ל־31';
        }
    }
    if (t.deadline !== null && !isISODate(t.deadline))
        e.deadline = 'תאריך לא תקין';
    if (t.kind === 'one_time' && t.date && t.deadline && t.deadline < t.date)
        e.deadline = 'הדדליין לפני התאריך המתוכנן';
    if (t.measure !== 'binary') {
        if (!num(t.target) || t.target <= 0)
            e.target = 'יש להגדיר יעד גדול מ־0';
        else if (t.target > 1000000)
            e.target = 'יעד גבוה מדי';
        if (t.measure === 'numeric' && !(t.unit ?? '').trim())
            e.unit = 'יש להגדיר יחידת מדידה';
    }
    if (t.estMinutes !== null && (!num(t.estMinutes) || t.estMinutes < 0 || t.estMinutes > 1440))
        e.estMinutes = 'בין 0 ל־1440 דקות';
    if (t.weightOverride !== null && (!num(t.weightOverride) || t.weightOverride <= 0 || t.weightOverride > 10))
        e.weightOverride = 'משקל בין 0.1 ל־10';
    if (t.subtasks.length > 50)
        e.subtasks = 'עד 50 תתי־משימות';
    else if (t.subtasks.some((s) => !s.title.trim()))
        e.subtasks = 'לתת־משימה חייב להיות שם';
    return e;
}
export function validateGoal(g) {
    const e = {};
    if (!g.title.trim())
        e.title = 'חובה למלא שם מטרה';
    else if (g.title.length > 120)
        e.title = 'עד 120 תווים';
    if (!isISODate(g.startDate))
        e.startDate = 'תאריך לא תקין';
    if (!isISODate(g.endDate))
        e.endDate = 'תאריך לא תקין';
    else if (isISODate(g.startDate) && g.endDate < g.startDate)
        e.endDate = 'הסיום לפני ההתחלה';
    if (g.progressMode !== 'linked_completion') {
        if (!num(g.target) || g.target <= 0)
            e.target = 'יש להגדיר יעד גדול מ־0';
    }
    if (!num(g.currentValue) || g.currentValue < 0)
        e.currentValue = 'ערך לא תקין';
    return e;
}
export function validateSettings(s) {
    const e = {};
    if (parseHHMM(s.summaryTime) === null)
        e.summaryTime = 'שעה בפורמט HH:MM';
    if (!isValidTimeZone(s.timezone))
        e.timezone = 'אזור זמן לא תקין';
    if (!Number.isInteger(s.weekStart) || s.weekStart < 0 || s.weekStart > 6)
        e.weekStart = 'יום לא תקין';
    if (!num(s.dailyCapacityMin) || s.dailyCapacityMin < 0 || s.dailyCapacityMin > 1440)
        e.dailyCapacityMin = 'בין 0 ל־1440 דקות';
    if (!num(s.streakThreshold) || s.streakThreshold < 0 || s.streakThreshold > 100)
        e.streakThreshold = 'בין 0 ל־100';
    for (const k of ['normal', 'important', 'critical']) {
        const w = s.weights[k];
        if (!num(w) || w <= 0 || w > 10)
            e[`weights.${k}`] = 'משקל בין 0.1 ל־10';
    }
    return e;
}
