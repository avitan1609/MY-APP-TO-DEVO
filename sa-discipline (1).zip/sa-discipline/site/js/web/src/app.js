import { minutesNowIn, todayIn } from '../../src/core/dates.js';
import { S } from './store.js';
export const A = {
    today: '',
    minutesNow: 0,
    route: { name: 'day', date: null },
    weekOff: 0,
    taskTab: 'active',
    taskQuery: '',
    taskCat: '',
    goalStatus: 'active',
    statRange: '30',
    sum: { date: '', journal: null, blockers: null, picked: {} },
    settingsErrors: {},
};
export function tick() {
    const tz = S.settings.timezone;
    const today = todayIn(tz);
    const m = minutesNowIn(tz);
    const changedDay = today !== A.today;
    A.today = today;
    A.minutesNow = m;
    return changedDay;
}
export const actions = {};
export const segs = {};
export const binds = {};
export const submits = {};
let refreshFn = () => { };
export const setRefresh = (f) => (refreshFn = f);
export const refresh = () => refreshFn();
let sheetRefresher = null;
export const setSheetRefresher = (f) => (sheetRefresher = f);
export const refreshSheet = () => {
    if (document.getElementById('sheet-body'))
        sheetRefresher?.();
    else
        sheetRefresher = null;
};
export function routeHash(r) {
    switch (r.name) {
        case 'day':
            return r.date ? `#/day/${r.date}` : '#/';
        case 'summary':
            return r.date ? `#/summary/${r.date}` : '#/summary';
        default:
            return `#/${r.name}`;
    }
}
export function go(r) {
    const h = routeHash(r);
    if (location.hash === h)
        refresh();
    else
        location.hash = h;
}
