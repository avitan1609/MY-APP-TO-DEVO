import { coachMessage } from '../../src/core/coach.js';
import { addDays, formatHebrewDate, formatShortDate, hebrewWeekday, parseHHMM, range, startOfMonth, startOfWeek, weekDates } from '../../src/core/dates.js';
import { formatPace, paceMinPerKm } from '../../src/core/factories.js';
import { goalProgress } from '../../src/core/goals.js';
import { average, averageOver, categoryRates, frequentlyPostponed, needsRecovery, scoreSeries, weekdayAverages } from '../../src/core/patterns.js';
import { dayLoad, isActiveOnDay, isOverloaded, sortItems } from '../../src/core/planning.js';
import { plannedItemsForDate } from '../../src/core/recurrence.js';
import { FORMULA_VERSION, completionRatio, computeDailyScore, isComplete } from '../../src/core/score.js';
import { bestDayStreak, dayStreak, habitCompletionRate, habitStreak } from '../../src/core/streaks.js';
import { buildDaySummary } from '../../src/core/summary.js';
import { HORIZON_LABEL, IMPORTANCE_LABEL, KIND_LABEL, fmtNum, minutesText, recurrenceText, relDay } from '../../src/ui/labels.js';
import { A } from './app.js';
import { S, categoryById, dayEntry, liveCategories, liveGoals, liveTasks, logsArr, snapshotMap } from './store.js';
import { I, bar, cls, esc, miniRing, ring, seg, stat } from './ui.js';
const W = () => S.settings;
const shortD = (d) => formatShortDate(d);
export function taskRow(i) {
    const { task: t, log: l, date } = i;
    const done = isComplete(t, l);
    const cancelled = l?.status === 'not_relevant';
    const movedAway = l?.status === 'moved';
    const inactive = cancelled || movedAway;
    const cat = categoryById(t.categoryId);
    const meta = [];
    if (cancelled)
        meta.push('<span>בוטלה להיום</span>');
    if (movedAway)
        meta.push(`<span>${I.move(13)}הועברה${l?.movedTo ? ` ל־${shortD(l.movedTo)}` : ''}${l?.counted ? ' · נספרה כ־0' : ''}</span>`);
    if (cat)
        meta.push(`<span><i class="dot" style="background:${esc(cat.color)}"></i>${esc(cat.name)}</span>`);
    if (t.estMinutes)
        meta.push(`<span>${I.clock()}${minutesText(t.estMinutes)}</span>`);
    if (t.subtasks.length)
        meta.push(`<span class="num">${(l?.subtaskDone ?? []).filter((id) => t.subtasks.some((s) => s.id === id)).length}/${t.subtasks.length}</span>`);
    if (t.deadline)
        meta.push(`<span>דדליין ${shortD(t.deadline)}</span>`);
    if (l?.extra)
        meta.push('<span>הועבר לכאן</span>');
    if (t.activity === 'run' && (l?.distanceKm || l?.durationMin))
        meta.push(`<span class="num">${fmtNum(l?.distanceKm ?? 0, 2)} ק"מ · ${formatPace(paceMinPerKm(l?.distanceKm ?? null, l?.durationMin ?? null))}</span>`);
    const flag = t.importance !== 'normal'
        ? `<span class="${t.importance === 'critical' ? 'c-danger' : 'c-warn'}">${I.flag()}</span><span class="sr-only">${IMPORTANCE_LABEL[t.importance]}</span>`
        : '';
    const left = t.measure === 'binary' || inactive
        ? `<button type="button" class="check ${done ? 'on' : ''}" data-a="toggle" data-task="${t.id}" data-date="${date}" ${inactive ? 'disabled' : ''} aria-pressed="${done}" aria-label="${done ? 'בטל סימון' : 'סמן כבוצע'}: ${esc(t.title)}">${done ? I.check(16) : ''}</button>`
        : miniRing(completionRatio(t, l), done);
    const qty = t.measure !== 'binary' && !inactive
        ? `<form class="qty" data-submit="qty" data-task="${t.id}" data-date="${date}"><div class="v"><b class="num">${fmtNum(l?.value ?? 0, 2)}</b><span class="num">/ ${fmtNum(t.target, 2)}</span></div><input class="field num" id="qty-${t.id}" inputmode="decimal" placeholder="+" aria-label="הוסף כמות ל${esc(t.title)}" autocomplete="off"></form>`
        : '';
    return `<li class="card task ${cls(t.importance === 'critical' && !done && !inactive && 'crit', done && 'done', inactive && 'inactive')}">${left}
    <button type="button" class="body" data-a="open-item" data-task="${t.id}" data-date="${date}"><span class="ttl">${flag}${t.activity === 'run' ? `<span class="c-muted">${I.run()}</span>` : ''}<span class="t">${esc(t.title)}</span></span>${meta.length ? `<span class="meta">${meta.join('')}</span>` : ''}</button>${qty}</li>`;
}
export function viewDay(date) {
    const tasks = liveTasks();
    const logs = logsArr();
    const isToday = date === A.today;
    const items = sortItems(plannedItemsForDate(tasks, logs, date));
    const live = computeDailyScore(items, W().weights);
    const frozen = date < A.today ? dayEntry(date).scoreSnapshot : null;
    const shown = frozen ? frozen.score : live.score;
    const snaps = snapshotMap();
    snaps.delete(date);
    const series = scoreSeries(tasks, logs, Array.from({ length: 45 }, (_, i) => addDays(date, -i)), W().weights, snaps);
    series.set(date, shown);
    const streak = dayStreak(series, W().streakThreshold, date);
    const avg7 = averageOver(series, date, 7, true);
    const recovery = isToday && needsRecovery(series, date, W().streakThreshold);
    const active = items.filter(isActiveOnDay);
    const doneCount = active.filter((i) => isComplete(i.task, i.log)).length;
    const load = dayLoad(items);
    const cap = W().dailyCapacityMin;
    const overloaded = isOverloaded(items, cap);
    const critOpen = active.filter((i) => i.task.importance === 'critical' && !isComplete(i.task, i.log)).length;
    const summaryAt = parseHHMM(W().summaryTime) ?? 1290;
    const dayOver = date < A.today || (isToday && A.minutesNow >= summaryAt);
    const coach = coachMessage({
        score: shown,
        avg7,
        streak,
        threshold: W().streakThreshold,
        criticalOpen: critOpen,
        criticalMissed: dayOver ? critOpen : 0,
        recovery,
        overloaded,
        dayOver,
    });
    const open = items.filter((i) => isActiveOnDay(i) && !isComplete(i.task, i.log));
    const closed = items.filter((i) => !isActiveOnDay(i) || isComplete(i.task, i.log));
    const crit = open.filter((i) => i.task.importance === 'critical');
    const rest = open.filter((i) => i.task.importance !== 'critical');
    const grp = (title, arr) => (arr.length ? `<h2 class="grp-t">${title}</h2><ul class="list">${arr.map(taskRow).join('')}</ul>` : '');
    const banners = [];
    if (overloaded && !dayOver)
        banners.push(`<div class="banner warn"><span class="c-warn">${I.alert()}</span><span>היום עמוס ב־${minutesText(load - cap)} מעבר לקיבולת.</span><button type="button" class="btn sm" data-a="overload" data-date="${date}">הצג חלופות</button></div>`);
    if (isToday && A.minutesNow >= summaryAt && !dayEntry(date).summaryGeneratedAt)
        banners.push(`<div class="banner acc"><span class="c-accent">${I.alert()}</span><span>הגיע זמן הסיכום היומי. שתי דקות לסגור את היום.</span><a class="btn sm primary" href="#/summary">לסיכום</a></div>`);
    return `<div class="daynav"><a class="icon-btn" href="#/day/${addDays(date, -1)}" aria-label="היום הקודם">${I.prev()}</a>
    <div><h1>${isToday ? 'היום' : esc(relDay(date, A.today))}</h1><p>${esc(formatHebrewDate(date))}</p>${!isToday ? '<a class="link" href="#/">חזרה להיום</a>' : ''}</div>
    <a class="icon-btn" href="#/day/${addDays(date, 1)}" aria-label="היום הבא">${I.next()}</a></div>
    <section class="card scorecard">${ring(shown, 116, frozen ? 'ציון שנשמר' : 'ציון יומי')}
      <div class="sc-side">
        <div class="meta-row"><span><b class="num">${doneCount}/${active.length}</b> <span class="mu">הושלמו</span></span>
          <span class="inl"><span class="${streak ? 'c-warn' : 'c-faint'}">${I.flame()}</span><b class="num">${streak}</b> <span class="mu">ימי רצף</span></span>
          ${avg7 !== null ? `<span class="mu">ממוצע 7 ימים <b class="num c-ink">${Math.round(avg7)}</b></span>` : ''}</div>
        ${cap > 0 ? `<div><div class="row-between small mu"><span>עומס מתוכנן</span><span class="num ${overloaded ? 'c-danger strong' : ''}">${minutesText(load)} / ${minutesText(cap)}</span></div>${bar(load, cap, overloaded ? 'danger' : '')}</div>` : ''}
        <p class="coach ${coach.tone}">${esc(coach.text)}</p>
      </div></section>
    ${banners.join('')}
    ${items.length
        ? grp('קריטי', crit) +
            grp(crit.length ? 'שאר המשימות' : 'משימות', rest) +
            (open.length === 0 ? '<p class="all-done">כל המשימות הושלמו.</p>' : '') +
            grp('הושלמו / לא פעילות', closed)
        : `<div class="card empty"><p class="e-t">אין משימות מתוכננות</p><p class="e-b">${isToday ? 'תוסיף את מה שחייב לקרות היום. התחל מהדבר החשוב ביותר.' : 'אין משימות ליום הזה.'}</p><button type="button" class="btn primary" data-a="quick" data-date="${date}">${I.plus()} הוסף משימה</button></div>`}
    ${items.length ? `<button type="button" class="addrow" data-a="quick" data-date="${date}">${I.plus()} הוסף משימה ${isToday ? 'להיום' : `ל${esc(relDay(date, A.today))}`}</button>` : ''}`;
}
export function viewWeek() {
    const dates = weekDates(addDays(A.today, A.weekOff * 7), W().weekStart);
    const tasks = liveTasks();
    const logs = logsArr();
    const snaps = snapshotMap();
    const rows = dates.map((d) => {
        const items = sortItems(plannedItemsForDate(tasks, logs, d));
        const live = computeDailyScore(items, W().weights).score;
        const score = d < A.today && snaps.has(d) ? snaps.get(d) : live;
        const act = items.filter(isActiveOnDay);
        return { d, items, score, load: dayLoad(items), done: act.filter((i) => isComplete(i.task, i.log)).length, total: act.length };
    });
    const avg = average(rows.filter((r) => r.d <= A.today).map((r) => r.score));
    const cap = W().dailyCapacityMin;
    return `<div class="page-h"><div><h1>תכנון שבועי</h1><p class="num">${shortD(dates[0])} – ${shortD(dates[6])}</p></div>
    <div class="inl"><button type="button" class="icon-btn" data-a="week" data-d="-1" aria-label="שבוע קודם">${I.prev()}</button>${A.weekOff ? '<button type="button" class="btn ghost sm" data-a="week" data-d="0">השבוע</button>' : ''}<button type="button" class="icon-btn" data-a="week" data-d="1" aria-label="שבוע הבא">${I.next()}</button></div></div>
    <div class="stats three">${stat('ממוצע ציון', avg === null ? '—' : Math.round(avg))}${stat('הושלמו', `${rows.reduce((a, r) => a + r.done, 0)}/${rows.reduce((a, r) => a + r.total, 0)}`)}${stat('עומס שבועי', minutesText(rows.reduce((a, r) => a + r.load, 0)))}</div>
    <ul class="list">${rows
        .map((r) => {
        const over = cap > 0 && r.load > cap;
        const isT = r.d === A.today;
        return `<li class="card wday ${isT ? 'today' : ''}"><div class="top"><a class="wlink" href="#/day/${r.d}">
          <span class="dn"><b>${hebrewWeekday(r.d)}</b><small class="num">${shortD(r.d)}</small></span>
          <span class="mid"><span class="l"><span>${r.total ? `${r.done}/${r.total} משימות` : 'אין משימות'}${r.load ? ' · ' + minutesText(r.load) : ''}</span>${over ? '<span class="c-danger strong">עומס יתר</span>' : ''}</span>${cap > 0 ? bar(r.load, cap, over ? 'danger' : '') : ''}</span>
          <span class="sc num">${r.d <= A.today && r.score !== null ? Math.round(r.score) : '<span class="c-faint">—</span>'}</span></a>
          <button type="button" class="icon-btn" data-a="quick" data-date="${r.d}" aria-label="הוסף משימה ל${hebrewWeekday(r.d)}">${I.plus(18)}</button></div>
          ${r.items.length
            ? `<div class="chips">${r.items
                .slice(0, 8)
                .map((i) => {
                const ok = isComplete(i.task, i.log);
                const off = !isActiveOnDay(i);
                return `<span class="chip ${ok ? 'ok' : off ? 'off' : i.task.importance === 'critical' ? 'crit' : ''}">${ok ? I.check(12) : ''}<span class="t">${esc(i.task.title)}</span></span>`;
            })
                .join('')}${r.items.length > 8 ? `<span class="chip">+${r.items.length - 8}</span>` : ''}</div>`
            : ''}</li>`;
    })
        .join('')}</ul>`;
}
export function viewTasks() {
    const term = A.taskQuery.trim().toLowerCase();
    const all = liveTasks();
    const logs = logsArr();
    const list = all
        .filter((t) => {
        if (term && !(t.title.toLowerCase().includes(term) || t.description.toLowerCase().includes(term)))
            return false;
        if (A.taskCat && t.categoryId !== A.taskCat)
            return false;
        switch (A.taskTab) {
            case 'archived':
                return t.archived;
            case 'habits':
                return !t.archived && t.kind !== 'one_time';
            case 'backlog':
                return !t.archived && t.kind === 'one_time' && !t.date;
            case 'done':
                return !t.archived && t.kind === 'one_time' && !!t.date && t.date < A.today;
            default:
                return !t.archived && (t.kind !== 'one_time' || (!!t.date && t.date >= A.today));
        }
    })
        .sort((a, b) => {
        if (a.kind === 'one_time' && b.kind === 'one_time') {
            const c = (a.date ?? '').localeCompare(b.date ?? '');
            return A.taskTab === 'done' ? -c : c;
        }
        if (a.kind !== b.kind)
            return a.kind === 'one_time' ? 1 : -1;
        return a.title.localeCompare(b.title, 'he');
    });
    const row = (t) => {
        const cat = categoryById(t.categoryId);
        const isH = t.kind !== 'one_time';
        const streak = isH ? habitStreak(t, logs, A.today) : 0;
        const rate = isH ? habitCompletionRate(t, logs, addDays(A.today, -29), A.today) : null;
        const meta = [
            `<span>${t.kind === 'one_time' ? (t.date ? esc(relDay(t.date, A.today)) : 'ללא תאריך') : esc(recurrenceText(t.recurrence))}</span>`,
            `<span>${KIND_LABEL[t.kind]}</span>`,
            t.importance !== 'normal' ? `<span>${IMPORTANCE_LABEL[t.importance]}</span>` : '',
            cat ? `<span><i class="dot" style="background:${esc(cat.color)}"></i>${esc(cat.name)}</span>` : '',
            t.estMinutes ? `<span>${minutesText(t.estMinutes)}</span>` : '',
            isH ? `<span class="inl"><span class="${streak ? 'c-warn' : 'c-faint'}">${I.flame(13)}</span><span class="num">${streak}</span></span>` : '',
            rate !== null ? `<span class="num">${Math.round(rate * 100)}% ב־30 יום</span>` : '',
        ].join('');
        const btns = [
            A.taskTab === 'backlog' ? `<button type="button" class="btn sm" data-a="schedule-today" data-task="${t.id}">להיום</button>` : '',
            A.taskTab === 'archived'
                ? `<button type="button" class="btn sm" data-a="archive" data-task="${t.id}" data-v="0">שחזר</button>`
                : `<button type="button" class="btn ghost sm" data-a="archive" data-task="${t.id}" data-v="1" aria-label="העבר לארכיון: ${esc(t.title)}">ארכיון</button>`,
        ].join('');
        return `<li class="card trow"><button type="button" class="body" data-a="edit-task" data-task="${t.id}"><span class="ttl">${t.importance !== 'normal' ? `<span class="${t.importance === 'critical' ? 'c-danger' : 'c-warn'}">${I.flag()}</span>` : ''}<span class="t">${esc(t.title)}</span></span><span class="meta">${meta}</span></button><span class="btns">${btns}</span></li>`;
    };
    return `<div class="page-h"><div><h1>משימות והרגלים</h1><p>${all.filter((t) => !t.archived).length} פעילות</p></div><button type="button" class="btn primary sm" data-a="new-task">${I.plus()} חדשה</button></div>
    <div class="scroll-x">${seg('taskTab', A.taskTab, [
        ['active', 'פעילות'],
        ['habits', 'חוזרות והרגלים'],
        ['backlog', 'ללא תאריך'],
        ['done', 'עבר'],
        ['archived', 'ארכיון'],
    ], undefined, true)}</div>
    <div class="filters"><div class="search">${I.search()}<input class="field" id="task-q" placeholder="חיפוש" value="${esc(A.taskQuery)}" data-bind="taskQuery" aria-label="חיפוש משימות" autocomplete="off"></div>
      <select class="field" id="task-cat" data-bind="taskCat" aria-label="סינון לפי קטגוריה"><option value="">כל הקטגוריות</option>${liveCategories()
        .map((c) => `<option value="${c.id}" ${A.taskCat === c.id ? 'selected' : ''}>${esc(c.name)}</option>`)
        .join('')}</select></div>
    ${list.length
        ? `<ul class="list">${list.map(row).join('')}</ul>`
        : `<div class="card empty"><p class="e-t">${A.taskTab === 'backlog' ? 'אין משימות ממתינות' : 'אין משימות כאן'}</p>${A.taskTab === 'habits' ? '<p class="e-b">הרגל הוא משימה חוזרת עם רצף משלה. לדוגמה: פיזיותרפיה 3 פעמים בשבוע.</p>' : ''}<button type="button" class="btn primary" data-a="new-task" data-preset="${A.taskTab}">${I.plus()} משימה חדשה</button></div>`}`;
}
export function viewGoals() {
    const tasks = liveTasks();
    const logs = logsArr();
    const rows = liveGoals()
        .filter((g) => g.status === A.goalStatus)
        .sort((a, b) => a.endDate.localeCompare(b.endDate))
        .map((g) => ({ g, p: goalProgress(g, tasks, logs, A.today) }));
    return `<div class="page-h"><div><h1>מטרות</h1><p>חודשיות, רבעוניות ושנתיות, עם קישור למשימות</p></div><button type="button" class="btn primary sm" data-a="new-goal">${I.plus()} מטרה</button></div>
    <div class="mb">${seg('goalStatus', A.goalStatus, [
        ['active', 'פעילות'],
        ['done', 'הושגו'],
        ['archived', 'ארכיון'],
    ], undefined, true)}</div>
    ${rows.length
        ? `<ul class="list">${rows
            .map(({ g, p }) => {
            const behind = g.status === 'active' && p.ratio + 0.05 < p.expected;
            return `<li><button type="button" class="card goal" data-a="edit-goal" data-goal="${g.id}">
                <span class="row-between"><b class="t">${esc(g.title)}</b><b class="num">${Math.round(p.ratio * 100)}%</b></span>
                ${bar(p.ratio, 1, behind ? 'warn' : '')}
                <span class="row-between small mu wrap"><span>${HORIZON_LABEL[g.horizon]} · עד ${shortD(g.endDate)}${p.linkedTasks ? ` · ${p.linkedTasks} משימות מקושרות` : ''}</span>
                <span><span class="num">${fmtNum(p.current)}${p.target ? ` / ${fmtNum(p.target)}` : ''}</span> ${g.progressMode !== 'linked_completion' ? esc(g.unit ?? '') : 'בוצעו'}${behind ? ' <span class="c-warn">· מאחורי הקצב</span>' : ''}</span></span></button></li>`;
        })
            .join('')}</ul>`
        : `<div class="card empty"><p class="e-t">אין מטרות כאן</p><p class="e-b">מטרה טובה היא מדידה ותחומה בזמן. קשר אליה משימות והרגלים כדי לראות התקדמות אמיתית.</p><button type="button" class="btn primary" data-a="new-goal">${I.plus()} מטרה חדשה</button></div>`}`;
}
function lineChart(points, threshold) {
    const w = 640, h = 220, pl = 30, pr = 12, pt = 12, pb = 26;
    const iw = w - pl - pr, ih = h - pt - pb;
    const X = (i) => pl + (points.length > 1 ? (i * iw) / (points.length - 1) : iw / 2);
    const Y = (v) => pt + ih - (v / 100) * ih;
    let path = '';
    let started = false;
    points.forEach((p, i) => {
        if (p.v === null) {
            started = false;
            return;
        }
        path += `${started ? 'L' : 'M'}${X(i).toFixed(1)},${Y(p.v).toFixed(1)}`;
        started = true;
    });
    const pts = points.map((p, i) => (p.v === null ? null : [X(i), Y(p.v)])).filter((x) => !!x);
    const area = pts.length > 1 ? `M${pts[0][0].toFixed(1)},${pt + ih}` + pts.map((q) => `L${q[0].toFixed(1)},${q[1].toFixed(1)}`).join('') + `L${pts[pts.length - 1][0].toFixed(1)},${pt + ih}Z` : '';
    const grid = [0, 25, 50, 75, 100]
        .map((v) => `<line class="grid" x1="${pl}" x2="${w - pr}" y1="${Y(v)}" y2="${Y(v)}"/><text x="${pl - 6}" y="${Y(v) + 4}" text-anchor="end">${v}</text>`)
        .join('');
    const step = Math.max(1, Math.ceil(points.length / 7));
    const xl = points.map((p, i) => (i % step === 0 || i === points.length - 1 ? `<text x="${X(i).toFixed(1)}" y="${h - 6}" text-anchor="middle">${shortD(p.d)}</text>` : '')).join('');
    const last = pts[pts.length - 1];
    const dots = points.length <= 31 ? pts.map((q) => `<circle class="dot-pt" cx="${q[0].toFixed(1)}" cy="${q[1].toFixed(1)}" r="2.6"/>`).join('') : '';
    return `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="גרף ציון יומי">${grid}
    <line class="thr" x1="${pl}" x2="${w - pr}" y1="${Y(threshold)}" y2="${Y(threshold)}"/><text class="thr-t" x="${w - pr}" y="${Y(threshold) - 5}" text-anchor="end">סף ${threshold}</text>
    ${area ? `<path class="area" d="${area}"/>` : ''}<path class="line" d="${path}"/>${dots}
    ${last ? `<circle class="end" cx="${last[0].toFixed(1)}" cy="${last[1].toFixed(1)}" r="4.5"/>` : ''}${xl}</svg>`;
}
function weekdayChart(vals, weekStart) {
    const order = Array.from({ length: 7 }, (_, i) => (weekStart + i) % 7);
    const w = 320, h = 170, pl = 28, pr = 6, pb = 22, pt = 8;
    const iw = w - pl - pr, ih = h - pt - pb, bw = iw / 7;
    const max = Math.max(...vals.map((v) => v ?? -1));
    const DS = ['א׳', 'ב׳', 'ג׳', 'ד׳', 'ה׳', 'ו׳', 'ש׳'];
    return `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="ממוצע ציון לפי יום בשבוע">${[0, 50, 100]
        .map((v) => `<line class="grid" x1="${pl}" x2="${w - pr}" y1="${pt + ih - (v / 100) * ih}" y2="${pt + ih - (v / 100) * ih}"/><text x="${pl - 5}" y="${pt + ih - (v / 100) * ih + 4}" text-anchor="end">${v}</text>`)
        .join('')}${order
        .map((wd, i) => {
        const v = vals[wd];
        const x = pl + (6 - i) * bw + bw * 0.2;
        const bh = ((v ?? 0) / 100) * ih;
        return `${v !== null ? `<rect class="${v === max ? 'b-top' : 'b'}" x="${x.toFixed(1)}" y="${(pt + ih - bh).toFixed(1)}" width="${(bw * 0.6).toFixed(1)}" height="${bh.toFixed(1)}" rx="4"><title>${DS[wd]}: ${Math.round(v)}</title></rect>` : ''}<text x="${(x + bw * 0.3).toFixed(1)}" y="${h - 5}" text-anchor="middle">${DS[wd]}</text>`;
    })
        .join('')}</svg>`;
}
export function viewStats() {
    const tasks = liveTasks();
    const logs = logsArr();
    const n = Number(A.statRange);
    const from = addDays(A.today, -(n - 1));
    const dates = range(from, A.today);
    const snaps = snapshotMap();
    snaps.delete(A.today);
    const longDates = range(addDays(A.today, -179), A.today);
    const series = scoreSeries(tasks, logs, longDates, W().weights, snaps);
    const inRange = dates.map((d) => ({ d, v: series.get(d) ?? null }));
    const avg = average(inRange.map((x) => x.v));
    const above = inRange.filter((x) => x.v !== null && x.v >= W().streakThreshold).length;
    const hasScores = inRange.some((x) => x.v !== null);
    let planned = 0;
    let done = 0;
    for (const d of dates)
        for (const i of plannedItemsForDate(tasks, logs, d)) {
            if (!isActiveOnDay(i))
                continue;
            planned++;
            if (isComplete(i.task, i.log))
                done++;
        }
    const wdAvg = weekdayAverages(new Map(inRange.map((x) => [x.d, x.v])));
    const cats = categoryRates(tasks, logs, dates, W().weights);
    const postponed = frequentlyPostponed(logs, addDays(A.today, -30));
    const habits = tasks
        .filter((t) => t.kind !== 'one_time' && !t.archived)
        .map((t) => ({ t, s: habitStreak(t, logs, A.today), r: habitCompletionRate(t, logs, from, A.today) }))
        .sort((a, b) => (b.r ?? -1) - (a.r ?? -1));
    const weeks = [];
    for (let k = 7; k >= 0; k--) {
        const start = addDays(startOfWeek(A.today, W().weekStart), -7 * k);
        const ds = range(start, addDays(start, 6)).filter((d) => d <= A.today);
        weeks.push({ label: `שבוע ${shortD(start)}`, v: average(ds.map((d) => series.get(d))) });
    }
    const months = [];
    let m = startOfMonth(A.today);
    for (let k = 0; k < 6; k++) {
        const next = startOfMonth(addDays(m, 32));
        const ds = range(m, addDays(next, -1)).filter((d) => d <= A.today && d >= longDates[0]);
        months.unshift({ label: new Intl.DateTimeFormat('he-IL', { month: 'long', timeZone: 'UTC' }).format(new Date(m + 'T00:00:00Z')), v: average(ds.map((d) => series.get(d))) });
        m = startOfMonth(addDays(m, -1));
    }
    const report = (title, rows) => `<div><h2 class="sec-t">${title}</h2><div class="card divided">${rows
        .map((r) => `<div class="hrow"><span class="lbl">${esc(r.label)}</span><span class="grow">${bar(r.v ?? 0, 100)}</span><span class="num w3 end strong">${r.v === null ? '—' : Math.round(r.v)}</span></div>`)
        .join('')}</div></div>`;
    return `<div class="page-h"><div><h1>נתונים ומגמות</h1><p>מבוסס רק על מה שהזנת</p></div></div>
    <div class="mb">${seg('statRange', A.statRange, [
        ['7', '7 ימים'],
        ['30', '30 ימים'],
        ['90', '90 ימים'],
    ], undefined, true)}</div>
    <div class="stats four">${stat('ממוצע ציון', avg === null ? '—' : Math.round(avg))}${stat('ימים מעל הסף', `${above}/${n}`, `סף ${W().streakThreshold}`)}${stat('רצף נוכחי', dayStreak(series, W().streakThreshold, A.today), `שיא ${bestDayStreak(series, W().streakThreshold)}`)}${stat('ביצוע משימות', planned ? `${Math.round((done / planned) * 100)}%` : '—', `${done}/${planned}`)}</div>
    <h2 class="sec-t">ציון יומי</h2>
    <div class="card chart">${hasScores ? lineChart(inRange, W().streakThreshold) : '<p class="empty-chart">עדיין אין מספיק נתונים. הגרף יתמלא אחרי כמה ימים של סימון משימות.</p>'}</div>
    <div class="two">
      <div><h2 class="sec-t">ממוצע לפי יום בשבוע</h2><div class="card chart">${hasScores ? weekdayChart(wdAvg, W().weekStart) : '<p class="empty-chart">אין נתונים בטווח.</p>'}</div></div>
      <div><h2 class="sec-t">ביצוע לפי קטגוריה</h2><div class="card pad stack">${cats.length
        ? cats
            .slice(0, 7)
            .map((c) => `<div><div class="row-between small"><span class="t">${esc(c.categoryId ? (categoryById(c.categoryId)?.name ?? 'קטגוריה שנמחקה') : 'ללא קטגוריה')}</span><span class="num mu">${Math.round(c.rate * 100)}%</span></div>${bar(c.rate, 1)}</div>`)
            .join('')
        : '<p class="mu small">אין נתונים בטווח.</p>'}</div></div>
    </div>
    <h2 class="sec-t">הרגלים ומשימות חוזרות</h2>
    ${habits.length
        ? `<div class="card divided">${habits
            .map((h) => `<div class="hrow"><span class="grow t">${esc(h.t.title)}</span><span class="w6">${bar(h.r ?? 0, 1)}</span><span class="num w3 end mu">${h.r === null ? '—' : Math.round(h.r * 100) + '%'}</span><span class="inl w3 end"><span class="${h.s ? 'c-warn' : 'c-faint'}">${I.flame(13)}</span><span class="num">${h.s}</span></span></div>`)
            .join('')}</div>`
        : '<div class="card empty"><p class="e-t">אין הרגלים עדיין</p></div>'}
    ${postponed.length
        ? `<h2 class="sec-t">נדחות שוב ושוב (30 יום)</h2><div class="card divided">${postponed
            .map((p) => `<div class="hrow"><span class="grow t">${esc(S.tasks.find((t) => t.id === p.taskId)?.title ?? 'משימה שנמחקה')}</span><span class="num c-warn">${p.moves} דחיות</span></div>`)
            .join('')}<p class="hrow small mu">משימה שנדחית 3 פעמים ומעלה: תפרק אותה לצעד קטן, תשבץ אותה לבוקר, או תחליט שהיא לא חשובה ותמחק.</p></div>`
        : ''}
    <div class="two">${report('דוח שבועי (ממוצע)', weeks)}${report('דוח חודשי (ממוצע)', months)}</div>`;
}
export function viewSummary(date) {
    const s = buildDaySummary({ date, today: A.today, minutesNow: A.minutesNow, tasks: liveTasks(), logs: logsArr(), settings: W(), snapshots: snapshotMap() });
    const day = dayEntry(date);
    if (A.sum.date !== date)
        A.sum = { date, journal: null, blockers: null, picked: {} };
    const journal = A.sum.journal ?? day.journal;
    const blockers = A.sum.blockers ?? day.blockers;
    const crit = s.importantOpen.filter((i) => i.task.importance === 'critical').length;
    const coach = coachMessage({
        score: s.snapshot.score,
        avg7: s.avg7,
        streak: s.streak,
        threshold: W().streakThreshold,
        criticalOpen: crit,
        criticalMissed: crit,
        recovery: s.recovery,
        overloaded: s.tomorrow.overloaded,
        dayOver: true,
    });
    const delta = s.avg7 !== null && s.snapshot.score !== null ? s.snapshot.score - s.avg7 : null;
    const picked = A.sum.picked;
    const nSel = Object.values(picked).filter(Boolean).length;
    const cap = W().dailyCapacityMin;
    return `<div class="page-h"><div><h1>סיכום יום</h1><p>${esc(relDay(date, A.today))} · ${esc(formatHebrewDate(date))}</p></div>
    <div class="inl"><a class="icon-btn" href="#/summary/${addDays(date, -1)}" aria-label="יום קודם">${I.prev()}</a>${date < A.today ? `<a class="icon-btn" href="#/summary/${addDays(date, 1)}" aria-label="יום הבא">${I.next()}</a>` : `<span class="icon-btn disabled" aria-hidden="true">${I.next()}</span>`}</div></div>
    <section class="card sum-hero">${ring(s.snapshot.score, 124)}<div class="grow"><p class="coach big ${coach.tone}">${esc(coach.text)}</p>${day.summaryGeneratedAt
        ? `<p class="small mu">נסגר ב־${new Date(day.summaryGeneratedAt).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit', timeZone: W().timezone })} · נוסחה ${esc(day.scoreSnapshot?.formulaVersion ?? FORMULA_VERSION)}</p>`
        : ''}</div></section>
    <div class="stats four">${stat('הושלמו', `${s.done}/${s.planned}`)}${stat('רצף', s.streak, `סף ${W().streakThreshold}`)}${stat('ממוצע 7 ימים', s.avg7 === null ? '—' : Math.round(s.avg7), delta === null ? undefined : `${delta >= 0 ? '+' : ''}${Math.round(delta)} מול הממוצע`)}${stat('ממוצע 30 ימים', s.avg30 === null ? '—' : Math.round(s.avg30))}</div>
    ${s.numeric.length
        ? `<h2 class="sec-t">יעדים מספריים</h2><div class="card divided">${s.numeric
            .map((n) => `<div class="hrow"><span class="grow t">${esc(n.task.title)}</span><span class="w5">${bar(n.value, n.target)}</span><span class="num end small ${n.met ? 'c-accent' : 'mu'}">${fmtNum(n.value, 2)} / ${fmtNum(n.target, 2)} ${esc(n.task.measure === 'duration' ? 'דק׳' : (n.task.unit ?? ''))}</span></div>`)
            .join('')}</div>`
        : ''}
    ${s.importantOpen.length
        ? `<h2 class="sec-t">חשובות שלא הושלמו</h2><div class="card divided">${s.importantOpen
            .map((i) => `<div class="hrow"><span class="grow t">${esc(i.task.title)}</span><span class="small ${i.task.importance === 'critical' ? 'c-danger' : 'c-warn'}">${IMPORTANCE_LABEL[i.task.importance]}</span></div>`)
            .join('')}</div>`
        : ''}
    <h2 class="sec-t">פירוט הציון</h2>
    <div class="card scroll-x"><table><thead><tr><th>משימה</th><th class="c">משקל</th><th class="c">ביצוע</th><th class="e">תרומה</th></tr></thead><tbody>${s.snapshot.lines.length
        ? s.snapshot.lines
            .map((l) => `<tr class="${l.excluded ? 'c-faint' : ''}"><td>${esc(l.title)}${l.excluded ? ' (לא נכלל)' : l.reason === 'moved' ? ' (הועבר)' : ''}</td><td class="c num">${fmtNum(l.weight)}</td><td class="c num">${l.excluded ? '—' : Math.round(l.ratio * 100) + '%'}</td><td class="e num">${l.excluded ? '—' : fmtNum(l.contribution, 2)}</td></tr>`)
            .join('')
        : '<tr><td colspan="4" class="mu">אין משימות ביום הזה</td></tr>'}</tbody><tfoot><tr><td colspan="3" class="num">100 × ${fmtNum(s.snapshot.earned, 2)} / ${fmtNum(s.snapshot.totalWeight, 2)}</td><td class="e num">${s.snapshot.score === null ? 'אין נתונים' : fmtNum(s.snapshot.score)}</td></tr></tfoot></table></div>
    ${s.proposals.length
        ? `<h2 class="sec-t">מה שלא הושלם — להעביר?</h2><div class="card divided">${s.proposals
            .map((p) => {
            const id = p.item.task.id;
            const on = !!picked[id];
            return `<div class="hrow wrap"><button type="button" class="box ${on ? 'on' : ''}" role="checkbox" aria-checked="${on}" data-a="sum-pick" data-task="${id}" data-sug="${p.suggestion.date}" aria-label="העבר: ${esc(p.item.task.title)}">${on ? I.check(12) : ''}</button><span class="grow t">${esc(p.item.task.title)}</span>${on
                ? `<input type="date" class="field date-sm" id="sum-d-${id}" value="${esc(picked[id])}" min="${addDays(date, 1)}" data-bind="sumDate" data-task="${id}" aria-label="תאריך יעד">`
                : `<span class="small mu">הצעה: ${esc(relDay(p.suggestion.date, A.today))}</span>`}</div>`;
        })
            .join('')}</div>
          ${s.proposals[0]?.afterTheFact ? '<p class="small mu note">העברה אחרי שעת הסיכום לא מוחקת את המשימה מהיום. היא נספרת כ־0, כדי שהציון יישאר אמין.</p>' : ''}
          <button type="button" class="btn primary mt" data-a="sum-move" data-date="${date}" ${nSel ? '' : 'disabled'}>אשר העברה (${nSel})</button>`
        : ''}
    <h2 class="sec-t">מחר — ${esc(formatHebrewDate(s.tomorrow.date, false))}</h2>
    <div class="card pad"><div class="row-between small"><span>${s.tomorrow.items.length} משימות · ${minutesText(s.tomorrow.load)}</span>${s.tomorrow.overloaded ? '<span class="c-danger strong">מעל הקיבולת</span>' : ''}</div>
      ${cap > 0 ? bar(s.tomorrow.load, cap, s.tomorrow.overloaded ? 'danger' : '') : ''}
      ${s.recovery ? '<p class="small c-warn mt">שלושה ימים מתחת לסף: תשאיר למחר רק את הקריטי ואת החשוב ביותר. את השאר העבר מתוך מסך מחר.</p>' : ''}
      <a class="link mt-s" href="#/day/${s.tomorrow.date}">פתח את מחר לתכנון</a></div>
    <h2 class="sec-t">חסמים ויומן</h2>
    <div class="stack">
      <div class="fld"><label class="label" for="sum-blockers">מה עצר אותך היום?</label><textarea class="field" id="sum-blockers" rows="2" maxlength="2000" data-bind="sumBlockers" placeholder="עייפות, הסחות, עומס, תכנון לא מציאותי…">${esc(blockers)}</textarea></div>
      <div class="fld"><label class="label" for="sum-journal">יומן</label><textarea class="field" id="sum-journal" rows="4" maxlength="10000" data-bind="sumJournal" placeholder="מה עבד, מה לומדים, מה משנים מחר">${esc(journal)}</textarea></div>
    </div>
    <div class="sticky-cta"><button type="button" class="btn primary full lg" data-a="close-day" data-date="${date}">${day.summaryGeneratedAt ? 'עדכן סיכום' : 'סגור את היום ושמור ציון'}</button></div>`;
}
const TIMEZONES = ['Asia/Jerusalem', 'Europe/London', 'Europe/Berlin', 'Europe/Athens', 'America/New_York', 'America/Chicago', 'America/Los_Angeles', 'Asia/Dubai', 'Asia/Bangkok', 'Australia/Sydney', 'UTC'];
export const SWATCHES = ['#2DB5A3', '#3B82F6', '#8B5CF6', '#0EA5E9', '#F59E0B', '#EC4899', '#64748B', '#22C55E', '#EF4444', '#A16207'];
export function viewSettings() {
    const st = W();
    const e = A.settingsErrors;
    let deviceTz = 'Asia/Jerusalem';
    try {
        deviceTz = Intl.DateTimeFormat().resolvedOptions().timeZone || deviceTz;
    }
    catch {
    }
    const tzs = [...new Set([st.timezone, deviceTz, ...TIMEZONES])];
    const errP = (k) => (e[k] ? `<p class="err" role="alert">${esc(e[k])}</p>` : '');
    const cats = liveCategories(true);
    return `<div class="page-h"><div><h1>הגדרות</h1></div></div>
    <h2 class="sec-t">שמירת נתונים</h2>
    <div class="card pad stack small">
      <div class="row-between"><span class="mu">איפה הנתונים נשמרים</span><span class="inl">${I.device()} ${S.persistent ? 'במכשיר הזה בלבד' : 'זמנית (הדפדפן חוסם שמירה)'}</span></div>
      <p class="mu">אין סנכרון בין מכשירים בגרסה הזו. ייצא גיבוי מדי פעם, ותוכל לשחזר אותו בכל מכשיר.</p>
    </div>
    <h2 class="sec-t">מראה</h2>
    <div class="card pad">${seg('theme', st.theme, [
        ['system', 'לפי המכשיר'],
        ['dark', 'כהה'],
        ['light', 'בהיר'],
    ])}</div>
    <h2 class="sec-t">היום שלי</h2>
    <form class="card pad stack" data-submit="settings" novalidate>
      <div class="grid2">
        <div class="fld"><label class="label" for="set-time">שעת סיכום יומי</label><input class="field" id="set-time" name="summaryTime" type="time" value="${esc(st.summaryTime)}">${errP('summaryTime')}</div>
        <div class="fld"><label class="label" for="set-cap">קיבולת יומית (שעות)</label><input class="field num" id="set-cap" name="capacity" type="number" inputmode="decimal" min="0" max="24" step="0.5" value="${Math.round((st.dailyCapacityMin / 60) * 10) / 10}"><p class="hint">0 = בלי בדיקת עומס</p>${errP('dailyCapacityMin')}</div>
        <div class="fld"><label class="label" for="set-thr">סף רצף (ציון)</label><input class="field num" id="set-thr" name="threshold" type="number" inputmode="numeric" min="0" max="100" value="${st.streakThreshold}">${errP('streakThreshold')}</div>
        <div class="fld"><label class="label" for="set-tz">אזור זמן</label><select class="field" id="set-tz" name="timezone">${tzs.map((t) => `<option ${t === st.timezone ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select>${errP('timezone')}</div>
      </div>
      <div><span class="label">משקלי ציון</span><div class="grid3">${['normal', 'important', 'critical']
        .map((k) => `<div class="fld"><label class="label" for="set-w-${k}">${IMPORTANCE_LABEL[k]}</label><input class="field num" id="set-w-${k}" name="w-${k}" type="number" inputmode="decimal" min="0.1" max="10" step="0.5" value="${st.weights[k]}">${errP(`weights.${k}`)}</div>`)
        .join('')}</div>
        <p class="hint">ציון = 100 × Σ(משקל × ביצוע) / Σ(משקל). ביצוע מספרי מוגבל ל־100%. "לא רלוונטי" לא נספר. נוסחה ${FORMULA_VERSION}.</p></div>
      <button type="submit" class="btn primary">שמירת הגדרות</button>
    </form>
    <h2 class="sec-t">תזכורות</h2>
    <div class="card pad"><button type="button" class="toggle-row" role="switch" aria-checked="${st.remindersEnabled}" data-a="reminders"><span><span class="d">תזכורת לסיכום היומי</span><span class="d small mu">בשעה ${esc(st.summaryTime)}, כשהאפליקציה פתוחה או פעילה ברקע</span></span><span class="sw ${st.remindersEnabled ? 'on' : ''}"></span></button></div>
    <h2 class="sec-t">קטגוריות</h2>
    <div class="card divided">${cats
        .map((c) => `<div class="hrow ${c.archived ? 'dim' : ''}"><select class="swatch" style="background:${esc(c.color)}" data-bind="catColor" data-cat="${c.id}" aria-label="צבע לקטגוריה ${esc(c.name)}">${[...new Set([c.color, ...SWATCHES])]
        .map((s) => `<option value="${s}" ${s === c.color ? 'selected' : ''}>${s}</option>`)
        .join('')}</select><input class="bare grow" id="cat-${c.id}" value="${esc(c.name)}" maxlength="60" data-bind="catName" data-cat="${c.id}" aria-label="שם קטגוריה"><button type="button" class="btn ghost sm" data-a="cat-archive" data-cat="${c.id}">${c.archived ? 'החזר' : 'הסתר'}</button></div>`)
        .join('')}
      <form class="hrow wrap" data-submit="new-cat"><input class="field grow" id="new-cat" name="name" placeholder="קטגוריה חדשה" maxlength="60" aria-label="שם קטגוריה חדשה" autocomplete="off"><button type="submit" class="btn sm">${I.plus(15)} הוסף</button></form></div>
    <h2 class="sec-t">גיבוי ושחזור</h2>
    <div class="card pad inl wrap gap">
      <button type="button" class="btn sm" data-a="export-json">ייצוא גיבוי מלא (JSON)</button>
      <button type="button" class="btn sm" data-a="export-csv">ייצוא ביצועים (CSV)</button>
      <button type="button" class="btn sm" data-a="import">שחזור מגיבוי</button>
      <input type="file" id="import-file" accept="application/json,.json" hidden>
    </div>
    <h2 class="sec-t">אזור מסוכן</h2>
    <div class="card pad stack danger-zone"><p class="small mu">מחיקה לצמיתות של כל הנתונים במכשיר הזה. מומלץ לייצא גיבוי קודם.</p><div><button type="button" class="btn danger sm" data-a="wipe">מחיקת כל הנתונים</button></div></div>
    <p class="foot">SA · משמעת · גרסה 0.2.0 · נוסחת ציון ${FORMULA_VERSION}</p>`;
}
