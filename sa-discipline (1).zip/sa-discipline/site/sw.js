/* Service worker: makes the app open and work with no internet.
   App files are precached; fonts are cached as they load. */
const VERSION = 'ff56f57f11';
const CACHE = `sa-${VERSION}`;
const FONT_CACHE = 'sa-fonts';
const ASSETS = ["./","icons/apple-touch-icon.png","icons/icon-192.png","icons/icon-512-maskable.png","icons/icon-512.png","img/logo-dark.png","img/logo-light.png","index.html","js/src/core/backup.js","js/src/core/coach.js","js/src/core/dates.js","js/src/core/factories.js","js/src/core/goals.js","js/src/core/patterns.js","js/src/core/planning.js","js/src/core/recurrence.js","js/src/core/score.js","js/src/core/streaks.js","js/src/core/summary.js","js/src/core/types.js","js/src/core/validation.js","js/src/ui/labels.js","js/web/src/app.js","js/web/src/main.js","js/web/src/sheets.js","js/web/src/store.js","js/web/src/ui.js","js/web/src/views.js","manifest.webmanifest","styles.css","theme.js"];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((c) => c.addAll(ASSETS))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('sa-') && k !== CACHE && k !== FONT_CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Google Fonts: cache first, refresh in the background.
  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    event.respondWith(
      caches.open(FONT_CACHE).then(async (c) => {
        const hit = await c.match(req);
        const net = fetch(req)
          .then((res) => {
            if (res.ok || res.type === 'opaque') c.put(req, res.clone());
            return res;
          })
          .catch(() => hit);
        return hit || net;
      }),
    );
    return;
  }

  if (url.origin !== self.location.origin) return;

  // Page navigations: network first (fresh deploys), cached shell when offline.
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put('./', copy));
          return res;
        })
        .catch(() => caches.match('./').then((r) => r || caches.match('index.html'))),
    );
    return;
  }

  // App files: cache first (versioned per deploy).
  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then(
      (hit) =>
        hit ||
        fetch(req).then((res) => {
          if (res.ok) {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
          return res;
        }),
    ),
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const c of list) if ('focus' in c) return c.focus();
      return self.clients.openWindow('./#/summary');
    }),
  );
});
