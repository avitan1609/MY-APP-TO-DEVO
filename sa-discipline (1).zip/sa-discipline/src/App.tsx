import { useEffect, useState } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthScreen } from './screens/AuthScreen';
import { DayScreen } from './screens/DayScreen';
import { GoalsScreen } from './screens/GoalsScreen';
import { Onboarding } from './screens/Onboarding';
import { SettingsScreen } from './screens/SettingsScreen';
import { StatsScreen } from './screens/StatsScreen';
import { SummaryScreen } from './screens/SummaryScreen';
import { TasksScreen } from './screens/TasksScreen';
import { WeekScreen } from './screens/WeekScreen';
import { AppProvider, useApp } from './state/app';
import { AuthProvider, useAuth } from './state/auth';
import { ToastProvider } from './ui/kit';
import { Logo } from './ui/Logo';
import { Shell } from './ui/Shell';

export function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <Gate />
      </AuthProvider>
    </ToastProvider>
  );
}

/** Splash stays at least 700ms so the logo animation is not a flicker. */
function useMinDelay(ms: number) {
  const [done, setDone] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setDone(true), ms);
    return () => clearTimeout(t);
  }, [ms]);
  return done;
}

function Gate() {
  const { status, account } = useAuth();
  const minDone = useMinDelay(700);
  if (status === 'loading' || !minDone) return <Splash />;
  if (status === 'signedOut' || !account) return <AuthScreen />;
  return (
    <AppProvider key={account.id} account={account}>
      <Ready />
    </AppProvider>
  );
}

function Ready() {
  const { ready } = useApp();
  if (!ready) return <Splash />;
  return (
    <BrowserRouter>
      <Shell>
        <Routes>
          <Route path="/" element={<DayScreen />} />
          <Route path="/day/:date" element={<DayScreen />} />
          <Route path="/week" element={<WeekScreen />} />
          <Route path="/tasks" element={<TasksScreen />} />
          <Route path="/goals" element={<GoalsScreen />} />
          <Route path="/stats" element={<StatsScreen />} />
          <Route path="/summary" element={<SummaryScreen />} />
          <Route path="/summary/:date" element={<SummaryScreen />} />
          <Route path="/settings" element={<SettingsScreen />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Shell>
      <Onboarding />
    </BrowserRouter>
  );
}

function Splash() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-4" role="status" aria-label="טוען">
      <Logo size={120} className="animate-logo-in" />
      <div className="h-0.5 w-16 overflow-hidden rounded-full bg-line">
        <div className="h-full w-1/2 animate-pulse rounded-full bg-accent" />
      </div>
    </div>
  );
}
