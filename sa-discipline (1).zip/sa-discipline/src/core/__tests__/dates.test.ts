import { describe, expect, it } from 'vitest';
import {
  addDays,
  diffDays,
  formatHebrewDate,
  isISODate,
  isValidTimeZone,
  minutesNowIn,
  parseHHMM,
  startOfWeek,
  todayIn,
  weekDates,
  weekday,
} from '../dates';

const TZ = 'Asia/Jerusalem';

describe('dates & time zones', () => {
  it('validates ISO dates strictly', () => {
    expect(isISODate('2026-02-28')).toBe(true);
    expect(isISODate('2026-02-29')).toBe(false);
    expect(isISODate('2028-02-29')).toBe(true);
    expect(isISODate('2026-13-01')).toBe(false);
    expect(isISODate('15/10/2026')).toBe(false);
  });

  it('adds days across month, year and DST boundaries', () => {
    expect(addDays('2026-10-31', 1)).toBe('2026-11-01');
    expect(addDays('2026-12-31', 1)).toBe('2027-01-01');
    expect(addDays('2026-10-24', 2)).toBe('2026-10-26'); // DST ends 25 Oct in Israel
    expect(addDays('2026-03-26', 2)).toBe('2026-03-28'); // DST starts 27 Mar
    expect(diffDays('2026-11-01', '2026-10-01')).toBe(31);
  });

  it('week starts on Sunday', () => {
    expect(weekday('2026-10-11')).toBe(0);
    expect(startOfWeek('2026-10-15', 0)).toBe('2026-10-11');
    expect(startOfWeek('2026-10-11', 0)).toBe('2026-10-11');
    expect(startOfWeek('2026-10-17', 0)).toBe('2026-10-11');
    expect(weekDates('2026-10-15')[6]).toBe('2026-10-17');
  });

  it('today in the user time zone, not UTC', () => {
    // 21:30 UTC on Oct 15 is 00:30 Oct 16 in Israel (UTC+3, summer time)
    expect(todayIn(TZ, new Date('2026-10-15T21:30:00Z'))).toBe('2026-10-16');
    expect(todayIn('UTC', new Date('2026-10-15T21:30:00Z'))).toBe('2026-10-15');
    // After DST ends (UTC+2): 22:30 UTC on Oct 26 is 00:30 Oct 27
    expect(todayIn(TZ, new Date('2026-10-26T22:30:00Z'))).toBe('2026-10-27');
    expect(todayIn(TZ, new Date('2026-10-26T21:30:00Z'))).toBe('2026-10-26');
  });

  it('minutes since midnight in the user time zone', () => {
    expect(minutesNowIn(TZ, new Date('2026-10-15T18:30:00Z'))).toBe(21 * 60 + 30);
    expect(minutesNowIn(TZ, new Date('2026-10-15T21:00:00Z'))).toBe(0);
    expect(minutesNowIn(TZ, new Date('2026-12-15T18:30:00Z'))).toBe(20 * 60 + 30); // winter UTC+2
  });

  it('parses HH:MM', () => {
    expect(parseHHMM('21:30')).toBe(1290);
    expect(parseHHMM('00:00')).toBe(0);
    expect(parseHHMM('24:00')).toBeNull();
    expect(parseHHMM('9:30')).toBeNull();
  });

  it('time zone validation', () => {
    expect(isValidTimeZone('Asia/Jerusalem')).toBe(true);
    expect(isValidTimeZone('Mars/Olympus')).toBe(false);
  });

  it('formats Hebrew dates', () => {
    expect(formatHebrewDate('2026-10-15')).toContain('באוקטובר');
    expect(formatHebrewDate('2026-10-15')).toContain('חמישי');
  });
});
