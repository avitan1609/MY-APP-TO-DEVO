import { defaultSettings, newLog, newTask } from '../factories';
import type { ISODate, Settings, Task, TaskLog } from '../types';

export const U = 'user-1';

export function task(p: Partial<Task> = {}, today: ISODate = '2026-10-15'): Task {
  return newTask(U, today, { title: 'משימה', ...p });
}

export function log(t: Task, date: ISODate, p: Partial<TaskLog> = {}): TaskLog {
  return newLog(U, t.id, date, p);
}

export function done(t: Task, date: ISODate, value?: number): TaskLog {
  return log(t, date, { status: 'done', value: value ?? null });
}

export function settings(p: Partial<Settings> = {}): Settings {
  return { ...defaultSettings(U, 'Asia/Jerusalem'), ...p };
}
