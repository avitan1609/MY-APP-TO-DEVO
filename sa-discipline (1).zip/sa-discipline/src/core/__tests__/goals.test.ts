import { describe, expect, it } from 'vitest';
import { newGoal } from '../factories';
import { goalProgress } from '../goals';
import { done, log, task } from './fixtures';

const g = (p: Parameters<typeof newGoal>[2]) => newGoal('user-1', '2026-10-01', { title: 'g', startDate: '2026-10-01', endDate: '2026-10-31', ...p });

describe('goal progress', () => {
  it('manual', () => {
    const p = goalProgress(g({ progressMode: 'manual', target: 12, currentValue: 3 }), [], [], '2026-10-16');
    expect(p.ratio).toBe(0.25);
    expect(p.expected).toBeCloseTo(16 / 31);
  });

  it('linked sum of values within the period', () => {
    const goal = g({ progressMode: 'linked_sum', target: 100, unit: 'ק"מ' });
    const run = task({ goalId: goal.id, kind: 'recurring', date: null, measure: 'numeric', target: 5, unit: 'ק"מ', recurrence: { type: 'daily', startDate: '2026-09-01' } });
    const logs = [log(run, '2026-09-30', { status: 'done', value: 50 }), log(run, '2026-10-02', { status: 'done', value: 8 }), log(run, '2026-10-03', { status: 'partial', value: 4.5 })];
    expect(goalProgress(goal, [run], logs, '2026-10-16').current).toBe(12.5);
  });

  it('linked completion counts past recurring + all dated one-time tasks', () => {
    const goal = g({ progressMode: 'linked_completion' });
    const habit = task({ goalId: goal.id, kind: 'habit', date: null, recurrence: { type: 'weekly', weekdays: [4], startDate: '2026-10-01' } });
    const report = task({ goalId: goal.id, date: '2026-10-28' });
    // Thursdays to Oct 15: 1, 8, 15 → 3 occurrences; plus 1 one-time = 4
    const p = goalProgress(goal, [habit, report], [done(habit, '2026-10-01'), done(habit, '2026-10-08')], '2026-10-15');
    expect(p.target).toBe(4);
    expect(p.current).toBe(2);
    expect(p.ratio).toBe(0.5);
  });
});
