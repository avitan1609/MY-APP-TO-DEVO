import { describe, expect, it } from 'vitest';
import {
  dayLoad,
  isAfterTheFact,
  isOverloaded,
  loadForFactory,
  overloadAlternatives,
  planMove,
  sortItems,
  suggestDate,
} from '../planning';
import { plannedItemsForDate } from '../recurrence';
import { done, log, task } from './fixtures';

const D = '2026-10-15';

describe('planning', () => {
  it('sorts critical first, completed last', () => {
    const a = task({ title: 'a', importance: 'normal', urgency: 'high' });
    const b = task({ title: 'b', importance: 'critical', urgency: 'low' });
    const c = task({ title: 'c', importance: 'important' });
    const d = task({ title: 'd', importance: 'critical' });
    const items = plannedItemsForDate([a, b, c, d], [done(d, D)], D);
    expect(sortItems(items).map((i) => i.task.title)).toEqual(['b', 'a', 'c', 'd']);
  });

  it('computes load and detects overload', () => {
    const items = plannedItemsForDate([task({ estMinutes: 120 }), task({ estMinutes: 300 }), task({ estMinutes: null })], [], D);
    expect(dayLoad(items)).toBe(420);
    expect(isOverloaded(items, 360)).toBe(true);
    expect(isOverloaded(items, 0)).toBe(false); // capacity 0 = disabled
  });

  it('remaining load excludes completed and cancelled', () => {
    const a = task({ estMinutes: 60 });
    const b = task({ estMinutes: 30 });
    const c = task({ estMinutes: 45 });
    const items = plannedItemsForDate([a, b, c], [done(a, D), log(b, D, { status: 'not_relevant' })], D);
    expect(dayLoad(items, true)).toBe(45);
    expect(dayLoad(items)).toBe(105);
  });

  it('overload alternatives: least important first, never critical or due today', () => {
    const crit = task({ title: 'crit', importance: 'critical', estMinutes: 200 });
    const due = task({ title: 'due', estMinutes: 100, deadline: D });
    const low = task({ title: 'low', importance: 'normal', urgency: 'low', estMinutes: 60 });
    const imp = task({ title: 'imp', importance: 'important', estMinutes: 90 });
    const items = plannedItemsForDate([crit, due, low, imp], [], D);
    expect(overloadAlternatives(items, 400).map((i) => i.task.title)).toEqual(['low']);
    expect(overloadAlternatives(items, 300).map((i) => i.task.title)).toEqual(['low', 'imp']);
    expect(overloadAlternatives(items, 1000)).toEqual([]);
  });

  it('suggests the first day with free capacity', () => {
    const t = task({ estMinutes: 60 });
    const loads: Record<string, number> = { '2026-10-16': 350, '2026-10-17': 100 };
    const s = suggestDate(t, D, (d) => loads[d] ?? 0, 360);
    expect(s).toEqual({ date: '2026-10-17', fits: true, beforeDeadline: true });
  });

  it('respects the deadline: least-loaded day before it when nothing fits', () => {
    const t = task({ estMinutes: 120, deadline: '2026-10-17' });
    const loads: Record<string, number> = { '2026-10-16': 340, '2026-10-17': 300 };
    expect(suggestDate(t, D, (d) => loads[d] ?? 0, 360)).toEqual({ date: '2026-10-17', fits: false, beforeDeadline: true });
  });

  it('skips days where a recurring task already occurs', () => {
    const t = task({ kind: 'recurring', date: null, estMinutes: 10, recurrence: { type: 'weekly', weekdays: [4, 5], startDate: '2026-10-01' } });
    expect(suggestDate(t, D, () => 0, 360).date).toBe('2026-10-17'); // Fri 16 already has it
  });

  it('load factory uses real planned items', () => {
    const a = task({ date: '2026-10-16', estMinutes: 45 });
    expect(loadForFactory([a], [])('2026-10-16')).toBe(45);
  });

  it('after-the-fact rule: past days and today after summary time', () => {
    expect(isAfterTheFact('2026-10-14', D, 600, '21:30')).toBe(true);
    expect(isAfterTheFact(D, D, 600, '21:30')).toBe(false);
    expect(isAfterTheFact(D, D, 21 * 60 + 30, '21:30')).toBe(true);
    expect(isAfterTheFact('2026-10-16', D, 23 * 60, '21:30')).toBe(false);
  });

  it('planMove: one-time moves its date; after the fact leaves a counted log', () => {
    const t = task();
    expect(planMove(t, D, '2026-10-16', false)).toEqual({ taskPatch: { date: '2026-10-16' }, logs: [] });
    const m = planMove(t, D, '2026-10-16', true);
    expect(m.logs[0]).toMatchObject({ date: D, status: 'moved', counted: true, movedTo: '2026-10-16' });
  });

  it('planMove: recurring creates source + extra target logs; rejects collisions', () => {
    const t = task({ kind: 'recurring', date: null, recurrence: { type: 'daily', startDate: '2026-10-01' } });
    expect(() => planMove(t, D, '2026-10-16', false)).toThrow();
    const w = task({ kind: 'habit', date: null, recurrence: { type: 'weekly', weekdays: [4], startDate: '2026-10-01' } });
    const m = planMove(w, D, '2026-10-17', false);
    expect(m.taskPatch).toBeNull();
    expect(m.logs).toHaveLength(2);
    expect(m.logs[1]).toMatchObject({ date: '2026-10-17', extra: true, status: 'pending' });
  });
});
