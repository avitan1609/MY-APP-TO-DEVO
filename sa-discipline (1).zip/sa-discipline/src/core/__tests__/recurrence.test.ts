import { describe, expect, it } from 'vitest';
import { range } from '../dates';
import { isScheduledOn, plannedItemsForDate, recurrenceMatches } from '../recurrence';
import { log, task } from './fixtures';

describe('recurrence', () => {
  it('daily from start date, respects end date', () => {
    const r = { type: 'daily' as const, startDate: '2026-10-10', endDate: '2026-10-12' };
    expect(recurrenceMatches(r, '2026-10-09')).toBe(false);
    expect(recurrenceMatches(r, '2026-10-10')).toBe(true);
    expect(recurrenceMatches(r, '2026-10-12')).toBe(true);
    expect(recurrenceMatches(r, '2026-10-13')).toBe(false);
  });

  it('weekly on Sun/Tue/Thu', () => {
    const r = { type: 'weekly' as const, weekdays: [0, 2, 4], startDate: '2026-10-01' };
    // 2026-10-11 is a Sunday
    const hits = range('2026-10-11', '2026-10-17').filter((d) => recurrenceMatches(r, d));
    expect(hits).toEqual(['2026-10-11', '2026-10-13', '2026-10-15']);
  });

  it('every 3 days from start', () => {
    const r = { type: 'interval' as const, interval: 3, startDate: '2026-10-01' };
    const hits = range('2026-10-01', '2026-10-10').filter((d) => recurrenceMatches(r, d));
    expect(hits).toEqual(['2026-10-01', '2026-10-04', '2026-10-07', '2026-10-10']);
  });

  it('monthly day 31 clamps to last day of short months, incl. leap year', () => {
    const r = { type: 'monthly' as const, monthDay: 31, startDate: '2027-01-01' };
    expect(recurrenceMatches(r, '2027-01-31')).toBe(true);
    expect(recurrenceMatches(r, '2027-02-28')).toBe(true);
    expect(recurrenceMatches(r, '2027-04-30')).toBe(true);
    expect(recurrenceMatches(r, '2027-04-29')).toBe(false);
    const leap = { type: 'monthly' as const, monthDay: 30, startDate: '2028-01-01' };
    expect(recurrenceMatches(leap, '2028-02-29')).toBe(true);
    expect(recurrenceMatches(leap, '2028-02-28')).toBe(false);
  });

  it('weekly across DST change still hits the right weekday (Asia/Jerusalem DST ends 2026-10-25)', () => {
    const r = { type: 'weekly' as const, weekdays: [0], startDate: '2026-10-01' };
    expect(recurrenceMatches(r, '2026-10-25')).toBe(true);
    expect(recurrenceMatches(r, '2026-11-01')).toBe(true);
    expect(recurrenceMatches(r, '2026-10-26')).toBe(false);
  });

  it('one-time task is scheduled only on its date; backlog (null) never', () => {
    const t = task({ date: '2026-10-20' });
    expect(isScheduledOn(t, '2026-10-20')).toBe(true);
    expect(isScheduledOn(t, '2026-10-21')).toBe(false);
    expect(isScheduledOn(task({ date: null }), '2026-10-15')).toBe(false);
  });

  it('archived and deleted tasks are not scheduled', () => {
    expect(isScheduledOn(task({ archived: true }), '2026-10-15')).toBe(false);
    expect(isScheduledOn(task({ deleted: true }), '2026-10-15')).toBe(false);
  });

  it('moved occurrence leaves the source day and appears on the target day', () => {
    const t = task({ kind: 'recurring', date: null, recurrence: { type: 'weekly', weekdays: [4], startDate: '2026-10-01' } });
    const logs = [
      log(t, '2026-10-15', { status: 'moved', movedTo: '2026-10-16', counted: false }),
      log(t, '2026-10-16', { status: 'pending', extra: true }),
    ];
    expect(plannedItemsForDate([t], logs, '2026-10-15')).toHaveLength(0);
    expect(plannedItemsForDate([t], logs, '2026-10-16')).toHaveLength(1);
  });

  it('moved after the fact stays on the source day (counted as 0)', () => {
    const t = task({ date: '2026-10-16' }); // already moved to the 16th
    const logs = [log(t, '2026-10-15', { status: 'moved', movedTo: '2026-10-16', counted: true })];
    expect(plannedItemsForDate([t], logs, '2026-10-15')).toHaveLength(1);
    expect(plannedItemsForDate([t], logs, '2026-10-16')).toHaveLength(1);
  });
});
