import { describe, expect, it } from 'vitest';
import { plannedItemsForDate } from '../recurrence';
import { FORMULA_VERSION, completionRatio, computeDailyScore, displayScore } from '../score';
import { done, log, task } from './fixtures';

const D = '2026-10-15';
const W = { normal: 1, important: 2, critical: 3 };

describe('daily score', () => {
  it('weights by importance: 100 × Σ(w·r) / Σw', () => {
    const a = task({ importance: 'normal' });
    const b = task({ importance: 'important' });
    const c = task({ importance: 'critical' });
    const items = plannedItemsForDate([a, b, c], [done(c, D)], D);
    const s = computeDailyScore(items, W);
    expect(s.totalWeight).toBe(6);
    expect(s.earned).toBe(3);
    expect(s.score).toBe(50);
  });

  it('all done = 100, nothing done = 0', () => {
    const a = task();
    const b = task({ importance: 'critical' });
    expect(computeDailyScore(plannedItemsForDate([a, b], [done(a, D), done(b, D)], D), W).score).toBe(100);
    expect(computeDailyScore(plannedItemsForDate([a, b], [], D), W).score).toBe(0);
  });

  it('numeric target: partial ratio, capped at 100%', () => {
    const steps = task({ measure: 'numeric', target: 10000, unit: 'צעדים' });
    expect(completionRatio(steps, log(steps, D, { status: 'partial', value: 7500 }))).toBe(0.75);
    expect(completionRatio(steps, log(steps, D, { status: 'done', value: 25000 }))).toBe(1);
    const s = computeDailyScore(plannedItemsForDate([steps], [log(steps, D, { status: 'partial', value: 2500 })], D), W);
    expect(s.score).toBe(25);
  });

  it('over-achieving one task never compensates another', () => {
    const a = task({ measure: 'numeric', target: 10, unit: 'עמודים' });
    const b = task();
    const s = computeDailyScore(plannedItemsForDate([a, b], [log(a, D, { status: 'done', value: 100 })], D), W);
    expect(s.score).toBe(50);
  });

  it('binary partial status still counts 0', () => {
    const a = task();
    expect(completionRatio(a, log(a, D, { status: 'partial' }))).toBe(0);
  });

  it('not_relevant is excluded from the denominator', () => {
    const a = task();
    const b = task({ importance: 'critical' });
    const items = plannedItemsForDate([a, b], [done(a, D), log(b, D, { status: 'not_relevant' })], D);
    const s = computeDailyScore(items, W);
    expect(s.score).toBe(100);
    expect(s.totalWeight).toBe(1);
    expect(s.lines.find((l) => l.taskId === b.id)!.excluded).toBe(true);
  });

  it('no valid items → null, not a misleading number', () => {
    expect(computeDailyScore([], W).score).toBeNull();
    const a = task();
    const s = computeDailyScore(plannedItemsForDate([a], [log(a, D, { status: 'not_relevant' })], D), W);
    expect(s.score).toBeNull();
    expect(displayScore(s.score)).toBe('—');
  });

  it('custom weights and per-task override', () => {
    const a = task({ importance: 'critical' });
    const b = task({ weightOverride: 5 });
    const s = computeDailyScore(plannedItemsForDate([a, b], [done(a, D)], D), { normal: 1, important: 2, critical: 5 });
    expect(s.totalWeight).toBe(10);
    expect(s.score).toBe(50);
  });

  it('stores formula version, weights and breakdown for auditing', () => {
    const a = task({ title: 'קריאה' });
    const s = computeDailyScore(plannedItemsForDate([a], [done(a, D)], D), W, new Date('2026-10-15T20:00:00Z'));
    expect(s.formulaVersion).toBe(FORMULA_VERSION);
    expect(s.weights).toEqual(W);
    expect(s.lines[0]).toEqual({ taskId: a.id, title: 'קריאה', weight: 1, ratio: 1, contribution: 1, excluded: false, reason: undefined });
    expect(s.computedAt).toBe('2026-10-15T20:00:00.000Z');
  });

  it('rounds to one decimal', () => {
    const items = [task(), task(), task()];
    const s = computeDailyScore(plannedItemsForDate(items, [done(items[0], D)], D), W);
    expect(s.score).toBe(33.3);
    expect(displayScore(s.score)).toBe('33');
  });

  it('duration measure uses minutes against target', () => {
    const a = task({ measure: 'duration', target: 30 });
    expect(completionRatio(a, log(a, D, { status: 'partial', value: 15 }))).toBe(0.5);
  });
});
