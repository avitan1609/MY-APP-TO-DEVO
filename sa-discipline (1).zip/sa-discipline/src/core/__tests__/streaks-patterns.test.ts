import { describe, expect, it } from 'vitest';
import { coachMessage } from '../coach';
import { averageOver, categoryRates, frequentlyPostponed, needsRecovery, recoveryPlan, weekdayAverages } from '../patterns';
import { plannedItemsForDate } from '../recurrence';
import { bestDayStreak, dayStreak, habitCompletionRate, habitStreak } from '../streaks';
import { buildDaySummary } from '../summary';
import { done, log, settings, task } from './fixtures';

const T = '2026-10-15';
const series = (entries: Array<[string, number | null]>) => new Map(entries);

describe('day streak', () => {
  it('counts consecutive days ≥ threshold; unfinished today does not break', () => {
    const s = series([
      ['2026-10-11', 40],
      ['2026-10-12', 80],
      ['2026-10-13', 90],
      ['2026-10-14', 70],
      ['2026-10-15', 20],
    ]);
    expect(dayStreak(s, 70, T)).toBe(3);
    s.set(T, 75);
    expect(dayStreak(s, 70, T)).toBe(4);
  });

  it('null days (nothing planned) are neutral', () => {
    const s = series([
      ['2026-10-12', 80],
      ['2026-10-13', null],
      ['2026-10-14', 90],
    ]);
    expect(dayStreak(s, 70, '2026-10-14')).toBe(2);
  });

  it('best streak', () => {
    const s = series([
      ['2026-10-10', 80],
      ['2026-10-11', 80],
      ['2026-10-12', 80],
      ['2026-10-13', 10],
      ['2026-10-14', 90],
    ]);
    expect(bestDayStreak(s, 70)).toBe(3);
  });
});

describe('habit streak', () => {
  const h = task({ kind: 'habit', date: null, recurrence: { type: 'weekly', weekdays: [0, 2, 4], startDate: '2026-10-01' } });

  it('counts scheduled occurrences only', () => {
    // Sun 11, Tue 13 done; Thu 15 (today) not yet → 2
    const logs = [done(h, '2026-10-11'), done(h, '2026-10-13')];
    expect(habitStreak(h, logs, T)).toBe(2);
    expect(habitStreak(h, [...logs, done(h, T)], T)).toBe(3);
  });

  it('a missed scheduled day breaks it; cancelled day is skipped', () => {
    expect(habitStreak(h, [done(h, '2026-10-13')], '2026-10-16')).toBe(0);
    expect(habitStreak(h, [done(h, '2026-10-11'), log(h, '2026-10-13', { status: 'not_relevant' }), done(h, T)], T)).toBe(2);
  });

  it('completion rate', () => {
    expect(habitCompletionRate(h, [done(h, '2026-10-11')], '2026-10-11', '2026-10-15')).toBeCloseTo(1 / 3);
  });
});

describe('patterns', () => {
  it('weekday averages and rolling average', () => {
    const s = series([
      ['2026-10-11', 50],
      ['2026-10-18', 70],
      ['2026-10-12', 90],
    ]);
    const w = weekdayAverages(s);
    expect(w[0]).toBe(60);
    expect(w[1]).toBe(90);
    expect(w[2]).toBeNull();
    expect(averageOver(s, '2026-10-18', 7)).toBe(80); // 12th (90) + 18th (70)
  });

  it('frequently postponed tasks', () => {
    const t = task();
    const logs = ['2026-10-01', '2026-10-05', '2026-10-09'].map((d) => log(t, d, { status: 'moved' }));
    expect(frequentlyPostponed(logs, '2026-09-15')).toEqual([{ taskId: t.id, moves: 3 }]);
    expect(frequentlyPostponed(logs, '2026-10-02')).toEqual([]);
  });

  it('recovery after 3 days below threshold', () => {
    const s = series([
      ['2026-10-12', 50],
      ['2026-10-13', 40],
      ['2026-10-14', 60],
    ]);
    expect(needsRecovery(s, T, 70)).toBe(true);
    s.set('2026-10-13', 71);
    expect(needsRecovery(s, T, 70)).toBe(false);
  });

  it('recovery plan keeps critical and fits ~60% capacity', () => {
    const c = task({ importance: 'critical', estMinutes: 120 });
    const i = task({ importance: 'important', estMinutes: 60 });
    const n = task({ importance: 'normal', estMinutes: 120 });
    const plan = recoveryPlan(plannedItemsForDate([c, i, n], [], T), 300);
    expect(plan.keep.map((x) => x.task.id)).toEqual([c.id, i.id]);
    expect(plan.move.map((x) => x.task.id)).toEqual([n.id]);
  });

  it('category completion rates', () => {
    const a = task({ categoryId: 'run' });
    const b = task({ categoryId: 'run' });
    const r = categoryRates([a, b], [done(a, T)], [T], { normal: 1, important: 2, critical: 3 });
    expect(r).toEqual([{ categoryId: 'run', planned: 2, rate: 0.5 }]);
  });
});

describe('coach messages are deterministic', () => {
  const base = { score: 50, avg7: 60, streak: 0, threshold: 70, criticalOpen: 0, criticalMissed: 0, recovery: false, overloaded: false, dayOver: false };
  it('recovery wins over everything', () => {
    expect(coachMessage({ ...base, recovery: true, overloaded: true }).tone).toBe('warn');
  });
  it('end-of-day critical miss', () => {
    expect(coachMessage({ ...base, dayOver: true, criticalMissed: 1 }).text).toContain('קריטית');
  });
  it('same input → same output', () => {
    expect(coachMessage(base)).toEqual(coachMessage(base));
  });
});

describe('day summary', () => {
  it('aggregates score, counts, numeric goals, open important and proposals', () => {
    const crit = task({ title: 'crit', importance: 'critical', estMinutes: 30 });
    const steps = task({ title: 'steps', measure: 'numeric', target: 10000, unit: 'צעדים' });
    const read = task({ title: 'read' });
    const logs = [log(steps, T, { status: 'partial', value: 8000 }), done(read, T)];
    const s = buildDaySummary({ date: T, today: T, minutesNow: 22 * 60, tasks: [crit, steps, read], logs, settings: settings() });
    expect(s.planned).toBe(3);
    expect(s.done).toBe(1);
    expect(s.snapshot.score).toBe(36); // (0*3 + 0.8*1 + 1*1) / 5
    expect(s.numeric[0]).toMatchObject({ value: 8000, target: 10000, met: false });
    expect(s.importantOpen.map((i) => i.task.title)).toEqual(['crit']);
    expect(s.proposals).toHaveLength(2);
    expect(s.proposals[0].afterTheFact).toBe(true);
    expect(s.tomorrow.date).toBe('2026-10-16');
  });
});
