import { describe, expect, it } from 'vitest';
import { makeBackup, parseBackup, reownBackup } from '../backup';
import { defaultCategories, formatPace, newLog, paceMinPerKm } from '../factories';
import { fromRemote, maxCursor, resolve, toRemote } from '../syncMerge';
import { validateGoal, validateSettings, validateTask } from '../validation';
import { newGoal } from '../factories';
import { settings, task } from './fixtures';

describe('validation', () => {
  it('requires a title and sane limits', () => {
    expect(validateTask(task({ title: '  ' })).title).toBeTruthy();
    expect(validateTask(task({ title: 'x'.repeat(121) })).title).toBeTruthy();
    expect(validateTask(task({ title: 'ok' }))).toEqual({});
  });

  it('numeric tasks need target and unit', () => {
    const e = validateTask(task({ measure: 'numeric', target: null, unit: '' }));
    expect(e.target).toBeTruthy();
    expect(e.unit).toBeTruthy();
    expect(validateTask(task({ measure: 'duration', target: 30 }))).toEqual({});
  });

  it('recurring tasks need a valid rule', () => {
    expect(validateTask(task({ kind: 'recurring', recurrence: null })).recurrence).toBeTruthy();
    expect(validateTask(task({ kind: 'habit', recurrence: { type: 'weekly', weekdays: [], startDate: '2026-10-15' } })).recurrence).toBeTruthy();
    expect(validateTask(task({ kind: 'habit', recurrence: { type: 'interval', interval: 0, startDate: '2026-10-15' } })).recurrence).toBeTruthy();
    expect(validateTask(task({ kind: 'habit', recurrence: { type: 'daily', startDate: '2026-10-15', endDate: '2026-10-01' } })).recurrence).toBeTruthy();
    expect(validateTask(task({ kind: 'habit', recurrence: { type: 'weekly', weekdays: [0, 3], startDate: '2026-10-15' } }))).toEqual({});
  });

  it('deadline cannot precede planned date', () => {
    expect(validateTask(task({ date: '2026-10-15', deadline: '2026-10-14' })).deadline).toBeTruthy();
  });

  it('goals and settings', () => {
    expect(validateGoal(newGoal('u', '2026-10-15', { title: 'g', endDate: '2026-10-01' })).endDate).toBeTruthy();
    expect(validateGoal(newGoal('u', '2026-10-15', { title: 'g', progressMode: 'linked_sum', target: null })).target).toBeTruthy();
    expect(validateSettings(settings())).toEqual({});
    expect(validateSettings(settings({ summaryTime: '25:00' })).summaryTime).toBeTruthy();
    expect(validateSettings(settings({ weights: { normal: 0, important: 2, critical: 3 } }))['weights.normal']).toBeTruthy();
  });
});

describe('sync merge', () => {
  it('converts top-level keys and drops local/server-only fields', () => {
    const l = { ...newLog('u', 't1', '2026-10-15'), _dirty: 1 as const };
    const r = toRemote(l);
    expect(r.task_id).toBe('t1');
    expect(r.subtask_done).toEqual([]);
    expect('_dirty' in r).toBe(false);
    const back = fromRemote<Record<string, unknown>>({ ...r, server_updated_at: 'x', recurrence: { startDate: 'a' } });
    expect(back.taskId).toBe('t1');
    expect(back.recurrence).toEqual({ startDate: 'a' }); // inner JSON untouched
    expect('serverUpdatedAt' in back).toBe(false);
  });

  it('last write wins only when local is dirty', () => {
    const older = '2026-10-15T10:00:00.000Z';
    const newer = '2026-10-15T11:00:00.000Z';
    expect(resolve(undefined, { updatedAt: older })).toBe('take_remote');
    expect(resolve({ updatedAt: newer, _dirty: 0 }, { updatedAt: older })).toBe('take_remote');
    expect(resolve({ updatedAt: newer, _dirty: 1 }, { updatedAt: older })).toBe('keep_local');
    expect(resolve({ updatedAt: older, _dirty: 1 }, { updatedAt: newer })).toBe('take_remote');
    expect(resolve({ updatedAt: older, _dirty: 1 }, { updatedAt: older })).toBe('keep_local');
  });

  it('pull cursor advances to the max server timestamp', () => {
    expect(maxCursor(null, [{ server_updated_at: '2026-01-02' }, { server_updated_at: '2026-01-03' }])).toBe('2026-01-03');
    expect(maxCursor('2026-02-01', [{ server_updated_at: '2026-01-03' }])).toBe('2026-02-01');
  });
});

describe('backup', () => {
  const data = { categories: defaultCategories('u'), goals: [], tasks: [task()], logs: [newLog('u', 't', '2026-10-15')], days: [], settings: settings() };

  it('round-trips and re-owns rows', () => {
    const file = parseBackup(JSON.stringify(makeBackup(data)));
    expect(file.tasks).toHaveLength(1);
    const re = reownBackup(file, 'other', '2026-10-15T00:00:00.000Z');
    expect(re.tasks[0].userId).toBe('other');
    expect(re.settings!.userId).toBe('other');
  });

  it('rejects garbage and foreign files', () => {
    expect(() => parseBackup('not json')).toThrow();
    expect(() => parseBackup('{"format":"x"}')).toThrow();
    const bad = { ...makeBackup(data), logs: [{ id: 'x', updatedAt: 'y', taskId: 't', date: '15/10' }] };
    expect(() => parseBackup(JSON.stringify(bad))).toThrow();
    expect(() => parseBackup(JSON.stringify({ ...makeBackup(data), version: 99 }))).toThrow();
  });
});

describe('run pace', () => {
  it('computes min/km', () => {
    expect(paceMinPerKm(10, 50)).toBe(5);
    expect(formatPace(paceMinPerKm(5, 27.5))).toBe('5:30');
    expect(paceMinPerKm(0, 30)).toBeNull();
  });
});
