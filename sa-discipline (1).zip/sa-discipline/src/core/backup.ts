/** Export / import format. Pure validation so it can be tested without a browser. */
import { isISODate } from './dates';
import type { Category, DayEntry, Goal, Settings, Task, TaskLog } from './types';

export const BACKUP_FORMAT = 'sa-discipline-backup';
export const BACKUP_VERSION = 1;

export interface BackupData {
  categories: Category[];
  goals: Goal[];
  tasks: Task[];
  logs: TaskLog[];
  days: DayEntry[];
  settings: Settings | null;
}

export interface BackupFile extends BackupData {
  format: typeof BACKUP_FORMAT;
  version: number;
  exportedAt: string;
}

export function makeBackup(data: BackupData, now = new Date()): BackupFile {
  return { format: BACKUP_FORMAT, version: BACKUP_VERSION, exportedAt: now.toISOString(), ...data };
}

const isObj = (x: unknown): x is Record<string, unknown> => !!x && typeof x === 'object' && !Array.isArray(x);
const isStr = (x: unknown) => typeof x === 'string';

function rowsOk(arr: unknown, check: (r: Record<string, unknown>) => boolean): boolean {
  return Array.isArray(arr) && arr.every((r) => isObj(r) && isStr(r.id) && isStr(r.updatedAt) && check(r));
}

/** Throws a Hebrew error message if the file is not a valid backup. */
export function parseBackup(text: string): BackupFile {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error('הקובץ אינו JSON תקין');
  }
  if (!isObj(data) || data.format !== BACKUP_FORMAT) throw new Error('זה לא קובץ גיבוי של האפליקציה');
  if (typeof data.version !== 'number' || data.version > BACKUP_VERSION) throw new Error('גרסת גיבוי לא נתמכת');
  const ok =
    rowsOk(data.categories, (r) => isStr(r.name)) &&
    rowsOk(data.goals, (r) => isStr(r.title)) &&
    rowsOk(data.tasks, (r) => isStr(r.title) && isStr(r.kind)) &&
    rowsOk(data.logs, (r) => isStr(r.taskId) && isISODate(r.date)) &&
    rowsOk(data.days, (r) => isISODate(r.date)) &&
    (data.settings === null || isObj(data.settings));
  if (!ok) throw new Error('מבנה הקובץ פגום — הייבוא בוטל');
  return data as unknown as BackupFile;
}

/** Re-own every row to the importing user. */
export function reownBackup(b: BackupData, userId: string, now = new Date().toISOString()): BackupData {
  const re = <T extends { userId: string; updatedAt: string }>(rows: T[]) => rows.map((r) => ({ ...r, userId, updatedAt: now }));
  return {
    categories: re(b.categories),
    goals: re(b.goals),
    tasks: re(b.tasks),
    logs: re(b.logs),
    days: re(b.days),
    settings: b.settings ? { ...b.settings, userId, id: 'settings', updatedAt: now } : null,
  };
}
