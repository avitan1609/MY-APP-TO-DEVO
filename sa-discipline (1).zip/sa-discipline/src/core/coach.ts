/**
 * Coach messages — fixed templates selected by rules. Direct, demanding, respectful.
 * No AI, no randomness: the same state always yields the same message.
 */
export interface CoachContext {
  score: number | null;
  avg7: number | null;
  streak: number;
  threshold: number;
  criticalOpen: number;
  criticalMissed: number;
  recovery: boolean;
  overloaded: boolean;
  dayOver: boolean;
}

export interface CoachMessage {
  tone: 'push' | 'warn' | 'good' | 'neutral';
  text: string;
}

export function coachMessage(c: CoachContext): CoachMessage {
  if (c.recovery) {
    return {
      tone: 'warn',
      text: 'שלושה ימים מתחת לסף. בלי דרמה: מחר יום מצומצם. רק הקריטי והחשוב ביותר, ומשם בונים חזרה.',
    };
  }
  if (c.overloaded && !c.dayOver) {
    return { tone: 'warn', text: 'תכננת יותר ממה שהיום מכיל. תחליט עכשיו מה זז, לפני שהיום יחליט בשבילך.' };
  }
  if (!c.dayOver) {
    if (c.criticalOpen > 0) {
      return {
        tone: 'push',
        text: c.criticalOpen === 1 ? 'יש משימה קריטית אחת פתוחה. תתחיל ממנה. הכול אחר כך.' : `יש ${c.criticalOpen} משימות קריטיות פתוחות. תתחיל מהן, אחת אחרי השנייה.`,
      };
    }
    if (c.score !== null && c.score >= 100) return { tone: 'good', text: 'היום סגור במלואו. ככה נראה סטנדרט.' };
    if (c.streak >= 3) return { tone: 'push', text: `רצף של ${c.streak} ימים. אל תיתן ליום אחד לשבור את מה שבנית.` };
    return { tone: 'neutral', text: 'תעשה את הדבר הבא ברשימה. לא את הקל — את הבא.' };
  }
  // End of day
  if (c.score === null) return { tone: 'neutral', text: 'לא היו משימות מתוכננות היום. תכנן את מחר עכשיו.' };
  if (c.criticalMissed > 0) {
    return { tone: 'warn', text: 'משימה קריטית נשארה פתוחה. זה הדבר הראשון מחר בבוקר — לא אחרי שום דבר אחר.' };
  }
  if (c.score >= Math.max(90, c.threshold)) return { tone: 'good', text: 'יום חזק. תשמור על אותו סטנדרט מחר.' };
  if (c.score >= c.threshold) {
    return c.avg7 !== null && c.score < c.avg7
      ? { tone: 'push', text: 'עברת את הסף, אבל מתחת לממוצע שלך. אתה יודע לעשות יותר.' }
      : { tone: 'good', text: 'עמדת ביעד. עכשיו תתכנן את מחר כדי שיהיה טוב יותר.' };
  }
  return { tone: 'push', text: 'היום לא עמדת בסף. תבין מה עצר אותך, תרשום את זה, ותתכנן מחר קטן ומדויק יותר.' };
}
