/**
 * Date helpers. Calendar dates are plain YYYY-MM-DD strings interpreted in the
 * user's time zone. Arithmetic is done in UTC on the date only, so DST changes
 * never shift a calendar day.
 */
import type { ISODate } from './types';

const ISO_RE = /^(\d{4})-(\d{2})-(\d{2})$/;

export function isISODate(s: unknown): s is ISODate {
  if (typeof s !== 'string') return false;
  const m = ISO_RE.exec(s);
  if (!m) return false;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  return d.getUTCFullYear() === +m[1] && d.getUTCMonth() === +m[2] - 1 && d.getUTCDate() === +m[3];
}

function toUTC(date: ISODate): Date {
  const m = ISO_RE.exec(date);
  if (!m) throw new Error(`Invalid ISO date: ${date}`);
  return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
}

function fromUTC(d: Date): ISODate {
  const y = d.getUTCFullYear();
  const mo = String(d.getUTCMonth() + 1).padStart(2, '0');
  const da = String(d.getUTCDate()).padStart(2, '0');
  return `${y}-${mo}-${da}`;
}

export function addDays(date: ISODate, n: number): ISODate {
  const d = toUTC(date);
  d.setUTCDate(d.getUTCDate() + n);
  return fromUTC(d);
}

/** 0 = Sunday … 6 = Saturday */
export function weekday(date: ISODate): number {
  return toUTC(date).getUTCDay();
}

export function diffDays(a: ISODate, b: ISODate): number {
  return Math.round((toUTC(a).getTime() - toUTC(b).getTime()) / 86_400_000);
}

export function dayOfMonth(date: ISODate): number {
  return toUTC(date).getUTCDate();
}

export function daysInMonth(date: ISODate): number {
  const d = toUTC(date);
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
}

export function startOfWeek(date: ISODate, weekStart = 0): ISODate {
  const delta = (weekday(date) - weekStart + 7) % 7;
  return addDays(date, -delta);
}

export function weekDates(date: ISODate, weekStart = 0): ISODate[] {
  const start = startOfWeek(date, weekStart);
  return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}

export function range(from: ISODate, to: ISODate): ISODate[] {
  const out: ISODate[] = [];
  for (let d = from; d <= to; d = addDays(d, 1)) out.push(d);
  return out;
}

export function startOfMonth(date: ISODate): ISODate {
  return date.slice(0, 8) + '01';
}

function partsIn(timeZone: string, now: Date) {
  const fmt = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  });
  const p: Record<string, string> = {};
  for (const part of fmt.formatToParts(now)) p[part.type] = part.value;
  return p;
}

/** Calendar date "now" in the given IANA time zone. */
export function todayIn(timeZone: string, now: Date = new Date()): ISODate {
  const p = partsIn(timeZone, now);
  return `${p.year}-${p.month}-${p.day}`;
}

/** Minutes since local midnight in the given time zone. */
export function minutesNowIn(timeZone: string, now: Date = new Date()): number {
  const p = partsIn(timeZone, now);
  return (+p.hour % 24) * 60 + +p.minute;
}

export function parseHHMM(s: string): number | null {
  const m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(s);
  return m ? +m[1] * 60 + +m[2] : null;
}

export function isValidTimeZone(tz: string): boolean {
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

export function deviceTimeZone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Jerusalem';
  } catch {
    return 'Asia/Jerusalem';
  }
}

const HE_DAYS = ['ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי', 'שישי', 'שבת'];
const HE_DAYS_SHORT = ['א׳', 'ב׳', 'ג׳', 'ד׳', 'ה׳', 'ו׳', 'ש׳'];

export function hebrewWeekday(date: ISODate, short = false): string {
  return (short ? HE_DAYS_SHORT : HE_DAYS)[weekday(date)];
}

/** "יום חמישי, 15 באוקטובר" */
export function formatHebrewDate(date: ISODate, withWeekday = true): string {
  const opts: Intl.DateTimeFormatOptions = { timeZone: 'UTC', day: 'numeric', month: 'long' };
  if (withWeekday) opts.weekday = 'long';
  return new Intl.DateTimeFormat('he-IL', opts).format(toUTC(date));
}

export function formatShortDate(date: ISODate): string {
  return `${dayOfMonth(date)}.${+date.slice(5, 7)}`;
}
