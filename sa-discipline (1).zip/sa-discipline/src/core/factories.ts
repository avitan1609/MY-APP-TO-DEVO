import { DEFAULT_WEIGHTS } from './score';
import type { Category, DayEntry, Goal, ISODate, Settings, Task, TaskLog } from './types';

export function uid(): string {
  const c = globalThis.crypto as Crypto;
  if (typeof c.randomUUID === 'function') return c.randomUUID();
  // Fallback (non-secure contexts): RFC4122 v4 from getRandomValues
  const b = new Uint8Array(16);
  c.getRandomValues(b);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = [...b].map((x) => x.toString(16).padStart(2, '0')).join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

function base(userId: string, id = uid(), now = new Date().toISOString()) {
  return { id, userId, createdAt: now, updatedAt: now, deleted: false };
}

export const DEFAULT_CATEGORIES: Array<{ name: string; color: string }> = [
  { name: 'חדר כושר ואימוני כוח', color: '#2DB5A3' },
  { name: 'ריצה וסיבולת', color: '#3B82F6' },
  { name: 'פיזיותרפיה ושיקום', color: '#8B5CF6' },
  { name: 'צעדים, שינה והתאוששות', color: '#0EA5E9' },
  { name: 'קריאה', color: '#F59E0B' },
  { name: 'למידה והתפתחות', color: '#EC4899' },
  { name: 'עבודה ועסק', color: '#64748B' },
  { name: 'תזונה והרגלים יומיים', color: '#22C55E' },
  { name: 'מטרות אישיות', color: '#EF4444' },
];

/**
 * Seed rows use deterministic ids and an epoch timestamp: a second device that seeds
 * before its first sync creates the *same* rows, and any real data from the cloud
 * (newer timestamp) always wins the merge.
 */
export const SEED_TIMESTAMP = '1970-01-01T00:00:00.000Z';

export function defaultCategories(userId: string): Category[] {
  return DEFAULT_CATEGORIES.map((c, i) => ({
    ...base(userId, `default-${i + 1}`, SEED_TIMESTAMP),
    name: c.name,
    color: c.color,
    sortOrder: i,
    isDefault: true,
    archived: false,
  }));
}

export function newCategory(userId: string, name: string, color: string, sortOrder: number): Category {
  return { ...base(userId), name, color, sortOrder, isDefault: false, archived: false };
}

export function newTask(userId: string, today: ISODate, p: Partial<Task> = {}): Task {
  return {
    ...base(userId),
    title: '',
    description: '',
    categoryId: null,
    goalId: null,
    kind: 'one_time',
    measure: 'binary',
    importance: 'normal',
    urgency: 'medium',
    weightOverride: null,
    date: today,
    deadline: null,
    recurrence: null,
    estMinutes: null,
    target: null,
    unit: null,
    activity: 'none',
    subtasks: [],
    notes: '',
    archived: false,
    ...p,
  };
}

export function newGoal(userId: string, today: ISODate, p: Partial<Goal> = {}): Goal {
  return {
    ...base(userId),
    title: '',
    description: '',
    categoryId: null,
    horizon: 'month',
    startDate: today,
    endDate: today,
    progressMode: 'linked_completion',
    target: null,
    unit: null,
    currentValue: 0,
    status: 'active',
    ...p,
  };
}

export function newLog(userId: string, taskId: string, date: ISODate, p: Partial<TaskLog> = {}): TaskLog {
  return {
    ...base(userId, `${taskId}:${date}`),
    taskId,
    date,
    status: 'pending',
    value: null,
    distanceKm: null,
    durationMin: null,
    subtaskDone: [],
    movedTo: null,
    counted: false,
    extra: false,
    note: '',
    ...p,
  };
}

export function newDayEntry(userId: string, date: ISODate): DayEntry {
  return { ...base(userId, `day:${date}`), date, journal: '', blockers: '', scoreSnapshot: null, summaryGeneratedAt: null };
}

export function defaultSettings(userId: string, timezone: string): Settings {
  return {
    ...base(userId, 'settings', SEED_TIMESTAMP),
    weights: { ...DEFAULT_WEIGHTS },
    summaryTime: '21:30',
    timezone,
    weekStart: 0,
    dailyCapacityMin: 360,
    streakThreshold: 70,
    theme: 'system',
    remindersEnabled: false,
    onboarded: false,
  };
}

/** Pace in min/km from a run log. */
export function paceMinPerKm(distanceKm: number | null, durationMin: number | null): number | null {
  if (!distanceKm || !durationMin || distanceKm <= 0 || durationMin <= 0) return null;
  return durationMin / distanceKm;
}

export function formatPace(pace: number | null): string {
  if (pace === null) return '—';
  let m = Math.floor(pace);
  let s = Math.round((pace - m) * 60);
  if (s === 60) {
    m++;
    s = 0;
  }
  return `${m}:${String(s).padStart(2, '0')}`;
}
