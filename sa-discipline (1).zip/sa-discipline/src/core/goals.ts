import { addDays } from './dates';
import { plannedItemsForDate } from './recurrence';
import { isComplete } from './score';
import type { Goal, ISODate, Task, TaskLog } from './types';

export interface GoalProgress {
  current: number;
  target: number | null;
  ratio: number; // 0..1
  /** Expected ratio if progress were linear over the goal period. */
  expected: number;
  linkedTasks: number;
}

/**
 * manual: currentValue / target.
 * linked_sum: Σ log values of linked tasks in the period (binary done = 1).
 * linked_completion: completed / planned occurrences of linked tasks in the period
 *   (past days for recurring tasks; all dated one-time tasks in the period).
 */
export function goalProgress(goal: Goal, tasks: Task[], logs: TaskLog[], today: ISODate): GoalProgress {
  const linked = tasks.filter((t) => t.goalId === goal.id && !t.deleted);
  const span = Math.max(1, (Date.parse(goal.endDate) - Date.parse(goal.startDate)) / 86_400_000 + 1);
  const elapsed = Math.min(span, Math.max(0, (Date.parse(today) - Date.parse(goal.startDate)) / 86_400_000 + 1));
  const expected = elapsed / span;

  if (goal.progressMode === 'manual') {
    const target = goal.target ?? 0;
    return { current: goal.currentValue, target: goal.target, ratio: target > 0 ? Math.min(1, goal.currentValue / target) : 0, expected, linkedTasks: linked.length };
  }

  const linkedIds = new Set(linked.map((t) => t.id));
  const relevantLogs = logs.filter((l) => linkedIds.has(l.taskId) && !l.deleted);

  if (goal.progressMode === 'linked_sum') {
    let sum = 0;
    const byId = new Map(linked.map((t) => [t.id, t]));
    for (const l of relevantLogs) {
      if (l.date < goal.startDate || l.date > goal.endDate) continue;
      if (l.status === 'not_relevant' || l.status === 'moved') continue;
      const t = byId.get(l.taskId)!;
      sum += t.measure === 'binary' ? (l.status === 'done' ? 1 : 0) : l.value ?? 0;
    }
    const target = goal.target ?? 0;
    return { current: sum, target: goal.target, ratio: target > 0 ? Math.min(1, sum / target) : 0, expected, linkedTasks: linked.length };
  }

  // linked_completion
  let planned = 0;
  let done = 0;
  const lastPast = today < goal.endDate ? today : goal.endDate;
  for (let d = goal.startDate; d <= goal.endDate; d = addDays(d, 1)) {
    for (const item of plannedItemsForDate(linked, relevantLogs, d)) {
      if (item.log?.status === 'not_relevant' || (item.log?.status === 'moved' && !item.log.counted)) continue;
      if (item.task.kind !== 'one_time' && d > lastPast) continue;
      planned++;
      if (isComplete(item.task, item.log)) done++;
    }
  }
  return { current: done, target: planned, ratio: planned ? done / planned : 0, expected, linkedTasks: linked.length };
}
