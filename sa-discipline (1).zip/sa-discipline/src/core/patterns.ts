/** Rule-based pattern detection over the user's own data. */
import { addDays, weekday } from './dates';
import { IMPORTANCE_RANK, dayLoad, isActiveOnDay } from './planning';
import { plannedItemsForDate } from './recurrence';
import { completionRatio, computeDailyScore, taskWeight } from './score';
import type { ScoreSeries } from './streaks';
import type { ISODate, PlannedItem, Task, TaskLog, Weights } from './types';

export function scoreSeries(
  tasks: Task[],
  logs: TaskLog[],
  dates: ISODate[],
  weights: Weights,
  snapshots?: Map<ISODate, number | null>,
): ScoreSeries {
  const out: ScoreSeries = new Map();
  for (const d of dates) {
    if (snapshots?.has(d)) out.set(d, snapshots.get(d)!);
    else out.set(d, computeDailyScore(plannedItemsForDate(tasks, logs, d), weights).score);
  }
  return out;
}

export function average(values: Array<number | null | undefined>): number | null {
  const v = values.filter((x): x is number => typeof x === 'number');
  return v.length ? Math.round((v.reduce((a, b) => a + b, 0) / v.length) * 10) / 10 : null;
}

export function averageOver(series: ScoreSeries, to: ISODate, days: number, excludeTo = false): number | null {
  const vals: Array<number | null | undefined> = [];
  for (let i = excludeTo ? 1 : 0; i < days + (excludeTo ? 1 : 0); i++) vals.push(series.get(addDays(to, -i)));
  return average(vals);
}

/** Average score per weekday (0 = Sunday). */
export function weekdayAverages(series: ScoreSeries): Array<number | null> {
  const buckets: number[][] = Array.from({ length: 7 }, () => []);
  for (const [d, s] of series) if (typeof s === 'number') buckets[weekday(d)].push(s);
  return buckets.map((b) => average(b));
}

export interface CategoryRate {
  categoryId: string | null;
  planned: number;
  rate: number; // weighted completion 0..1
}

export function categoryRates(tasks: Task[], logs: TaskLog[], dates: ISODate[], weights: Weights): CategoryRate[] {
  const acc = new Map<string | null, { w: number; e: number; n: number }>();
  for (const d of dates) {
    for (const item of plannedItemsForDate(tasks, logs, d)) {
      if (item.log?.status === 'not_relevant') continue;
      const w = taskWeight(item.task, weights);
      const a = acc.get(item.task.categoryId) ?? { w: 0, e: 0, n: 0 };
      a.w += w;
      a.e += w * completionRatio(item.task, item.log);
      a.n++;
      acc.set(item.task.categoryId, a);
    }
  }
  return [...acc.entries()]
    .map(([categoryId, a]) => ({ categoryId, planned: a.n, rate: a.w ? a.e / a.w : 0 }))
    .sort((a, b) => b.planned - a.planned);
}

/** Tasks moved away ≥ minMoves times since `from`. */
export function frequentlyPostponed(logs: TaskLog[], from: ISODate, minMoves = 3): Array<{ taskId: string; moves: number }> {
  const counts = new Map<string, number>();
  for (const l of logs) if (!l.deleted && l.status === 'moved' && l.date >= from) counts.set(l.taskId, (counts.get(l.taskId) ?? 0) + 1);
  return [...counts.entries()]
    .filter(([, n]) => n >= minMoves)
    .map(([taskId, moves]) => ({ taskId, moves }))
    .sort((a, b) => b.moves - a.moves);
}

/** True when the last `days` completed days (before today) all scored below the threshold. */
export function needsRecovery(series: ScoreSeries, today: ISODate, threshold: number, days = 3): boolean {
  for (let i = 1; i <= days; i++) {
    const s = series.get(addDays(today, -i));
    if (typeof s !== 'number' || s >= threshold) return false;
  }
  return true;
}

/**
 * Recovery plan: keep critical items, then the most important ones,
 * until ~60% of capacity. Returns what to keep and what to propose moving.
 */
export function recoveryPlan(items: PlannedItem[], capacityMin: number, share = 0.6) {
  const budget = capacityMin > 0 ? capacityMin * share : Infinity;
  const active = items.filter(isActiveOnDay);
  const sorted = [...active].sort(
    (a, b) => IMPORTANCE_RANK[b.task.importance] - IMPORTANCE_RANK[a.task.importance] || (a.task.estMinutes ?? 0) - (b.task.estMinutes ?? 0),
  );
  const keep: PlannedItem[] = [];
  const move: PlannedItem[] = [];
  let used = 0;
  for (const i of sorted) {
    const est = i.task.estMinutes ?? 0;
    if (i.task.importance === 'critical' || used + est <= budget) {
      keep.push(i);
      used += est;
    } else move.push(i);
  }
  return { keep, move, keepLoad: dayLoad(keep) };
}
