/**
 * Rule-based planning (no AI): ordering, load, overload alternatives,
 * reschedule suggestions and move semantics. Every change is a *proposal* —
 * the UI applies it only after the user approves.
 */
import { addDays, parseHHMM } from './dates';
import { isScheduledOn, logId, plannedItemsForDate } from './recurrence';
import { isComplete } from './score';
import type { ISODate, Importance, PlannedItem, Task, TaskLog, Urgency } from './types';

export const IMPORTANCE_RANK: Record<Importance, number> = { normal: 1, important: 2, critical: 3 };
export const URGENCY_RANK: Record<Urgency, number> = { low: 1, medium: 2, high: 3 };

/** Counts toward the day's work (not cancelled / moved away). */
export function isActiveOnDay(item: PlannedItem): boolean {
  const s = item.log?.status;
  return s !== 'not_relevant' && s !== 'moved';
}

/** Incomplete first; then critical → urgent → important → nearest deadline → shortest. */
export function sortItems(items: PlannedItem[]): PlannedItem[] {
  const key = (i: PlannedItem) => {
    const inactive = !isActiveOnDay(i) ? 2 : isComplete(i.task, i.log) ? 1 : 0;
    return inactive;
  };
  return [...items].sort((a, b) => {
    const k = key(a) - key(b);
    if (k) return k;
    const imp = IMPORTANCE_RANK[b.task.importance] - IMPORTANCE_RANK[a.task.importance];
    if (a.task.importance === 'critical' || b.task.importance === 'critical') if (imp) return imp;
    const urg = URGENCY_RANK[b.task.urgency] - URGENCY_RANK[a.task.urgency];
    if (urg) return urg;
    if (imp) return imp;
    const da = a.task.deadline ?? '9999-12-31';
    const db = b.task.deadline ?? '9999-12-31';
    if (da !== db) return da < db ? -1 : 1;
    return (a.task.estMinutes ?? 0) - (b.task.estMinutes ?? 0);
  });
}

/** Planned minutes for the day. remainingOnly skips completed items. */
export function dayLoad(items: PlannedItem[], remainingOnly = false): number {
  let sum = 0;
  for (const i of items) {
    if (!isActiveOnDay(i)) continue;
    if (remainingOnly && isComplete(i.task, i.log)) continue;
    sum += Math.max(0, i.task.estMinutes ?? 0);
  }
  return sum;
}

export function isOverloaded(items: PlannedItem[], capacityMin: number): boolean {
  return capacityMin > 0 && dayLoad(items) > capacityMin;
}

/**
 * Greedy list of items to move so the day fits capacity.
 * Never proposes critical items or items whose deadline is that day or earlier.
 */
export function overloadAlternatives(items: PlannedItem[], capacityMin: number): PlannedItem[] {
  let load = dayLoad(items);
  if (capacityMin <= 0 || load <= capacityMin) return [];
  const candidates = items
    .filter((i) => isActiveOnDay(i) && !isComplete(i.task, i.log))
    .filter((i) => i.task.importance !== 'critical')
    .filter((i) => !(i.task.deadline && i.task.deadline <= i.date))
    .filter((i) => (i.task.estMinutes ?? 0) > 0)
    .sort((a, b) => {
      const imp = IMPORTANCE_RANK[a.task.importance] - IMPORTANCE_RANK[b.task.importance];
      if (imp) return imp;
      const urg = URGENCY_RANK[a.task.urgency] - URGENCY_RANK[b.task.urgency];
      if (urg) return urg;
      return (b.task.estMinutes ?? 0) - (a.task.estMinutes ?? 0);
    });
  const out: PlannedItem[] = [];
  for (const c of candidates) {
    if (load <= capacityMin) break;
    out.push(c);
    load -= c.task.estMinutes ?? 0;
  }
  return out;
}

export interface DateSuggestion {
  date: ISODate;
  fits: boolean;
  /** true when the suggestion respects the task deadline (or there is none) */
  beforeDeadline: boolean;
}

/**
 * Suggest a new date for `task`, starting the day after `fromDate`:
 * the first day (within `horizon`) whose load + estimate fits capacity.
 * Respects the deadline when possible; skips days where a recurring task
 * already occurs. Falls back to the least-loaded valid day.
 */
export function suggestDate(
  task: Task,
  fromDate: ISODate,
  loadFor: (d: ISODate) => number,
  capacityMin: number,
  horizon = 14,
): DateSuggestion {
  const est = Math.max(0, task.estMinutes ?? 0);
  const deadline = task.deadline;
  let best: { date: ISODate; load: number } | null = null;
  let firstValid: ISODate | null = null;

  for (let i = 1; i <= horizon; i++) {
    const d = addDays(fromDate, i);
    if (task.kind !== 'one_time' && isScheduledOn(task, d)) continue;
    if (deadline && d > deadline) break;
    firstValid ??= d;
    const load = loadFor(d);
    if (capacityMin <= 0 || load + est <= capacityMin) return { date: d, fits: true, beforeDeadline: true };
    if (!best || load < best.load) best = { date: d, load };
  }
  if (best) return { date: best.date, fits: false, beforeDeadline: true };
  if (firstValid) return { date: firstValid, fits: false, beforeDeadline: true };
  // Deadline already passed or no valid day before it: next valid day.
  for (let i = 1; i <= horizon * 2; i++) {
    const d = addDays(fromDate, i);
    if (task.kind !== 'one_time' && isScheduledOn(task, d)) continue;
    return { date: d, fits: capacityMin <= 0 || loadFor(d) + est <= capacityMin, beforeDeadline: !deadline };
  }
  return { date: addDays(fromDate, 1), fits: false, beforeDeadline: !deadline };
}

export function loadForFactory(tasks: Task[], logs: TaskLog[]) {
  const cache = new Map<ISODate, number>();
  return (d: ISODate) => {
    if (!cache.has(d)) cache.set(d, dayLoad(plannedItemsForDate(tasks, logs, d)));
    return cache.get(d)!;
  };
}

/**
 * A move is "after the fact" (and keeps counting as 0 on the original day)
 * when the day is already past, or it is today and the summary time has passed.
 * This prevents dodging the score by moving tasks at the end of the day.
 */
export function isAfterTheFact(fromDate: ISODate, today: ISODate, minutesNow: number, summaryTime: string): boolean {
  if (fromDate < today) return true;
  if (fromDate > today) return false;
  const s = parseHHMM(summaryTime);
  return s !== null && minutesNow >= s;
}

export interface MovePlan {
  taskPatch: Partial<Task> | null;
  logs: Array<Pick<TaskLog, 'id' | 'taskId' | 'date'> & Partial<TaskLog>>;
}

export function planMove(task: Task, fromDate: ISODate, toDate: ISODate, afterTheFact: boolean): MovePlan {
  if (toDate === fromDate) throw new Error('Target date equals source date');
  if (task.kind !== 'one_time' && isScheduledOn(task, toDate)) {
    throw new Error('The recurring task already occurs on the target date');
  }
  const fromLog = {
    id: logId(task.id, fromDate),
    taskId: task.id,
    date: fromDate,
    status: 'moved' as const,
    movedTo: toDate,
    counted: afterTheFact,
  };
  if (task.kind === 'one_time') {
    return { taskPatch: { date: toDate }, logs: afterTheFact ? [fromLog] : [] };
  }
  return {
    taskPatch: null,
    logs: [
      fromLog,
      { id: logId(task.id, toDate), taskId: task.id, date: toDate, status: 'pending', extra: true, counted: false, movedTo: null },
    ],
  };
}
