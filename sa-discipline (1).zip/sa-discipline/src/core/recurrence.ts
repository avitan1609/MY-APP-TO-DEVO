import { dayOfMonth, daysInMonth, diffDays, weekday } from './dates';
import type { ISODate, PlannedItem, Recurrence, Task, TaskLog } from './types';

/** Does a recurrence rule produce an occurrence on `date`? */
export function recurrenceMatches(rule: Recurrence, date: ISODate): boolean {
  if (date < rule.startDate) return false;
  if (rule.endDate && date > rule.endDate) return false;
  switch (rule.type) {
    case 'daily':
      return true;
    case 'weekly':
      return (rule.weekdays ?? []).includes(weekday(date));
    case 'interval': {
      const n = Math.max(1, Math.floor(rule.interval ?? 1));
      return diffDays(date, rule.startDate) % n === 0;
    }
    case 'monthly': {
      const wanted = Math.min(Math.max(1, rule.monthDay ?? 1), 31);
      // Clamp: monthDay 31 lands on the 30th / 28th / 29th in short months.
      return dayOfMonth(date) === Math.min(wanted, daysInMonth(date));
    }
    default:
      return false;
  }
}

/** Is the task scheduled (by its own rule/date) on this day, ignoring moves? */
export function isScheduledOn(task: Task, date: ISODate): boolean {
  if (task.deleted || task.archived) return false;
  if (task.kind === 'one_time') return task.date === date;
  return task.recurrence ? recurrenceMatches(task.recurrence, date) : false;
}

export function logId(taskId: string, date: ISODate): string {
  return `${taskId}:${date}`;
}

/**
 * Items planned for a day:
 *  - tasks scheduled on the day, unless moved away without being counted;
 *  - recurring occurrences moved *to* this day (log.extra);
 *  - occurrences moved away after the fact (counted = true) stay as 0.
 */
export function plannedItemsForDate(tasks: Task[], logs: TaskLog[], date: ISODate): PlannedItem[] {
  const byId = new Map(tasks.map((t) => [t.id, t]));
  const dayLogs = new Map<string, TaskLog>();
  for (const l of logs) if (l.date === date && !l.deleted) dayLogs.set(l.taskId, l);

  const out: PlannedItem[] = [];
  const seen = new Set<string>();

  for (const task of tasks) {
    if (!isScheduledOn(task, date)) continue;
    const log = dayLogs.get(task.id) ?? null;
    if (log?.status === 'moved' && !log.counted) continue;
    out.push({ task, date, log });
    seen.add(task.id);
  }

  for (const [taskId, log] of dayLogs) {
    if (seen.has(taskId)) continue;
    const task = byId.get(taskId);
    if (!task || task.deleted || task.archived) continue;
    if (log.extra || (log.status === 'moved' && log.counted)) out.push({ task, date, log });
  }
  return out;
}
