/**
 * Daily score — transparent and versioned.
 *
 *   Daily Score = 100 × Σ(weight × completion_ratio) / Σ(weight)
 *
 * Rules (formula v1):
 *  - weight = task.weightOverride ?? weights[importance] (defaults 1 / 2 / 3)
 *  - binary: done = 1, otherwise 0
 *  - numeric / duration: min(value / target, 1)
 *  - not_relevant (cancelled for the day): excluded from numerator and denominator
 *  - moved away after the fact (counted): stays in the denominator with ratio 0
 *  - no valid items (Σ weight = 0): score is null — never a misleading 0 or 100
 */
import type { PlannedItem, ScoreLine, ScoreSnapshot, Task, TaskLog, Weights } from './types';

export const FORMULA_VERSION = 'v1';
export const DEFAULT_WEIGHTS: Weights = { normal: 1, important: 2, critical: 3 };

export function taskWeight(task: Task, weights: Weights): number {
  const w = task.weightOverride ?? weights[task.importance] ?? 1;
  return Number.isFinite(w) && w > 0 ? w : 0;
}

export function completionRatio(task: Task, log: TaskLog | null): number {
  if (!log) return 0;
  if (log.status === 'moved' || log.status === 'not_relevant') return 0;
  if (task.measure === 'binary') return log.status === 'done' ? 1 : 0;
  const target = task.target ?? 0;
  if (target <= 0) return log.status === 'done' ? 1 : 0;
  const value = log.value ?? 0;
  if (!Number.isFinite(value) || value <= 0) return log.status === 'done' ? 1 : 0;
  return Math.min(value / target, 1);
}

export function isComplete(task: Task, log: TaskLog | null): boolean {
  return completionRatio(task, log) >= 1;
}

const round1 = (n: number) => Math.round(n * 10) / 10;

export function computeDailyScore(
  items: PlannedItem[],
  weights: Weights = DEFAULT_WEIGHTS,
  now: Date = new Date(),
): ScoreSnapshot {
  const lines: ScoreLine[] = [];
  let total = 0;
  let earned = 0;

  for (const { task, log } of items) {
    const weight = taskWeight(task, weights);
    if (log?.status === 'not_relevant') {
      lines.push({ taskId: task.id, title: task.title, weight, ratio: 0, contribution: 0, excluded: true, reason: 'not_relevant' });
      continue;
    }
    const ratio = completionRatio(task, log);
    const contribution = weight * ratio;
    total += weight;
    earned += contribution;
    lines.push({
      taskId: task.id,
      title: task.title,
      weight,
      ratio: round1(ratio * 100) / 100,
      contribution: round1(contribution),
      excluded: false,
      reason: log?.status === 'moved' ? 'moved' : undefined,
    });
  }

  const score = total > 0 ? round1((100 * earned) / total) : null;
  return {
    score,
    earned: round1(earned),
    totalWeight: round1(total),
    lines,
    formulaVersion: FORMULA_VERSION,
    weights: { ...weights },
    computedAt: now.toISOString(),
  };
}

/** Rounded integer for display. */
export function displayScore(score: number | null): string {
  return score === null ? '—' : String(Math.round(score));
}
