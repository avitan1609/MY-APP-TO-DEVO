import { addDays } from './dates';
import { isScheduledOn, logId } from './recurrence';
import { isComplete } from './score';
import type { ISODate, Task, TaskLog } from './types';

export type ScoreSeries = Map<ISODate, number | null>;

/**
 * Day streak: consecutive days with score ≥ threshold, ending today.
 *  - Today counts only once it reaches the threshold; an unfinished today never breaks the streak.
 *  - Days without valid data (score null — nothing planned) are neutral: skipped, not broken.
 */
export function dayStreak(scores: ScoreSeries, threshold: number, today: ISODate, maxDays = 400): number {
  let streak = 0;
  for (let i = 0; i < maxDays; i++) {
    const d = addDays(today, -i);
    const s = scores.get(d);
    if (s === undefined) {
      if (i === 0) continue;
      break; // no record before this point
    }
    if (s === null) continue;
    if (s >= threshold) streak++;
    else if (i === 0) continue;
    else break;
  }
  return streak;
}

/** Longest run of qualifying days in the series (null days neutral). */
export function bestDayStreak(scores: ScoreSeries, threshold: number): number {
  const dates = [...scores.keys()].sort();
  let best = 0;
  let cur = 0;
  let prev: ISODate | null = null;
  for (const d of dates) {
    if (prev && addDays(prev, 1) !== d) cur = 0; // gap in data breaks
    prev = d;
    const s = scores.get(d);
    if (s === null || s === undefined) continue;
    if (s >= threshold) best = Math.max(best, ++cur);
    else cur = 0;
  }
  return best;
}

/**
 * Habit streak: consecutive *scheduled* occurrences completed, ending today.
 * Unscheduled days and cancelled occurrences are skipped; an unfinished today does not break it.
 */
export function habitStreak(task: Task, logs: TaskLog[], today: ISODate, maxDays = 400): number {
  const byId = new Map(logs.filter((l) => l.taskId === task.id && !l.deleted).map((l) => [l.id, l]));
  let streak = 0;
  for (let i = 0; i < maxDays; i++) {
    const d = addDays(today, -i);
    const log = byId.get(logId(task.id, d)) ?? null;
    const scheduled = isScheduledOn(task, d) || !!log?.extra;
    if (!scheduled) {
      if (task.recurrence && d < task.recurrence.startDate) break;
      continue;
    }
    if (log?.status === 'not_relevant' || (log?.status === 'moved' && !log.counted)) continue;
    if (isComplete(task, log)) streak++;
    else if (i === 0) continue;
    else break;
  }
  return streak;
}

/** Share of scheduled occurrences completed within [from, to]. null if none scheduled. */
export function habitCompletionRate(task: Task, logs: TaskLog[], from: ISODate, to: ISODate): number | null {
  const byId = new Map(logs.filter((l) => l.taskId === task.id && !l.deleted).map((l) => [l.id, l]));
  let scheduled = 0;
  let done = 0;
  for (let d = from; d <= to; d = addDays(d, 1)) {
    const log = byId.get(logId(task.id, d)) ?? null;
    if (!(isScheduledOn(task, d) || log?.extra)) continue;
    if (log?.status === 'not_relevant' || (log?.status === 'moved' && !log.counted)) continue;
    scheduled++;
    if (isComplete(task, log)) done++;
  }
  return scheduled ? done / scheduled : null;
}
