/**
 * Pure sync helpers: row shape conversion and conflict resolution.
 * Strategy: last-write-wins per row by client `updatedAt`, tombstones for deletes.
 */

export interface LocalMeta {
  /** 1 = has local changes not yet pushed */
  _dirty?: 0 | 1;
}

const toSnakeKey = (k: string) => k.replace(/[A-Z]/g, (c) => '_' + c.toLowerCase());
const toCamelKey = (k: string) => k.replace(/_([a-z])/g, (_, c: string) => c.toUpperCase());

/** Converts top-level keys only (JSON columns keep their inner shape). Drops local-only `_` keys. */
export function toRemote(row: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(row)) if (!k.startsWith('_')) out[toSnakeKey(k)] = v;
  return out;
}

/** Converts a remote row to the local shape. Drops server-only columns. */
export function fromRemote<T>(row: Record<string, unknown>): T {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(row)) {
    if (k === 'server_updated_at') continue;
    out[toCamelKey(k)] = v;
  }
  return out as T;
}

export type MergeDecision = 'take_remote' | 'keep_local';

/**
 * Decide what to keep when a remote row arrives.
 *  - no local row → take remote
 *  - local row clean → take remote (server is source of truth for synced rows)
 *  - local row dirty → newer updatedAt wins; ties keep local (it will be pushed)
 */
export function resolve(
  local: ({ updatedAt: string } & LocalMeta) | undefined,
  remote: { updatedAt: string },
): MergeDecision {
  if (!local) return 'take_remote';
  if (!local._dirty) return 'take_remote';
  return Date.parse(remote.updatedAt) > Date.parse(local.updatedAt) ? 'take_remote' : 'keep_local';
}

/** Max timestamp helper for pull cursors. */
export function maxCursor(current: string | null, rows: Array<{ server_updated_at?: string }>): string | null {
  let best = current;
  for (const r of rows) if (r.server_updated_at && (!best || r.server_updated_at > best)) best = r.server_updated_at;
  return best;
}
