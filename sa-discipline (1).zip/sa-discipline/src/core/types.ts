/** Domain types. Pure — no runtime dependencies. */

/** Calendar date in the user's time zone, formatted YYYY-MM-DD. */
export type ISODate = string;

export type Importance = 'normal' | 'important' | 'critical';
export type Urgency = 'low' | 'medium' | 'high';
/** one_time: a single dated task. recurring: repeats by rule. habit: recurring + tracked as a habit (own streak). */
export type TaskKind = 'one_time' | 'recurring' | 'habit';
/** binary: done / not done. numeric: target value with unit. duration: target in minutes. */
export type Measure = 'binary' | 'numeric' | 'duration';
export type Activity = 'none' | 'run';

export type RecurrenceType = 'daily' | 'weekly' | 'interval' | 'monthly';

export interface Recurrence {
  type: RecurrenceType;
  /** weekly: 0 = Sunday … 6 = Saturday */
  weekdays?: number[];
  /** interval: every N days counted from startDate */
  interval?: number;
  /** monthly: day of month 1-31 (clamped to the last day of short months) */
  monthDay?: number;
  startDate: ISODate;
  endDate?: ISODate | null;
}

export interface Subtask {
  id: string;
  title: string;
}

/** Fields every synced row carries. */
export interface SyncFields {
  id: string;
  userId: string;
  createdAt: string; // ISO timestamp
  updatedAt: string; // ISO timestamp — last-write-wins key
  deleted: boolean; // soft delete (tombstone) so deletions sync
}

export interface Category extends SyncFields {
  name: string;
  color: string;
  sortOrder: number;
  isDefault: boolean;
  archived: boolean;
}

export type GoalHorizon = 'month' | 'quarter' | 'year' | 'custom';
export type GoalProgressMode = 'manual' | 'linked_sum' | 'linked_completion';
export type GoalStatus = 'active' | 'done' | 'archived';

export interface Goal extends SyncFields {
  title: string;
  description: string;
  categoryId: string | null;
  horizon: GoalHorizon;
  startDate: ISODate;
  endDate: ISODate;
  progressMode: GoalProgressMode;
  target: number | null;
  unit: string | null;
  currentValue: number;
  status: GoalStatus;
}

export interface Task extends SyncFields {
  title: string;
  description: string;
  categoryId: string | null;
  goalId: string | null;
  kind: TaskKind;
  measure: Measure;
  importance: Importance;
  urgency: Urgency;
  /** Overrides the importance-based weight when set. */
  weightOverride: number | null;
  /** one_time: the day it is planned for (null = backlog, not scored). */
  date: ISODate | null;
  /** Optional hard deadline. */
  deadline: ISODate | null;
  recurrence: Recurrence | null;
  estMinutes: number | null;
  target: number | null;
  unit: string | null;
  activity: Activity;
  subtasks: Subtask[];
  notes: string;
  archived: boolean;
}

/**
 * done / partial: progress recorded.
 * not_relevant: cancelled for that day — excluded from the score denominator.
 * moved: rescheduled away from this date. `counted` decides whether it still
 *        counts as 0 on this day (true when moved after the fact, e.g. from the end-of-day summary).
 */
export type LogStatus = 'pending' | 'done' | 'partial' | 'not_relevant' | 'moved';

export interface TaskLog extends SyncFields {
  /** Deterministic id `${taskId}:${date}` so two offline devices never duplicate. */
  taskId: string;
  date: ISODate;
  status: LogStatus;
  value: number | null;
  distanceKm: number | null;
  durationMin: number | null;
  subtaskDone: string[];
  movedTo: ISODate | null;
  counted: boolean;
  /** true when this occurrence exists on `date` only because it was moved here. */
  extra: boolean;
  note: string;
}

export interface ScoreLine {
  taskId: string;
  title: string;
  weight: number;
  ratio: number;
  contribution: number;
  excluded: boolean;
  reason?: 'not_relevant' | 'moved';
}

export interface ScoreSnapshot {
  score: number | null;
  earned: number;
  totalWeight: number;
  lines: ScoreLine[];
  formulaVersion: string;
  weights: Weights;
  computedAt: string;
}

export interface DayEntry extends SyncFields {
  /** id = `day:${date}` */
  date: ISODate;
  journal: string;
  blockers: string;
  scoreSnapshot: ScoreSnapshot | null;
  summaryGeneratedAt: string | null;
}

export interface Weights {
  normal: number;
  important: number;
  critical: number;
}

export type ThemePref = 'system' | 'light' | 'dark';

export interface Settings extends SyncFields {
  /** id = 'settings' */
  weights: Weights;
  summaryTime: string; // HH:MM
  timezone: string;
  weekStart: number; // 0 = Sunday
  dailyCapacityMin: number;
  streakThreshold: number;
  theme: ThemePref;
  remindersEnabled: boolean;
  onboarded: boolean;
}

/** A task as it appears on a specific day (an "occurrence"). */
export interface PlannedItem {
  task: Task;
  date: ISODate;
  log: TaskLog | null;
}
