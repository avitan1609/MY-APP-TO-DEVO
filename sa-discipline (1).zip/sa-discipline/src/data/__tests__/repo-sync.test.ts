/**
 * Data layer tests: local persistence (offline), dirty tracking, moves,
 * snapshots, backup round-trip, and sync push/pull against an in-memory fake Supabase.
 * Runs with fake-indexeddb (see src/test-setup.ts).
 */
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { newTask } from '../../core/factories';
import { destroyDB, openDB, type AppDB } from '../db';
import {
  applyMove,
  ensureSeed,
  exportAll,
  importAll,
  loadCore,
  pendingChanges,
  saveTask,
  setLog,
  snapshotDay,
  toggleDone,
  toggleSubtask,
  type Ctx,
} from '../repo';
import { SyncEngine } from '../sync';

const D = '2026-10-15';

/** Minimal in-memory stand-in for the parts of supabase-js the engine uses. */
function fakeSupabase() {
  const tables = new Map<string, Map<string, Record<string, unknown>>>();
  let clock = 0;
  const tbl = (n: string) => tables.get(n) ?? tables.set(n, new Map()).get(n)!;
  const client = {
    from(name: string) {
      const rows = tbl(name);
      return {
        async upsert(payload: Array<Record<string, unknown>>) {
          for (const r of payload) {
            const key = `${r.user_id}|${r.id}`;
            const prev = rows.get(key);
            if (prev && Date.parse(String(r.updated_at)) < Date.parse(String(prev.updated_at))) continue; // LWW guard
            rows.set(key, { ...r, server_updated_at: new Date(Date.UTC(2026, 0, 1, 0, 0, ++clock)).toISOString() });
          }
          return { error: null };
        },
        select() {
          let filt: Array<(r: Record<string, unknown>) => boolean> = [];
          let lim = 1000;
          const q = {
            eq(col: string, v: unknown) {
              filt.push((r) => r[col] === v);
              return q;
            },
            gt(col: string, v: string) {
              filt.push((r) => String(r[col]) > v);
              return q;
            },
            order() {
              return q;
            },
            limit(n: number) {
              lim = n;
              return q;
            },
            then(res: (v: { data: unknown[]; error: null }) => void) {
              const data = [...rows.values()]
                .filter((r) => filt.every((f) => f(r)))
                .sort((a, b) => String(a.server_updated_at).localeCompare(String(b.server_updated_at)))
                .slice(0, lim);
              filt = [];
              res({ data, error: null });
            },
          };
          return q;
        },
      };
    },
    tables,
  };
  return client;
}

let db: AppDB;
let ctx: Ctx;
const USER = 'u-test';

beforeEach(async () => {
  db = openDB(USER);
  ctx = { db, userId: USER, notify: () => {} };
  await ensureSeed(ctx, 'Asia/Jerusalem');
});

afterEach(async () => {
  await destroyDB(USER);
  await destroyDB('u-other');
});

describe('local repository (works fully offline)', () => {
  it('seeds settings and default categories once', async () => {
    await ensureSeed(ctx, 'Asia/Jerusalem');
    expect(await db.categories.count()).toBe(9);
    expect((await db.settings.get('settings'))?.timezone).toBe('Asia/Jerusalem');
  });

  it('persists tasks and logs with dirty flags', async () => {
    const t = newTask(USER, D, { title: 'ריצה' });
    await saveTask(ctx, t);
    await toggleDone(ctx, t, D, null);
    const { tasks, logs } = await loadCore(db);
    expect(tasks.map((x) => x.title)).toContain('ריצה');
    expect(logs[0].status).toBe('done');
    expect(await pendingChanges(db)).toBeGreaterThan(0);
  });

  it('numeric values derive status from the target', async () => {
    const t = newTask(USER, D, { title: 'צעדים', measure: 'numeric', target: 10000, unit: 'צעדים' });
    await saveTask(ctx, t);
    expect((await setLog(ctx, t, D, { value: 4000 })).status).toBe('partial');
    expect((await setLog(ctx, t, D, { value: 12000 })).status).toBe('done');
  });

  it('completing all subtasks completes the task', async () => {
    const t = newTask(USER, D, { title: 'x', subtasks: [{ id: 'a', title: 'A' }, { id: 'b', title: 'B' }] });
    await saveTask(ctx, t);
    let log = await toggleSubtask(ctx, t, D, null, 'a');
    expect(log.status).toBe('pending');
    log = await toggleSubtask(ctx, t, D, log, 'b');
    expect(log.status).toBe('done');
  });

  it('applies an approved move and snapshots the score with formula version', async () => {
    const t = newTask(USER, D, { title: 'דוח' });
    await saveTask(ctx, t);
    await applyMove(ctx, t, D, '2026-10-16', true);
    const day = await snapshotDay(ctx, D, true);
    expect(day.scoreSnapshot?.score).toBe(0); // moved after the fact still counts as 0
    expect(day.scoreSnapshot?.formulaVersion).toBe('v1');
    expect((await db.tasks.get(t.id))?.date).toBe('2026-10-16');
  });

  it('backup export → import into another account re-owns rows', async () => {
    await saveTask(ctx, newTask(USER, D, { title: 'גיבוי' }));
    const file = await exportAll(db);
    const other = openDB('u-other');
    await importAll({ db: other, userId: 'u-other', notify: () => {} }, file);
    const t = (await other.tasks.toArray()).find((x) => x.title === 'גיבוי');
    expect(t?.userId).toBe('u-other');
    expect(t?._dirty).toBe(1);
  });
});

describe('sync engine', () => {
  it('stays local when offline and keeps changes pending', async () => {
    const fake = fakeSupabase();
    Object.defineProperty(navigator, 'onLine', { value: false, configurable: true });
    const eng = new SyncEngine(db, USER, fake as never);
    await saveTask(ctx, newTask(USER, D, { title: 'offline' }));
    await eng.sync();
    expect(eng.state.status).toBe('offline');
    expect(fake.tables.size).toBe(0);
    expect(await pendingChanges(db)).toBeGreaterThan(0);
    Object.defineProperty(navigator, 'onLine', { value: true, configurable: true });
  });

  it('pushes dirty rows, clears flags, and a second device pulls them', async () => {
    const fake = fakeSupabase();
    await saveTask(ctx, newTask(USER, D, { title: 'סנכרון' }));
    await new SyncEngine(db, USER, fake as never).sync();
    expect(await pendingChanges(db)).toBe(0);
    const remoteTask = [...fake.tables.get('tasks')!.values()].find((r) => r.title === 'סנכרון');
    expect(remoteTask?.user_id).toBe(USER);
    expect('_dirty' in remoteTask!).toBe(false);

    // Device 2 = fresh database for the same user
    await destroyDB(USER);
    const db2 = openDB(USER);
    await new SyncEngine(db2, USER, fake as never).sync();
    expect((await db2.tasks.toArray()).some((t) => t.title === 'סנכרון')).toBe(true);
  });

  it('local mode never talks to the server', async () => {
    const eng = new SyncEngine(db, 'local', fakeSupabase() as never);
    expect(eng.enabled).toBe(false);
    expect(eng.state.status).toBe('local');
  });
});
