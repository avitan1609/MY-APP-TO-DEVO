import Dexie, { type Table } from 'dexie';
import type { Category, DayEntry, Goal, Settings, Task, TaskLog } from '../core/types';

/** Local row = domain row + dirty flag (1 = not yet pushed). Booleans are not indexable, hence 0/1. */
export type Row<T> = T & { _dirty: 0 | 1 };

export interface Meta {
  key: string;
  value: unknown;
}

export class AppDB extends Dexie {
  categories!: Table<Row<Category>, string>;
  goals!: Table<Row<Goal>, string>;
  tasks!: Table<Row<Task>, string>;
  logs!: Table<Row<TaskLog>, string>;
  days!: Table<Row<DayEntry>, string>;
  settings!: Table<Row<Settings>, string>;
  meta!: Table<Meta, string>;

  constructor(name: string) {
    super(name);
    this.version(1).stores({
      categories: 'id, _dirty, sortOrder',
      goals: 'id, _dirty, status',
      tasks: 'id, _dirty, kind, date, categoryId, goalId',
      logs: 'id, _dirty, date, taskId',
      days: 'id, _dirty, date',
      settings: 'id, _dirty',
      meta: 'key',
    });
  }
}

export const SYNC_TABLES = ['categories', 'goals', 'tasks', 'logs', 'days', 'settings'] as const;
export type SyncTable = (typeof SYNC_TABLES)[number];
export const REMOTE_TABLE: Record<SyncTable, string> = {
  categories: 'categories',
  goals: 'goals',
  tasks: 'tasks',
  logs: 'task_logs',
  days: 'days',
  settings: 'settings',
};

/** One IndexedDB database per account keeps users on a shared device fully separated. */
export function dbNameFor(userId: string) {
  return `sa-discipline-${userId}`;
}

const open = new Map<string, AppDB>();

export function openDB(userId: string): AppDB {
  let d = open.get(userId);
  if (!d) {
    d = new AppDB(dbNameFor(userId));
    open.set(userId, d);
  }
  return d;
}

export async function destroyDB(userId: string) {
  const d = open.get(userId);
  if (d) {
    d.close();
    open.delete(userId);
  }
  await Dexie.delete(dbNameFor(userId));
}

export async function getMeta<T>(db: AppDB, key: string): Promise<T | undefined> {
  return (await db.meta.get(key))?.value as T | undefined;
}

export async function setMeta(db: AppDB, key: string, value: unknown) {
  await db.meta.put({ key, value });
}
