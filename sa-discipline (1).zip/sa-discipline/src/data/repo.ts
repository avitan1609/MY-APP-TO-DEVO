/**
 * Local-first repository. Every write goes to IndexedDB immediately (works offline),
 * is stamped with updatedAt + _dirty=1, and then the sync engine is nudged.
 */
import { BACKUP_VERSION, makeBackup, reownBackup, type BackupData, type BackupFile } from '../core/backup';
import { addDays } from '../core/dates';
import { defaultCategories, defaultSettings, newDayEntry, newLog } from '../core/factories';
import { planMove } from '../core/planning';
import { logId, plannedItemsForDate } from '../core/recurrence';
import { computeDailyScore } from '../core/score';
import type { Category, DayEntry, Goal, ISODate, Settings, SyncFields, Task, TaskLog } from '../core/types';
import { getMeta, setMeta, SYNC_TABLES, type AppDB, type Row } from './db';

export interface Ctx {
  db: AppDB;
  userId: string;
  notify: () => void;
}

function stamp<T extends SyncFields>(row: T, userId: string): Row<T> {
  const { _dirty: _ignored, ...clean } = row as T & { _dirty?: 0 | 1 };
  return { ...(clean as T), userId, updatedAt: new Date().toISOString(), _dirty: 1 };
}

function strip<T>(row: Row<T>): T {
  const { _dirty: _ignored, ...rest } = row;
  return rest as T;
}

/**
 * Create default settings and categories on first run for this account.
 * Seed rows keep their epoch timestamp (see factories.SEED_TIMESTAMP) so cloud data always wins.
 */
export async function ensureSeed(ctx: Ctx, timezone: string): Promise<void> {
  await ctx.db.transaction('rw', ctx.db.settings, ctx.db.categories, async () => {
    if (!(await ctx.db.settings.get('settings'))) {
      await ctx.db.settings.put({ ...defaultSettings(ctx.userId, timezone), _dirty: 1 });
    }
    if ((await ctx.db.categories.count()) === 0) {
      await ctx.db.categories.bulkPut(defaultCategories(ctx.userId).map((c) => ({ ...c, _dirty: 1 as const })));
    }
  });
  ctx.notify();
}

// ---------------------------------------------------------------------------
// Reads
// ---------------------------------------------------------------------------
export async function loadCore(db: AppDB) {
  const [tasks, logs, settings] = await Promise.all([
    db.tasks.filter((t) => !t.deleted).toArray(),
    db.logs.filter((l) => !l.deleted).toArray(),
    db.settings.get('settings'),
  ]);
  return { tasks: tasks.map(strip), logs: logs.map(strip), settings: settings ? strip(settings) : null };
}

// ---------------------------------------------------------------------------
// Writes
// ---------------------------------------------------------------------------
export async function saveTask(ctx: Ctx, task: Task) {
  await ctx.db.tasks.put(stamp(task, ctx.userId));
  ctx.notify();
}

export async function deleteTask(ctx: Ctx, task: Task) {
  await ctx.db.tasks.put(stamp({ ...task, deleted: true }, ctx.userId));
  ctx.notify();
}

export async function saveGoal(ctx: Ctx, goal: Goal) {
  await ctx.db.goals.put(stamp(goal, ctx.userId));
  ctx.notify();
}

export async function deleteGoal(ctx: Ctx, goal: Goal) {
  await ctx.db.transaction('rw', ctx.db.goals, ctx.db.tasks, async () => {
    await ctx.db.goals.put(stamp({ ...goal, deleted: true }, ctx.userId));
    const linked = await ctx.db.tasks.where('goalId').equals(goal.id).toArray();
    await ctx.db.tasks.bulkPut(linked.map((t) => stamp({ ...strip(t), goalId: null }, ctx.userId)));
  });
  ctx.notify();
}

export async function saveCategory(ctx: Ctx, cat: Category) {
  await ctx.db.categories.put(stamp(cat, ctx.userId));
  ctx.notify();
}

export async function saveSettings(ctx: Ctx, s: Settings) {
  await ctx.db.settings.put(stamp({ ...s, id: 'settings' }, ctx.userId));
  ctx.notify();
}

export async function saveDay(ctx: Ctx, day: DayEntry) {
  await ctx.db.days.put(stamp(day, ctx.userId));
  ctx.notify();
}

export async function getDay(db: AppDB, userId: string, date: ISODate): Promise<DayEntry> {
  const d = await db.days.get(`day:${date}`);
  return d && !d.deleted ? strip(d) : newDayEntry(userId, date);
}

/** Derive a status from a numeric value against the target. */
export function statusForValue(task: Task, value: number | null): TaskLog['status'] {
  if (value === null || value <= 0) return 'pending';
  if (task.target && value >= task.target) return 'done';
  return 'partial';
}

/** Merge a patch into the log for (task, date), creating it if needed. */
export async function setLog(ctx: Ctx, task: Task, date: ISODate, patch: Partial<TaskLog>, today?: ISODate): Promise<TaskLog> {
  const id = logId(task.id, date);
  const existing = await ctx.db.logs.get(id);
  const base = existing && !existing.deleted ? strip(existing) : newLog(ctx.userId, task.id, date);
  const next: TaskLog = { ...base, ...patch, id, taskId: task.id, date, deleted: false };
  if (task.measure !== 'binary' && 'value' in patch && !('status' in patch)) next.status = statusForValue(task, next.value);
  await ctx.db.logs.put(stamp(next, ctx.userId));
  if (today && date < today) await refreshSnapshotIfExists(ctx, date);
  ctx.notify();
  return next;
}

export async function toggleDone(ctx: Ctx, task: Task, date: ISODate, log: TaskLog | null, today?: ISODate) {
  const isDone = log?.status === 'done';
  return setLog(ctx, task, date, { status: isDone ? 'pending' : 'done' }, today);
}

/** Toggle a subtask for that day; all subtasks done ⇒ the binary task is done. */
export async function toggleSubtask(ctx: Ctx, task: Task, date: ISODate, log: TaskLog | null, subId: string, today?: ISODate) {
  const done = new Set(log?.subtaskDone ?? []);
  if (done.has(subId)) done.delete(subId);
  else done.add(subId);
  const all = task.subtasks.length > 0 && task.subtasks.every((s) => done.has(s.id));
  const patch: Partial<TaskLog> = { subtaskDone: [...done] };
  if (task.measure === 'binary') {
    if (all) patch.status = 'done';
    else if (log?.status === 'done') patch.status = 'pending';
  }
  return setLog(ctx, task, date, patch, today);
}

/** Apply an approved move (see core/planning planMove). */
export async function applyMove(ctx: Ctx, task: Task, from: ISODate, to: ISODate, afterTheFact: boolean, today?: ISODate) {
  const plan = planMove(task, from, to, afterTheFact);
  await ctx.db.transaction('rw', ctx.db.tasks, ctx.db.logs, async () => {
    if (plan.taskPatch) await ctx.db.tasks.put(stamp({ ...task, ...plan.taskPatch }, ctx.userId));
    for (const l of plan.logs) {
      const existing = await ctx.db.logs.get(l.id);
      const base = existing && !existing.deleted ? strip(existing) : newLog(ctx.userId, l.taskId, l.date);
      await ctx.db.logs.put(stamp({ ...base, ...l, deleted: false } as TaskLog, ctx.userId));
    }
  });
  if (today && from < today) await refreshSnapshotIfExists(ctx, from);
  ctx.notify();
}

// ---------------------------------------------------------------------------
// Score snapshots (keep history auditable even if tasks change later)
// ---------------------------------------------------------------------------
export async function snapshotDay(ctx: Ctx, date: ISODate, markSummary = false): Promise<DayEntry> {
  const { tasks, logs, settings } = await loadCore(ctx.db);
  const weights = settings?.weights ?? defaultSettings(ctx.userId, 'UTC').weights;
  const snap = computeDailyScore(plannedItemsForDate(tasks, logs, date), weights);
  const day = await getDay(ctx.db, ctx.userId, date);
  const next: DayEntry = { ...day, scoreSnapshot: snap, summaryGeneratedAt: markSummary ? new Date().toISOString() : day.summaryGeneratedAt };
  await saveDay(ctx, next);
  return next;
}

async function refreshSnapshotIfExists(ctx: Ctx, date: ISODate) {
  const d = await ctx.db.days.get(`day:${date}`);
  if (d?.scoreSnapshot) await snapshotDay(ctx, date);
}

/** Freeze scores for past days that have none yet (up to 60 days back). */
export async function finalizePastDays(ctx: Ctx, today: ISODate) {
  const last = (await getMeta<ISODate>(ctx.db, 'finalizedThrough')) ?? addDays(today, -1);
  let from = addDays(last, 1);
  const floor = addDays(today, -60);
  if (from < floor) from = floor;
  for (let d = from; d < today; d = addDays(d, 1)) {
    const existing = await ctx.db.days.get(`day:${d}`);
    if (!existing?.scoreSnapshot) await snapshotDay(ctx, d);
  }
  await setMeta(ctx.db, 'finalizedThrough', addDays(today, -1));
}

// ---------------------------------------------------------------------------
// Backup / restore / migration between accounts
// ---------------------------------------------------------------------------
export async function exportAll(db: AppDB): Promise<BackupFile> {
  const live = <T extends { deleted: boolean }>(rows: Row<T>[]) => rows.filter((r) => !r.deleted).map(strip);
  const settings = await db.settings.get('settings');
  return makeBackup({
    categories: live(await db.categories.toArray()),
    goals: live(await db.goals.toArray()),
    tasks: live(await db.tasks.toArray()),
    logs: live(await db.logs.toArray()),
    days: live(await db.days.toArray()),
    settings: settings ? strip(settings) : null,
  });
}

/** Merge a backup into the current account. Rows are re-owned and marked for upload. */
export async function importAll(ctx: Ctx, data: BackupData) {
  const b = reownBackup(data, ctx.userId);
  const dirty = <T>(rows: T[]) => rows.map((r) => ({ ...r, _dirty: 1 as const }));
  await ctx.db.transaction('rw', [ctx.db.categories, ctx.db.goals, ctx.db.tasks, ctx.db.logs, ctx.db.days, ctx.db.settings], async () => {
    await ctx.db.categories.bulkPut(dirty(b.categories));
    await ctx.db.goals.bulkPut(dirty(b.goals));
    await ctx.db.tasks.bulkPut(dirty(b.tasks));
    await ctx.db.logs.bulkPut(dirty(b.logs));
    await ctx.db.days.bulkPut(dirty(b.days));
    if (b.settings) await ctx.db.settings.put({ ...b.settings, _dirty: 1 });
  });
  ctx.notify();
}

/** Has this database got any user content? */
export async function hasContent(db: AppDB): Promise<boolean> {
  return (await db.tasks.count()) > 0 || (await db.goals.count()) > 0 || (await db.logs.count()) > 0;
}

export async function pendingChanges(db: AppDB): Promise<number> {
  let n = 0;
  for (const t of SYNC_TABLES) n += await db.table(t).where('_dirty').equals(1).count();
  return n;
}

export { BACKUP_VERSION };
