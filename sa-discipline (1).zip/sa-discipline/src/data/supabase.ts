import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const url = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim();
const anonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined)?.trim();

/** Cloud features are on only when both public values are configured. */
export const cloudConfigured = !!(url && anonKey);
export const googleEnabled = cloudConfigured && import.meta.env.VITE_ENABLE_GOOGLE === 'true';

export const supabase: SupabaseClient | null = cloudConfigured
  ? createClient(url!, anonKey!, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, flowType: 'pkce' },
    })
  : null;

/** Maps Supabase auth errors to Hebrew without leaking internals. */
export function authErrorMessage(err: unknown): string {
  const msg = (err as { message?: string })?.message?.toLowerCase() ?? '';
  if (!navigator.onLine) return 'אין חיבור לאינטרנט. נסה שוב כשתהיה מחובר.';
  if (msg.includes('invalid login credentials')) return 'אימייל או סיסמה שגויים';
  if (msg.includes('email not confirmed')) return 'יש לאשר את כתובת האימייל דרך הקישור שנשלח אליך';
  if (msg.includes('already registered')) return 'כבר קיים חשבון עם האימייל הזה';
  if (msg.includes('password should be at least')) return 'הסיסמה קצרה מדי (לפחות 8 תווים)';
  if (msg.includes('rate limit')) return 'יותר מדי ניסיונות. נסה שוב בעוד כמה דקות';
  return 'הפעולה נכשלה. נסה שוב.';
}
