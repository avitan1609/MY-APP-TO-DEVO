/**
 * Sync engine: push dirty rows (upsert), then pull rows changed on the server
 * since the last cursor. Conflicts: last-write-wins per row (see core/syncMerge),
 * enforced on the server too by the sync_guard trigger.
 */
import type { SupabaseClient } from '@supabase/supabase-js';
import { fromRemote, maxCursor, resolve, toRemote } from '../core/syncMerge';
import { getMeta, REMOTE_TABLE, setMeta, SYNC_TABLES, type AppDB, type SyncTable } from './db';

export type SyncStatus = 'local' | 'offline' | 'idle' | 'syncing' | 'error';

export interface SyncState {
  status: SyncStatus;
  lastSyncAt: string | null;
  error: string | null;
}

const PAGE = 1000;
const PUSH_CHUNK = 200;

export class SyncEngine {
  state: SyncState;
  private listeners = new Set<(s: SyncState) => void>();
  private running = false;
  private again = false;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private interval: ReturnType<typeof setInterval> | null = null;
  private cleanup: Array<() => void> = [];

  constructor(
    private db: AppDB,
    private userId: string,
    private client: SupabaseClient | null,
  ) {
    this.state = { status: this.enabled ? (navigator.onLine ? 'idle' : 'offline') : 'local', lastSyncAt: null, error: null };
  }

  get enabled() {
    return !!this.client && this.userId !== 'local';
  }

  subscribe(fn: (s: SyncState) => void) {
    this.listeners.add(fn);
    fn(this.state);
    return () => this.listeners.delete(fn);
  }

  private set(p: Partial<SyncState>) {
    this.state = { ...this.state, ...p };
    for (const l of this.listeners) l(this.state);
  }

  start() {
    if (!this.enabled) return;
    const online = () => {
      this.set({ status: 'idle' });
      void this.sync();
    };
    const offline = () => this.set({ status: 'offline' });
    const visible = () => document.visibilityState === 'visible' && void this.sync();
    window.addEventListener('online', online);
    window.addEventListener('offline', offline);
    document.addEventListener('visibilitychange', visible);
    this.cleanup.push(
      () => window.removeEventListener('online', online),
      () => window.removeEventListener('offline', offline),
      () => document.removeEventListener('visibilitychange', visible),
    );
    this.interval = setInterval(() => void this.sync(), 60_000);
    void getMeta<string>(this.db, 'lastSyncAt').then((v) => v && this.set({ lastSyncAt: v }));
    void this.sync();
  }

  stop() {
    this.cleanup.forEach((f) => f());
    this.cleanup = [];
    if (this.interval) clearInterval(this.interval);
    if (this.timer) clearTimeout(this.timer);
  }

  /** Debounced sync after local writes. */
  schedule = () => {
    if (!this.enabled) return;
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => void this.sync(), 1500);
  };

  async sync(): Promise<void> {
    if (!this.enabled) return;
    if (!navigator.onLine) {
      this.set({ status: 'offline' });
      return;
    }
    if (this.running) {
      this.again = true;
      return;
    }
    this.running = true;
    this.set({ status: 'syncing', error: null });
    try {
      for (const t of SYNC_TABLES) await this.push(t);
      for (const t of SYNC_TABLES) await this.pull(t);
      const now = new Date().toISOString();
      await setMeta(this.db, 'lastSyncAt', now);
      this.set({ status: 'idle', lastSyncAt: now });
    } catch (e) {
      console.error('[sync]', e);
      this.set({ status: navigator.onLine ? 'error' : 'offline', error: 'הסנכרון נכשל. השינויים שמורים במכשיר וינסו שוב אוטומטית.' });
    } finally {
      this.running = false;
      if (this.again) {
        this.again = false;
        void this.sync();
      }
    }
  }

  private async push(table: SyncTable) {
    const t = this.db.table(table);
    const dirty = await t.where('_dirty').equals(1).toArray();
    for (let i = 0; i < dirty.length; i += PUSH_CHUNK) {
      const chunk = dirty.slice(i, i + PUSH_CHUNK);
      const payload = chunk.map((r) => ({ ...toRemote(r), user_id: this.userId }));
      const { error } = await this.client!.from(REMOTE_TABLE[table]).upsert(payload, { onConflict: 'user_id,id' });
      if (error) throw error;
      // Clear the flag only if the row was not edited again meanwhile.
      await this.db.transaction('rw', t, async () => {
        for (const r of chunk) {
          const cur = await t.get(r.id);
          if (cur && cur.updatedAt === r.updatedAt) await t.update(r.id, { _dirty: 0 });
        }
      });
    }
  }

  private async pull(table: SyncTable) {
    const t = this.db.table(table);
    const key = `cursor:${table}`;
    let cursor = (await getMeta<string>(this.db, key)) ?? null;
    for (;;) {
      let q = this.client!.from(REMOTE_TABLE[table]).select('*').eq('user_id', this.userId).order('server_updated_at', { ascending: true }).limit(PAGE);
      if (cursor) q = q.gt('server_updated_at', cursor);
      const { data, error } = await q;
      if (error) throw error;
      const rows = (data ?? []) as Array<Record<string, unknown> & { server_updated_at?: string }>;
      if (!rows.length) break;
      await this.db.transaction('rw', t, async () => {
        for (const raw of rows) {
          const remote = fromRemote<{ id: string; updatedAt: string }>(raw);
          const local = await t.get(remote.id);
          if (resolve(local, remote) === 'take_remote') await t.put({ ...remote, _dirty: 0 });
        }
      });
      cursor = maxCursor(cursor, rows);
      await setMeta(this.db, key, cursor);
      if (rows.length < PAGE) break;
    }
  }
}
