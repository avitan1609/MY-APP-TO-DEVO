import { useState, type FormEvent } from 'react';
import { googleEnabled } from '../data/supabase';
import { useAuth } from '../state/auth';
import { Button, Segmented, TextInput } from '../ui/kit';
import { Logo } from '../ui/Logo';

type Mode = 'signin' | 'signup' | 'reset';

export function AuthScreen() {
  const auth = useAuth();
  const [mode, setMode] = useState<Mode>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setInfo('');
    const em = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return setError('כתובת אימייל לא תקינה');
    if (mode !== 'reset' && password.length < 8) return setError('סיסמה של לפחות 8 תווים');
    setBusy(true);
    try {
      if (mode === 'signin') await auth.signIn(em, password);
      else if (mode === 'signup') {
        const r = await auth.signUp(em, password);
        if (r === 'confirm') setInfo('נשלח אליך אימייל לאישור החשבון. אחרי האישור — התחבר כאן.');
      } else {
        await auth.resetPassword(em);
        setInfo('אם קיים חשבון עם האימייל הזה, נשלח אליו קישור לאיפוס.');
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-dvh items-center justify-center px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center text-center">
          <Logo size={88} className="animate-logo-in" />
          <h1 className="mt-4 text-[24px] font-bold tracking-tight">משמעת</h1>
          <p className="mt-1 text-[14px] text-muted">שלוש דקות ביום. סדר, מיקוד, התמדה.</p>
        </div>

        <div className="card p-5">
          {mode !== 'reset' ? (
            <div className="mb-4">
              <Segmented<Mode>
                value={mode}
                onChange={(m) => {
                  setMode(m);
                  setError('');
                  setInfo('');
                }}
                options={[
                  { value: 'signin', label: 'התחברות' },
                  { value: 'signup', label: 'הרשמה' },
                ]}
              />
            </div>
          ) : (
            <h2 className="mb-4 text-[16px] font-semibold">איפוס סיסמה</h2>
          )}
          <form className="space-y-3" onSubmit={submit} noValidate>
            <TextInput label="אימייל" type="email" autoComplete="email" dir="ltr" value={email} onChange={(e) => setEmail(e.target.value)} />
            {mode !== 'reset' ? (
              <TextInput
                label="סיסמה"
                type="password"
                dir="ltr"
                autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                hint={mode === 'signup' ? 'לפחות 8 תווים' : undefined}
              />
            ) : null}
            {error ? (
              <p className="text-[13px] text-danger" role="alert">
                {error}
              </p>
            ) : null}
            {info ? (
              <p className="text-[13px] text-accent" role="status">
                {info}
              </p>
            ) : null}
            <Button type="submit" variant="primary" size="lg" className="w-full" loading={busy}>
              {mode === 'signin' ? 'התחברות' : mode === 'signup' ? 'יצירת חשבון' : 'שליחת קישור'}
            </Button>
          </form>

          {googleEnabled && mode !== 'reset' ? (
            <>
              <div className="my-4 flex items-center gap-3 text-[12px] text-faint">
                <span className="h-px flex-1 bg-line" /> או <span className="h-px flex-1 bg-line" />
              </div>
              <Button
                size="lg"
                className="w-full"
                onClick={async () => {
                  try {
                    await auth.signInWithGoogle();
                  } catch (err) {
                    setError((err as Error).message);
                  }
                }}
              >
                <GoogleMark /> המשך עם Google
              </Button>
            </>
          ) : null}

          <div className="mt-4 text-center text-[13px]">
            {mode === 'reset' ? (
              <button type="button" className="text-accent" onClick={() => setMode('signin')}>
                חזרה להתחברות
              </button>
            ) : mode === 'signin' ? (
              <button type="button" className="text-muted hover:text-ink" onClick={() => setMode('reset')}>
                שכחתי סיסמה
              </button>
            ) : null}
          </div>
        </div>

        <button type="button" onClick={auth.continueLocal} className="mt-5 w-full text-center text-[13px] text-muted hover:text-ink">
          המשך בלי חשבון — הנתונים יישמרו רק במכשיר הזה
        </button>
      </div>
    </div>
  );
}

function GoogleMark() {
  return (
    <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34.1 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.3-.4-3.5z" />
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34.1 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
      <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z" />
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.3-.4-3.5z" />
    </svg>
  );
}
