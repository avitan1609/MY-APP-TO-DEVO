import { useMemo, useState, type ReactNode } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { coachMessage } from '../core/coach';
import { addDays, formatHebrewDate, isISODate, parseHHMM } from '../core/dates';
import { averageOver, needsRecovery, scoreSeries } from '../core/patterns';
import { dayLoad, isActiveOnDay, isAfterTheFact, isOverloaded, loadForFactory, overloadAlternatives, suggestDate } from '../core/planning';
import { isComplete } from '../core/score';
import { dayStreak } from '../core/streaks';
import type { Category, PlannedItem } from '../core/types';
import { applyMove } from '../data/repo';
import { useApp, useCategories, useDay, useSnapshots } from '../state/app';
import { useDayItems } from '../state/derived';
import { IconAlert, IconChevronBack, IconChevronForward, IconFlame, IconPlus } from '../ui/icons';
import { Bar, Button, Empty, IconButton, ScoreRing, Sheet, cx, useToast } from '../ui/kit';
import { minutesText, relDay } from '../ui/labels';
import { useOverlays } from '../ui/Shell';
import { TaskRow } from '../ui/TaskRow';

export function DayScreen() {
  const params = useParams();
  const { today, settings, minutesNow } = useApp();
  const date = params.date && isISODate(params.date) ? params.date : today;
  const isToday = date === today;
  const data = useDayItems(date);
  const snapshots = useSnapshots();
  const categories = useCategories(true);
  const day = useDay(date);
  const { quickAdd, openItem } = useOverlays();
  const navigate = useNavigate();
  const [showAlt, setShowAlt] = useState(false);

  const catById = useMemo(() => new Map((categories ?? []).map((c) => [c.id, c])), [categories]);

  const derived = useMemo(() => {
    if (!data || !snapshots) return null;
    const hist = Array.from({ length: 45 }, (_, i) => addDays(date, -i));
    const snaps = new Map(snapshots);
    snaps.delete(date);
    const series = scoreSeries(data.tasks, data.logs, hist, settings.weights, snaps);
    series.set(date, data.score.score);
    const active = data.items.filter(isActiveOnDay);
    return {
      streak: dayStreak(series, settings.streakThreshold, date),
      avg7: averageOver(series, date, 7, true),
      recovery: needsRecovery(series, date, settings.streakThreshold),
      load: dayLoad(data.items),
      remaining: dayLoad(data.items, true),
      overloaded: isOverloaded(data.items, settings.dailyCapacityMin),
      doneCount: active.filter((i) => isComplete(i.task, i.log)).length,
      activeCount: active.length,
      criticalOpen: active.filter((i) => i.task.importance === 'critical' && !isComplete(i.task, i.log)).length,
    };
  }, [data, snapshots, date, settings]);

  if (!data || !derived) return <Skeleton />;

  // Past days show the frozen score (kept even if tasks are edited/deleted later).
  const frozen = date < today && day?.scoreSnapshot ? day.scoreSnapshot : null;
  const shownScore = frozen ? frozen.score : data.score.score;

  const summaryAt = parseHHMM(settings.summaryTime) ?? 1290;
  const dayOver = date < today || (isToday && minutesNow >= summaryAt);
  const coach = coachMessage({
    score: shownScore,
    avg7: derived.avg7,
    streak: derived.streak,
    threshold: settings.streakThreshold,
    criticalOpen: derived.criticalOpen,
    criticalMissed: dayOver ? derived.criticalOpen : 0,
    recovery: derived.recovery && isToday,
    overloaded: derived.overloaded,
    dayOver,
  });

  const open = data.items.filter((i) => isActiveOnDay(i) && !isComplete(i.task, i.log));
  const closed = data.items.filter((i) => !isActiveOnDay(i) || isComplete(i.task, i.log));
  const critical = open.filter((i) => i.task.importance === 'critical');
  const rest = open.filter((i) => i.task.importance !== 'critical');

  return (
    <div>
      {/* Date navigation */}
      <div className="mb-4 flex items-center justify-between gap-2">
        <IconButton label="היום הקודם" onClick={() => navigate(`/day/${addDays(date, -1)}`)}>
          <IconChevronBack />
        </IconButton>
        <div className="text-center">
          <h1 className="text-[20px] font-bold tracking-tight sm:text-[24px]">{isToday ? 'היום' : relDay(date, today)}</h1>
          <p className="text-[13px] text-muted">{formatHebrewDate(date)}</p>
        </div>
        <IconButton label="היום הבא" onClick={() => navigate(`/day/${addDays(date, 1)}`)}>
          <IconChevronForward />
        </IconButton>
      </div>
      {!isToday ? (
        <div className="mb-4 text-center">
          <Link to="/" className="text-[13px] text-accent underline-offset-4 hover:underline">
            חזרה להיום
          </Link>
        </div>
      ) : null}

      {/* Score card */}
      <section className="card mb-4 flex items-center gap-5 p-4 sm:p-5">
        <ScoreRing score={shownScore} size={116} label={frozen ? 'ציון שנשמר' : 'ציון יומי'} />
        <div className="min-w-0 flex-1 space-y-2.5">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[13px]">
            <span>
              <span className="num font-semibold">
                {derived.doneCount}/{derived.activeCount}
              </span>{' '}
              <span className="text-muted">הושלמו</span>
            </span>
            <span className="inline-flex items-center gap-1">
              <IconFlame size={15} className={derived.streak ? 'text-warn' : 'text-faint'} />
              <span className="num font-semibold">{derived.streak}</span> <span className="text-muted">ימי רצף</span>
            </span>
            {derived.avg7 !== null ? (
              <span className="text-muted">
                ממוצע 7 ימים <span className="num font-semibold text-ink">{Math.round(derived.avg7)}</span>
              </span>
            ) : null}
          </div>
          {settings.dailyCapacityMin > 0 ? (
            <div>
              <div className="mb-1 flex justify-between text-[12px] text-muted">
                <span>עומס מתוכנן</span>
                <span className={cx('num', derived.overloaded && 'font-semibold text-danger')}>
                  {minutesText(derived.load)} / {minutesText(settings.dailyCapacityMin)}
                </span>
              </div>
              <Bar value={derived.load} max={settings.dailyCapacityMin} tone={derived.overloaded ? 'danger' : 'accent'} />
            </div>
          ) : null}
          <p className={cx('text-[13px] leading-snug', coach.tone === 'warn' ? 'text-warn' : coach.tone === 'good' ? 'text-accent' : 'text-ink')}>{coach.text}</p>
        </div>
      </section>

      {/* Banners */}
      {derived.overloaded && !dayOver ? (
        <Banner tone="warn" action={<Button size="sm" onClick={() => setShowAlt(true)}>הצג חלופות</Button>}>
          היום עמוס ב־{minutesText(derived.load - settings.dailyCapacityMin)} מעבר לקיבולת.
        </Banner>
      ) : null}
      {isToday && minutesNow >= summaryAt && !day?.summaryGeneratedAt ? (
        <Banner tone="accent" action={<Button size="sm" variant="primary" onClick={() => navigate('/summary')}>לסיכום</Button>}>
          הגיע זמן הסיכום היומי. שתי דקות לסגור את היום.
        </Banner>
      ) : null}

      {/* Lists */}
      {data.items.length === 0 ? (
        <Empty
          title="אין משימות מתוכננות"
          body={isToday ? 'תוסיף את מה שחייב לקרות היום. התחל מהדבר החשוב ביותר.' : 'אין משימות ליום הזה.'}
          action={
            <Button variant="primary" onClick={() => quickAdd(date)}>
              <IconPlus size={16} /> הוסף משימה
            </Button>
          }
        />
      ) : (
        <div className="space-y-5">
          {critical.length ? <Group title="קריטי" items={critical} catById={catById} onOpen={openItem} /> : null}
          {rest.length ? <Group title={critical.length ? 'שאר המשימות' : 'משימות'} items={rest} catById={catById} onOpen={openItem} /> : null}
          {open.length === 0 && closed.length ? <p className="py-2 text-center text-[13px] text-accent">כל המשימות הושלמו.</p> : null}
          {closed.length ? <Group title="הושלמו / לא פעילות" items={closed} catById={catById} onOpen={openItem} /> : null}
          <Button variant="ghost" className="w-full border border-dashed border-line" onClick={() => quickAdd(date)}>
            <IconPlus size={16} /> הוסף משימה {isToday ? 'להיום' : `ל${relDay(date, today)}`}
          </Button>
        </div>
      )}

      <OverloadSheet open={showAlt} onClose={() => setShowAlt(false)} items={data.items} date={date} data={data} />
    </div>
  );
}

function Group({ title, items, catById, onOpen }: { title: string; items: PlannedItem[]; catById: Map<string, Category>; onOpen: (i: PlannedItem) => void }) {
  return (
    <section>
      <h2 className="mb-2 text-[13px] font-semibold text-muted">{title}</h2>
      <ul className="space-y-2">
        {items.map((i) => (
          <li key={`${i.task.id}:${i.date}`}>
            <TaskRow item={i} category={i.task.categoryId ? catById.get(i.task.categoryId) : undefined} onOpen={() => onOpen(i)} />
          </li>
        ))}
      </ul>
    </section>
  );
}

function Banner({ tone, children, action }: { tone: 'warn' | 'accent'; children: ReactNode; action?: ReactNode }) {
  return (
    <div className={cx('mb-4 flex items-center gap-3 rounded-2xl border px-4 py-3 text-[13px]', tone === 'warn' ? 'border-warn/40 bg-warn/10' : 'border-accent/40 bg-accent-soft')}>
      <IconAlert size={18} className={tone === 'warn' ? 'shrink-0 text-warn' : 'shrink-0 text-accent'} />
      <span className="flex-1">{children}</span>
      {action}
    </div>
  );
}

function OverloadSheet({ open, onClose, items, date, data }: { open: boolean; onClose: () => void; items: PlannedItem[]; date: string; data: NonNullable<ReturnType<typeof useDayItems>> }) {
  const { settings, ctx, today, minutesNow } = useApp();
  const toast = useToast();
  const proposals = useMemo(() => {
    const loadFor = loadForFactory(data.tasks, data.logs);
    return overloadAlternatives(items, settings.dailyCapacityMin).map((i) => ({ item: i, to: suggestDate(i.task, date, loadFor, settings.dailyCapacityMin).date }));
  }, [items, data, date, settings.dailyCapacityMin]);
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const toggle = (id: string) => setPicked((s) => (s.has(id) ? new Set([...s].filter((x) => x !== id)) : new Set([...s, id])));

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="חלופות לעומס"
      footer={
        <>
          <Button
            variant="primary"
            disabled={!picked.size}
            loading={busy}
            onClick={async () => {
              setBusy(true);
              const after = isAfterTheFact(date, today, minutesNow, settings.summaryTime);
              for (const p of proposals) if (picked.has(p.item.task.id)) await applyMove(ctx, p.item.task, date, p.to, after, today);
              setBusy(false);
              toast(`הועברו ${picked.size} משימות`);
              setPicked(new Set());
              onClose();
            }}
          >
            אשר העברה ({picked.size})
          </Button>
          <Button variant="ghost" onClick={onClose}>
            סגור
          </Button>
        </>
      }
    >
      {proposals.length === 0 ? (
        <p className="text-[14px] text-muted">אין משימות שאפשר להזיז בלי לפגוע בקריטי או בדדליין של היום. שקול לבטל משימה פחות חשובה.</p>
      ) : (
        <>
          <p className="mb-3 text-[13px] text-muted">המשימות הפחות חשובות, עם המועד הפנוי הקרוב לכל אחת. שום דבר לא זז בלי אישורך.</p>
          <ul className="space-y-2">
            {proposals.map((p) => (
              <li key={p.item.task.id}>
                <label className="card flex cursor-pointer items-center gap-3 px-3 py-2.5">
                  <input type="checkbox" className="h-5 w-5 accent-[rgb(var(--accent))]" checked={picked.has(p.item.task.id)} onChange={() => toggle(p.item.task.id)} />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[14px] font-medium">{p.item.task.title}</span>
                    <span className="text-[12px] text-muted">
                      {minutesText(p.item.task.estMinutes ?? 0)} · אל {relDay(p.to, today)}
                    </span>
                  </span>
                </label>
              </li>
            ))}
          </ul>
        </>
      )}
    </Sheet>
  );
}

function Skeleton() {
  return (
    <div className="animate-pulse space-y-3" aria-busy="true" aria-label="טוען">
      <div className="mx-auto h-8 w-40 rounded-lg bg-raised" />
      <div className="h-36 rounded-2xl bg-raised" />
      <div className="h-14 rounded-2xl bg-raised" />
      <div className="h-14 rounded-2xl bg-raised" />
    </div>
  );
}
