import { useEffect, useMemo, useState } from 'react';
import { addDays, startOfMonth } from '../core/dates';
import { newGoal } from '../core/factories';
import { goalProgress } from '../core/goals';
import type { Goal, GoalHorizon, GoalProgressMode, GoalStatus } from '../core/types';
import { validateGoal, type Errors } from '../core/validation';
import { deleteGoal, saveGoal } from '../data/repo';
import { useApp, useCategories, useGoals, useLogs, useTasks } from '../state/app';
import { IconPlus, IconTrash } from '../ui/icons';
import { Bar, Button, ConfirmSheet, Empty, NumberInput, PageHeader, Segmented, Select, Sheet, TextArea, TextInput, useToast } from '../ui/kit';
import { HORIZON_LABEL, fmtNum } from '../ui/labels';

export function GoalsScreen() {
  const { today } = useApp();
  const goals = useGoals();
  const tasks = useTasks();
  const logs = useLogs();
  const [editing, setEditing] = useState<Goal | null>(null);
  const [status, setStatus] = useState<GoalStatus>('active');
  const { account } = useApp();

  const rows = useMemo(() => {
    if (!goals || !tasks || !logs) return null;
    return goals
      .filter((g) => g.status === status)
      .sort((a, b) => a.endDate.localeCompare(b.endDate))
      .map((g) => ({ goal: g, p: goalProgress(g, tasks, logs, today) }));
  }, [goals, tasks, logs, status, today]);

  return (
    <div>
      <PageHeader
        title="מטרות"
        sub="חודשיות, רבעוניות ושנתיות — עם קישור למשימות"
        actions={
          <Button variant="primary" size="sm" onClick={() => setEditing(newGoal(account.id, today, { endDate: endOfMonth(today) }))}>
            <IconPlus size={16} /> מטרה
          </Button>
        }
      />
      <div className="mb-4">
        <Segmented<GoalStatus>
          size="sm"
          value={status}
          onChange={setStatus}
          options={[
            { value: 'active', label: 'פעילות' },
            { value: 'done', label: 'הושגו' },
            { value: 'archived', label: 'ארכיון' },
          ]}
        />
      </div>
      {!rows ? (
        <div className="h-32 animate-pulse rounded-2xl bg-raised" />
      ) : rows.length === 0 ? (
        <Empty title="אין מטרות כאן" body="מטרה טובה היא מדידה ותחומה בזמן. קשר אליה משימות והרגלים כדי לראות התקדמות אמיתית." />
      ) : (
        <ul className="space-y-2.5">
          {rows.map(({ goal, p }) => {
            const behind = goal.status === 'active' && p.ratio + 0.05 < p.expected;
            return (
              <li key={goal.id}>
                <button type="button" onClick={() => setEditing(goal)} className="card block w-full px-4 py-3.5 text-start">
                  <div className="mb-1 flex items-center justify-between gap-3">
                    <span className="truncate text-[15px] font-semibold">{goal.title}</span>
                    <span className="num shrink-0 text-[15px] font-semibold">{Math.round(p.ratio * 100)}%</span>
                  </div>
                  <Bar value={p.ratio} max={1} tone={behind ? 'warn' : 'accent'} className="h-2" />
                  <div className="mt-1.5 flex flex-wrap justify-between gap-x-3 text-[12px] text-muted">
                    <span>
                      {HORIZON_LABEL[goal.horizon]} · עד {goal.endDate.slice(8, 10)}.{+goal.endDate.slice(5, 7)}
                      {p.linkedTasks ? ` · ${p.linkedTasks} משימות מקושרות` : ''}
                    </span>
                    <span className="num">
                      {fmtNum(p.current)}
                      {p.target ? ` / ${fmtNum(p.target)}` : ''} {goal.progressMode !== 'linked_completion' ? goal.unit ?? '' : 'בוצעו'}
                      {behind ? <span className="ms-2 text-warn">מאחורי הקצב</span> : null}
                    </span>
                  </div>
                </button>
              </li>
            );
          })}
        </ul>
      )}
      <GoalEditor goal={editing} onClose={() => setEditing(null)} />
    </div>
  );
}

function endOfMonth(d: string) {
  const next = addDays(startOfMonth(d), 32);
  return addDays(startOfMonth(next), -1);
}

function GoalEditor({ goal, onClose }: { goal: Goal | null; onClose: () => void }) {
  const { ctx, today } = useApp();
  const goals = useGoals();
  const categories = useCategories();
  const toast = useToast();
  const [d, setD] = useState<Goal | null>(null);
  const [errors, setErrors] = useState<Errors>({});
  const [confirm, setConfirm] = useState(false);
  useEffect(() => {
    setD(goal ? { ...goal } : null);
    setErrors({});
  }, [goal]);
  const isNew = !!goal && !goals?.some((g) => g.id === goal.id);
  const set = (p: Partial<Goal>) => setD((x) => (x ? { ...x, ...p } : x));

  const setHorizon = (h: GoalHorizon) => {
    if (!d) return;
    const start = d.startDate || today;
    const end =
      h === 'month' ? endOfMonth(start) : h === 'quarter' ? addDays(endOfMonth(addDays(startOfMonth(start), 62)), 0) : h === 'year' ? `${start.slice(0, 4)}-12-31` : d.endDate;
    set({ horizon: h, endDate: end });
  };

  return (
    <>
      <Sheet
        open={!!d}
        onClose={onClose}
        title={isNew ? 'מטרה חדשה' : 'עריכת מטרה'}
        footer={
          <>
            <Button
              variant="primary"
              onClick={async () => {
                if (!d) return;
                const clean = { ...d, title: d.title.trim() };
                const e = validateGoal(clean);
                setErrors(e);
                if (Object.keys(e).length) return;
                await saveGoal(ctx, clean);
                toast('נשמר');
                onClose();
              }}
            >
              שמירה
            </Button>
            <Button variant="ghost" onClick={onClose}>
              ביטול
            </Button>
            {!isNew ? (
              <Button variant="danger" className="ms-auto" onClick={() => setConfirm(true)}>
                <IconTrash size={16} />
              </Button>
            ) : null}
          </>
        }
      >
        {d ? (
          <div className="space-y-4">
            <TextInput label="שם המטרה" value={d.title} onChange={(e) => set({ title: e.target.value })} error={errors.title} maxLength={120} placeholder='לדוגמה: לרוץ 100 ק"מ באוקטובר' data-autofocus />
            <Segmented<GoalHorizon>
              label="טווח"
              size="sm"
              value={d.horizon}
              onChange={setHorizon}
              options={(['month', 'quarter', 'year', 'custom'] as const).map((h) => ({ value: h, label: HORIZON_LABEL[h] }))}
            />
            <div className="grid grid-cols-2 gap-3">
              <TextInput label="התחלה" type="date" value={d.startDate} onChange={(e) => set({ startDate: e.target.value })} error={errors.startDate} />
              <TextInput label="סיום" type="date" value={d.endDate} onChange={(e) => set({ endDate: e.target.value, horizon: 'custom' })} error={errors.endDate} />
            </div>
            <Select label="מדידת התקדמות" value={d.progressMode} onChange={(e) => set({ progressMode: e.target.value as GoalProgressMode })}>
              <option value="linked_completion">אחוז ביצוע של המשימות המקושרות</option>
              <option value="linked_sum">סכום ערכים מהמשימות המקושרות</option>
              <option value="manual">עדכון ידני</option>
            </Select>
            {d.progressMode !== 'linked_completion' ? (
              <div className="grid grid-cols-2 gap-3">
                <NumberInput label="יעד" value={d.target} onValue={(v) => set({ target: v })} min={0} step="any" error={errors.target} />
                <TextInput label="יחידה" value={d.unit ?? ''} onChange={(e) => set({ unit: e.target.value || null })} maxLength={30} />
              </div>
            ) : (
              <p className="text-[12px] text-muted">את המשימות מקשרים מתוך עריכת משימה ← "קישור למטרה".</p>
            )}
            {d.progressMode === 'manual' ? <NumberInput label="מצב נוכחי" value={d.currentValue} onValue={(v) => set({ currentValue: v ?? 0 })} min={0} step="any" error={errors.currentValue} /> : null}
            <div className="grid grid-cols-2 gap-3">
              <Select label="קטגוריה" value={d.categoryId ?? ''} onChange={(e) => set({ categoryId: e.target.value || null })}>
                <option value="">ללא</option>
                {categories?.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </Select>
              <Select label="סטטוס" value={d.status} onChange={(e) => set({ status: e.target.value as GoalStatus })}>
                <option value="active">פעילה</option>
                <option value="done">הושגה</option>
                <option value="archived">בארכיון</option>
              </Select>
            </div>
            <TextArea label="תיאור / למה זה חשוב" value={d.description} onChange={(e) => set({ description: e.target.value })} maxLength={2000} />
          </div>
        ) : null}
      </Sheet>
      <ConfirmSheet
        open={confirm}
        title="למחוק את המטרה?"
        body="המשימות המקושרות יישארו, רק הקישור יוסר."
        confirmLabel="מחק"
        danger
        onClose={() => setConfirm(false)}
        onConfirm={async () => {
          if (d) await deleteGoal(ctx, d);
          setConfirm(false);
          onClose();
        }}
      />
    </>
  );
}
