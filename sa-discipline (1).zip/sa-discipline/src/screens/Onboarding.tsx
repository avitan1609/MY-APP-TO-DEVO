import { useState } from 'react';
import { validateSettings } from '../core/validation';
import { saveSettings } from '../data/repo';
import { useApp } from '../state/app';
import { Button, NumberInput, Sheet, TextInput } from '../ui/kit';

/** First run: the three numbers that drive the system. Everything else has sane defaults. */
export function Onboarding() {
  const { settings, ctx, ready } = useApp();
  const [time, setTime] = useState(settings.summaryTime);
  const [hours, setHours] = useState<number | null>(settings.dailyCapacityMin / 60);
  const [threshold, setThreshold] = useState<number | null>(settings.streakThreshold);
  const [error, setError] = useState('');

  if (!ready || settings.onboarded) return null;

  const finish = async () => {
    const next = { ...settings, summaryTime: time, dailyCapacityMin: Math.round((hours ?? 0) * 60), streakThreshold: threshold ?? 70, onboarded: true };
    const e = validateSettings(next);
    if (Object.keys(e).length) return setError(Object.values(e)[0] ?? 'בדוק את הערכים');
    await saveSettings(ctx, next);
  };

  return (
    <Sheet open onClose={() => void finish()} title="שלושה דברים לפני שמתחילים" footer={<Button variant="primary" onClick={() => void finish()}>מתחילים</Button>}>
      <div className="space-y-4">
        <p className="text-[14px] text-muted">את הכול אפשר לשנות אחר כך בהגדרות.</p>
        <TextInput label="באיזו שעה תסגור את היום?" type="time" value={time} onChange={(e) => setTime(e.target.value)} hint="בשעה הזו יופיע הסיכום היומי" />
        <NumberInput label="כמה שעות עבודה אמיתיות יש לך ביום?" value={hours} onValue={setHours} min={0} max={24} step="0.5" hint="משמש לזיהוי עומס יתר. 0 = ללא בדיקה" />
        <NumberInput label="מאיזה ציון יום נחשב מוצלח?" value={threshold} onValue={setThreshold} min={0} max={100} hint="ימים מעל הסף נספרים ברצף" />
        {error ? <p className="text-[13px] text-danger">{error}</p> : null}
      </div>
    </Sheet>
  );
}
