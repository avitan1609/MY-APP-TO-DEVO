import { useEffect, useRef, useState, type ReactNode } from 'react';
import { parseBackup, type BackupFile } from '../core/backup';
import { deviceTimeZone } from '../core/dates';
import { newCategory } from '../core/factories';
import { FORMULA_VERSION } from '../core/score';
import type { Category, Settings, ThemePref } from '../core/types';
import { validateSettings, type Errors } from '../core/validation';
import { destroyDB, openDB } from '../data/db';
import { exportAll, hasContent, importAll, pendingChanges, saveCategory, saveSettings } from '../data/repo';
import { supabase } from '../data/supabase';
import { useAuth } from '../state/auth';
import { useApp, useCategories } from '../state/app';
import { IconPlus } from '../ui/icons';
import { Button, ConfirmSheet, NumberInput, PageHeader, SectionTitle, Segmented, Select, TextInput, Toggle, useToast } from '../ui/kit';

const TIMEZONES = ['Asia/Jerusalem', 'Europe/London', 'Europe/Berlin', 'Europe/Athens', 'America/New_York', 'America/Chicago', 'America/Los_Angeles', 'Asia/Dubai', 'Asia/Bangkok', 'Australia/Sydney', 'UTC'];
const SWATCHES = ['#2DB5A3', '#3B82F6', '#8B5CF6', '#0EA5E9', '#F59E0B', '#EC4899', '#64748B', '#22C55E', '#EF4444', '#A16207'];

export function SettingsScreen() {
  const { settings, ctx, sync, syncState, account, db } = useApp();
  const auth = useAuth();
  const toast = useToast();
  const [draft, setDraft] = useState<Settings>(settings);
  const [errors, setErrors] = useState<Errors>({});
  const [pending, setPending] = useState<number | null>(null);
  const [importFile, setImportFile] = useState<BackupFile | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [confirmWipe, setConfirmWipe] = useState(false);
  const [deleteText, setDeleteText] = useState('');
  const [localData, setLocalData] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => setDraft(settings), [settings]);
  useEffect(() => {
    void pendingChanges(db).then(setPending);
  }, [db, syncState]);
  useEffect(() => {
    if (account.mode !== 'cloud') return;
    void hasContent(openDB('local')).then(async (has) => setLocalData(has && !(await db.meta.get('importedLocal'))));
  }, [account.mode, db]);

  const dirty = JSON.stringify({ ...draft, theme: settings.theme, remindersEnabled: settings.remindersEnabled }) !== JSON.stringify(settings);

  const saveDay = async () => {
    const e = validateSettings(draft);
    setErrors(e);
    if (Object.keys(e).length) return;
    await saveSettings(ctx, { ...draft, theme: settings.theme, remindersEnabled: settings.remindersEnabled });
    toast('ההגדרות נשמרו');
  };

  const patchNow = async (p: Partial<Settings>) => saveSettings(ctx, { ...settings, ...p });

  const download = (name: string, content: string, type: string) => {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const exportJson = async () => {
    const b = await exportAll(db);
    download(`sa-discipline-backup-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(b, null, 2), 'application/json');
    toast('הגיבוי ירד למכשיר');
  };

  const exportCsv = async () => {
    const b = await exportAll(db);
    const title = new Map(b.tasks.map((t) => [t.id, t.title]));
    const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const rows = [['date', 'task', 'status', 'value', 'distance_km', 'duration_min', 'note'].join(',')];
    for (const l of [...b.logs].sort((x, y) => x.date.localeCompare(y.date))) rows.push([l.date, title.get(l.taskId) ?? '', l.status, l.value, l.distanceKm, l.durationMin, l.note].map(esc).join(','));
    download(`sa-discipline-logs-${new Date().toISOString().slice(0, 10)}.csv`, '﻿' + rows.join('\n'), 'text/csv;charset=utf-8');
  };

  const onFile = async (f: File | undefined) => {
    if (!f) return;
    if (f.size > 20 * 1024 * 1024) return toast('הקובץ גדול מדי', 'error');
    try {
      setImportFile(parseBackup(await f.text()));
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const enableReminders = async (on: boolean) => {
    if (on) {
      if (!('Notification' in window)) return toast('הדפדפן לא תומך בהתראות', 'error');
      const p = await Notification.requestPermission();
      if (p !== 'granted') return toast('לא ניתנה הרשאה להתראות', 'error');
    }
    await patchNow({ remindersEnabled: on });
  };

  const deleteAccount = async () => {
    try {
      if (account.mode === 'cloud') {
        const { error } = await supabase!.rpc('delete_my_account');
        if (error) throw error;
      }
      sync.stop();
      await destroyDB(account.id);
      await auth.signOut();
      try {
        localStorage.removeItem('sa-local-mode');
      } catch {
        /* ignore */
      }
      window.location.replace('/');
    } catch {
      toast('המחיקה נכשלה. בדוק חיבור ונסה שוב.', 'error');
    }
  };

  return (
    <div>
      <PageHeader title="הגדרות" />

      <SectionTitle>חשבון וסנכרון</SectionTitle>
      <div className="card space-y-3 p-4 text-[14px]">
        {account.mode === 'cloud' ? (
          <>
            <Row label="מחובר בתור">{account.email}</Row>
            <Row label="מצב סנכרון">
              {{ idle: 'מסונכרן', syncing: 'מסנכרן…', offline: 'לא מקוון', error: 'שגיאה', local: 'מקומי' }[syncState.status]}
              {syncState.lastSyncAt ? <span className="text-faint"> · {new Date(syncState.lastSyncAt).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' })}</span> : null}
            </Row>
            <Row label="שינויים שממתינים להעלאה">{pending ?? '—'}</Row>
            {syncState.error ? <p className="text-[12px] text-danger">{syncState.error}</p> : null}
            <div className="flex flex-wrap gap-2 pt-1">
              <Button size="sm" onClick={() => void sync.sync()} disabled={syncState.status === 'syncing'}>
                סנכרן עכשיו
              </Button>
              <Button size="sm" variant="ghost" onClick={() => void auth.signOut()}>
                התנתקות
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setConfirmWipe(true)}>
                התנתקות ומחיקה מהמכשיר
              </Button>
            </div>
            {localData ? (
              <div className="rounded-xl bg-raised p-3 text-[13px]">
                נמצאו במכשיר נתונים ששמרת לפני ההתחברות.
                <Button
                  size="sm"
                  variant="primary"
                  className="ms-2"
                  onClick={async () => {
                    await importAll(ctx, await exportAll(openDB('local')));
                    await db.meta.put({ key: 'importedLocal', value: true });
                    setLocalData(false);
                    toast('הנתונים המקומיים יובאו לחשבון');
                  }}
                >
                  ייבא לחשבון
                </Button>
              </div>
            ) : null}
          </>
        ) : (
          <>
            <p className="text-muted">מצב מקומי: הנתונים נשמרים רק במכשיר הזה, ללא סנכרון וללא גיבוי בענן. מומלץ לייצא גיבוי מדי פעם.</p>
            {auth.cloudConfigured ? (
              <Button size="sm" variant="primary" onClick={auth.leaveLocal}>
                התחברות לחשבון (הנתונים המקומיים יישמרו לייבוא)
              </Button>
            ) : (
              <p className="text-[12px] text-faint">חשבון ענן יופעל אחרי חיבור Supabase (ראה README).</p>
            )}
          </>
        )}
      </div>

      <SectionTitle>מראה</SectionTitle>
      <div className="card p-4">
        <Segmented<ThemePref>
          value={settings.theme}
          onChange={(theme) => void patchNow({ theme })}
          options={[
            { value: 'system', label: 'לפי המכשיר' },
            { value: 'dark', label: 'כהה' },
            { value: 'light', label: 'בהיר' },
          ]}
        />
      </div>

      <SectionTitle>היום שלי</SectionTitle>
      <div className="card space-y-4 p-4">
        <div className="grid grid-cols-2 gap-3">
          <TextInput label="שעת סיכום יומי" type="time" value={draft.summaryTime} onChange={(e) => setDraft({ ...draft, summaryTime: e.target.value })} error={errors.summaryTime} />
          <NumberInput
            label="קיבולת יומית (שעות)"
            value={Math.round((draft.dailyCapacityMin / 60) * 10) / 10}
            onValue={(v) => setDraft({ ...draft, dailyCapacityMin: Math.round((v ?? 0) * 60) })}
            min={0}
            max={24}
            step="0.5"
            hint="0 = בלי בדיקת עומס"
            error={errors.dailyCapacityMin}
          />
          <NumberInput label="סף רצף (ציון)" value={draft.streakThreshold} onValue={(v) => setDraft({ ...draft, streakThreshold: v ?? 0 })} min={0} max={100} error={errors.streakThreshold} />
          <Select label="אזור זמן" value={draft.timezone} onChange={(e) => setDraft({ ...draft, timezone: e.target.value })}>
            {[...new Set([draft.timezone, deviceTimeZone(), ...TIMEZONES])].map((tz) => (
              <option key={tz} value={tz}>
                {tz}
              </option>
            ))}
          </Select>
        </div>
        <div>
          <span className="label">משקלי ציון</span>
          <div className="grid grid-cols-3 gap-3">
            {(['normal', 'important', 'critical'] as const).map((k) => (
              <NumberInput
                key={k}
                label={{ normal: 'רגילה', important: 'חשובה', critical: 'קריטית' }[k]}
                value={draft.weights[k]}
                onValue={(v) => setDraft({ ...draft, weights: { ...draft.weights, [k]: v ?? 0 } })}
                min={0.1}
                max={10}
                step="0.5"
                error={errors[`weights.${k}`]}
              />
            ))}
          </div>
          <p className="mt-2 text-[12px] text-muted">
            ציון = 100 × Σ(משקל × ביצוע) / Σ(משקל). ביצוע מספרי מוגבל ל־100%. "לא רלוונטי" לא נספר. נוסחה {FORMULA_VERSION}.
          </p>
        </div>
        <Button variant="primary" disabled={!dirty} onClick={() => void saveDay()}>
          שמירת הגדרות
        </Button>
      </div>

      <SectionTitle>תזכורות</SectionTitle>
      <div className="card p-4">
        <Toggle checked={settings.remindersEnabled} onChange={(v) => void enableReminders(v)} label="תזכורת לסיכום היומי" description={`בשעה ${settings.summaryTime}, כשהאפליקציה פתוחה או מותקנת ופעילה ברקע`} />
        <p className="mt-2 text-[12px] text-faint">התראות כשהאפליקציה סגורה לגמרי דורשות שרת Push — מתוכנן לשלב 2.</p>
      </div>

      <SectionTitle>קטגוריות</SectionTitle>
      <Categories />

      <SectionTitle>נתונים וגיבוי</SectionTitle>
      <div className="card flex flex-wrap gap-2 p-4">
        <Button size="sm" onClick={() => void exportJson()}>
          ייצוא גיבוי מלא (JSON)
        </Button>
        <Button size="sm" onClick={() => void exportCsv()}>
          ייצוא ביצועים (CSV)
        </Button>
        <Button size="sm" onClick={() => fileRef.current?.click()}>
          שחזור מגיבוי
        </Button>
        <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={(e) => void onFile(e.target.files?.[0])} />
      </div>

      <SectionTitle>אזור מסוכן</SectionTitle>
      <div className="card space-y-3 border-danger/30 p-4">
        <p className="text-[13px] text-muted">
          {account.mode === 'cloud' ? 'מחיקת החשבון מוחקת לצמיתות את כל הנתונים מהענן ומהמכשיר.' : 'מחיקת הנתונים מוחקת לצמיתות את כל מה ששמור במכשיר הזה.'} מומלץ לייצא גיבוי קודם.
        </p>
        <Button variant="danger" size="sm" onClick={() => setConfirmDelete(true)}>
          {account.mode === 'cloud' ? 'מחיקת חשבון' : 'מחיקת כל הנתונים'}
        </Button>
      </div>

      <p className="mt-8 text-center text-[12px] text-faint">SA · משמעת · גרסה 0.1.0 · נוסחת ציון {FORMULA_VERSION}</p>

      <ConfirmSheet
        open={!!importFile}
        title="שחזור מגיבוי"
        body={
          importFile ? (
            <>
              הגיבוי מ־{new Date(importFile.exportedAt).toLocaleDateString('he-IL')} כולל {importFile.tasks.length} משימות, {importFile.logs.length} רישומי ביצוע ו־{importFile.goals.length} מטרות. הנתונים
              ימוזגו לתוך החשבון הנוכחי; רשומות עם אותו מזהה יוחלפו.
            </>
          ) : null
        }
        confirmLabel="שחזר"
        onClose={() => setImportFile(null)}
        onConfirm={async () => {
          if (importFile) await importAll(ctx, importFile);
          setImportFile(null);
          toast('השחזור הושלם');
        }}
      />
      <ConfirmSheet
        open={confirmWipe}
        title="התנתקות ומחיקה מהמכשיר"
        body={pending ? `יש ${pending} שינויים שעוד לא עלו לענן ויאבדו. סנכרן קודם.` : 'הנתונים יימחקו מהמכשיר הזה בלבד. בענן הם נשמרים.'}
        confirmLabel="התנתק ומחק"
        danger
        onClose={() => setConfirmWipe(false)}
        onConfirm={async () => {
          sync.stop();
          await destroyDB(account.id);
          await auth.signOut();
          window.location.replace('/');
        }}
      />
      <ConfirmSheet
        open={confirmDelete}
        title="מחיקה לצמיתות"
        body={
          <div className="space-y-3">
            <p>זו פעולה בלתי הפיכה. כדי לאשר, הקלד "מחק".</p>
            <input className="field" value={deleteText} onChange={(e) => setDeleteText(e.target.value)} aria-label='הקלד "מחק" לאישור' />
          </div>
        }
        confirmLabel="מחק לצמיתות"
        danger
        onClose={() => {
          setConfirmDelete(false);
          setDeleteText('');
        }}
        onConfirm={async () => {
          if (deleteText.trim() !== 'מחק') return toast('יש להקליד "מחק"', 'error');
          await deleteAccount();
        }}
      />
    </div>
  );
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-muted">{label}</span>
      <span className="min-w-0 truncate text-end">{children}</span>
    </div>
  );
}

function Categories() {
  const { ctx, account } = useApp();
  const cats = useCategories(true);
  const toast = useToast();
  const [name, setName] = useState('');
  const [color, setColor] = useState(SWATCHES[0]);

  const add = async () => {
    const n = name.trim();
    if (!n) return;
    if (n.length > 60) return toast('עד 60 תווים', 'error');
    await saveCategory(ctx, newCategory(account.id, n, color, (cats?.length ?? 0) + 1));
    setName('');
  };

  return (
    <div className="card divide-y divide-line">
      {cats?.map((c) => <CategoryRow key={c.id} c={c} />)}
      <div className="flex flex-wrap items-center gap-2 p-3">
        <input className="field min-w-0 flex-1 py-2" placeholder="קטגוריה חדשה" value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && void add()} aria-label="שם קטגוריה חדשה" />
        <ColorPick value={color} onChange={setColor} />
        <Button size="sm" onClick={() => void add()}>
          <IconPlus size={15} /> הוסף
        </Button>
      </div>
    </div>
  );
}

function CategoryRow({ c }: { c: Category }) {
  const { ctx } = useApp();
  const [name, setName] = useState(c.name);
  useEffect(() => setName(c.name), [c.name]);
  return (
    <div className={`flex items-center gap-2 px-3 py-2 ${c.archived ? 'opacity-50' : ''}`}>
      <ColorPick value={c.color} onChange={(color) => void saveCategory(ctx, { ...c, color })} />
      <input
        className="min-w-0 flex-1 bg-transparent px-1 py-1.5 text-[14px] outline-none focus:ring-0"
        value={name}
        maxLength={60}
        onChange={(e) => setName(e.target.value)}
        onBlur={() => name.trim() && name !== c.name && void saveCategory(ctx, { ...c, name: name.trim() })}
        aria-label="שם קטגוריה"
      />
      <Button size="sm" variant="ghost" onClick={() => void saveCategory(ctx, { ...c, archived: !c.archived })}>
        {c.archived ? 'החזר' : 'הסתר'}
      </Button>
    </div>
  );
}

function ColorPick({ value, onChange }: { value: string; onChange: (c: string) => void }) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      aria-label="צבע"
      className="h-8 w-8 cursor-pointer appearance-none rounded-full border-2 border-line text-transparent"
      style={{ background: value }}
    >
      {[...new Set([value, ...SWATCHES])].map((s) => (
        <option key={s} value={s} style={{ background: s, color: '#fff' }}>
          {s}
        </option>
      ))}
    </select>
  );
}
