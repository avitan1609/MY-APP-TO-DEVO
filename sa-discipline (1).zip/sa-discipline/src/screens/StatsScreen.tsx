import { useMemo, useState } from 'react';
import { Bar as RBar, BarChart, CartesianGrid, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { addDays, formatShortDate, range, startOfMonth, startOfWeek } from '../core/dates';
import { average, categoryRates, frequentlyPostponed, scoreSeries, weekdayAverages } from '../core/patterns';
import { isActiveOnDay } from '../core/planning';
import { plannedItemsForDate } from '../core/recurrence';
import { isComplete } from '../core/score';
import { bestDayStreak, dayStreak, habitCompletionRate, habitStreak } from '../core/streaks';
import { useApp, useCategories, useLogs, useSnapshots, useTasks } from '../state/app';
import { IconFlame } from '../ui/icons';
import { Bar, Empty, PageHeader, SectionTitle, Segmented, Stat } from '../ui/kit';
import { fmtNum } from '../ui/labels';
import { useThemeColors } from '../ui/useThemeColors';

type Range = '7' | '30' | '90';
const WD = ['א׳', 'ב׳', 'ג׳', 'ד׳', 'ה׳', 'ו׳', 'ש׳'];

export function StatsScreen() {
  const { today, settings } = useApp();
  const tasks = useTasks();
  const logs = useLogs();
  const snapshots = useSnapshots();
  const categories = useCategories(true);
  const colors = useThemeColors();
  const [rng, setRng] = useState<Range>('30');

  const data = useMemo(() => {
    if (!tasks || !logs || !snapshots) return null;
    const days = Number(rng);
    const from = addDays(today, -(days - 1));
    const dates = range(from, today);
    const snaps = new Map(snapshots);
    snaps.delete(today);
    const longDates = range(addDays(today, -179), today);
    const series = scoreSeries(tasks, logs, longDates, settings.weights, snaps);
    const inRange = dates.map((d) => ({ d, score: series.get(d) ?? null }));

    let planned = 0;
    let done = 0;
    for (const d of dates) {
      for (const i of plannedItemsForDate(tasks, logs, d)) {
        if (!isActiveOnDay(i)) continue;
        planned++;
        if (isComplete(i.task, i.log)) done++;
      }
    }

    // Weekly and monthly reports
    const weeks: Array<{ label: string; avg: number | null }> = [];
    for (let w = 0; w < 8; w++) {
      const start = addDays(startOfWeek(today, settings.weekStart), -7 * w);
      const ds = range(start, addDays(start, 6)).filter((d) => d <= today);
      weeks.push({ label: formatShortDate(start), avg: average(ds.map((d) => series.get(d))) });
    }
    const months: Array<{ label: string; avg: number | null }> = [];
    let m = startOfMonth(today);
    for (let i = 0; i < 6; i++) {
      const next = startOfMonth(addDays(m, 32));
      const ds = range(m, addDays(next, -1)).filter((d) => d <= today && d >= longDates[0]);
      months.push({ label: new Intl.DateTimeFormat('he-IL', { month: 'short', timeZone: 'UTC' }).format(new Date(m + 'T00:00:00Z')), avg: average(ds.map((d) => series.get(d))) });
      m = startOfMonth(addDays(m, -1));
    }

    return {
      inRange,
      avg: average(inRange.map((x) => x.score)),
      atOrAbove: inRange.filter((x) => x.score !== null && x.score >= settings.streakThreshold).length,
      streak: dayStreak(series, settings.streakThreshold, today),
      best: bestDayStreak(series, settings.streakThreshold),
      planned,
      done,
      weekday: weekdayAverages(new Map(inRange.map((x) => [x.d, x.score]))),
      cats: categoryRates(tasks, logs, dates, settings.weights),
      postponed: frequentlyPostponed(logs, addDays(today, -30)),
      habits: tasks
        .filter((t) => t.kind !== 'one_time' && !t.archived)
        .map((t) => ({ t, streak: habitStreak(t, logs, today), rate: habitCompletionRate(t, logs, from, today) }))
        .sort((a, b) => (b.rate ?? -1) - (a.rate ?? -1)),
      weeks: weeks.reverse(),
      months: months.reverse(),
    };
  }, [tasks, logs, snapshots, rng, today, settings]);

  if (!data) return <div className="h-40 animate-pulse rounded-2xl bg-raised" />;
  const catName = (id: string | null) => (id ? categories?.find((c) => c.id === id)?.name ?? 'קטגוריה שנמחקה' : 'ללא קטגוריה');
  const taskTitle = (id: string) => tasks?.find((t) => t.id === id)?.title ?? 'משימה שנמחקה';
  const hasScores = data.inRange.some((x) => x.score !== null);

  const tooltipStyle = { background: colors.surface, border: `1px solid ${colors.line}`, borderRadius: 12, color: colors.ink, fontSize: 12, direction: 'rtl' as const };

  return (
    <div>
      <PageHeader title="נתונים ומגמות" sub="מבוסס רק על מה שהזנת" />
      <div className="mb-4">
        <Segmented<Range>
          size="sm"
          value={rng}
          onChange={setRng}
          options={[
            { value: '7', label: '7 ימים' },
            { value: '30', label: '30 ימים' },
            { value: '90', label: '90 ימים' },
          ]}
        />
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 sm:gap-3">
        <Stat label="ממוצע ציון" value={data.avg === null ? '—' : Math.round(data.avg)} />
        <Stat label="ימים מעל הסף" value={`${data.atOrAbove}/${data.inRange.length}`} sub={`סף ${settings.streakThreshold}`} />
        <Stat label="רצף נוכחי" value={data.streak} sub={`שיא ${data.best}`} />
        <Stat label="ביצוע משימות" value={data.planned ? `${Math.round((data.done / data.planned) * 100)}%` : '—'} sub={`${data.done}/${data.planned}`} />
      </div>

      <SectionTitle>ציון יומי</SectionTitle>
      <div className="card p-3">
        {hasScores ? (
          <div dir="ltr" className="h-56 w-full">
            <ResponsiveContainer>
              <LineChart data={data.inRange.map((x) => ({ name: formatShortDate(x.d), score: x.score }))} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
                <CartesianGrid stroke={colors.line} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{ fill: colors.muted, fontSize: 11 }} tickLine={false} axisLine={{ stroke: colors.line }} minTickGap={16} />
                <YAxis domain={[0, 100]} ticks={[0, 25, 50, 75, 100]} tick={{ fill: colors.muted, fontSize: 11 }} tickLine={false} axisLine={false} />
                <ReferenceLine y={settings.streakThreshold} stroke={colors.warn} strokeDasharray="4 4" />
                <Tooltip contentStyle={tooltipStyle} formatter={(v) => [Math.round(Number(v)), 'ציון']} />
                <Line type="monotone" dataKey="score" stroke={colors.accent} strokeWidth={2.2} dot={Number(rng) <= 30 ? { r: 2.5, fill: colors.accent } : false} connectNulls={false} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <p className="py-10 text-center text-[13px] text-muted">עדיין אין מספיק נתונים. הגרף יתמלא אחרי כמה ימים של סימון משימות.</p>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <SectionTitle>ממוצע לפי יום בשבוע</SectionTitle>
          <div className="card p-3">
            <div dir="ltr" className="h-44 w-full">
              <ResponsiveContainer>
                <BarChart data={data.weekday.map((v, i) => ({ name: WD[i], v: v ?? 0, has: v !== null }))} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
                  <CartesianGrid stroke={colors.line} strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" tick={{ fill: colors.muted, fontSize: 11 }} tickLine={false} axisLine={{ stroke: colors.line }} />
                  <YAxis domain={[0, 100]} ticks={[0, 50, 100]} tick={{ fill: colors.muted, fontSize: 11 }} tickLine={false} axisLine={false} />
                  <Tooltip contentStyle={tooltipStyle} cursor={{ fill: colors.raised }} formatter={(v) => [Math.round(Number(v)), 'ממוצע']} />
                  <RBar dataKey="v" fill={colors.accent} radius={[6, 6, 0, 0]} isAnimationActive={false} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
        <div>
          <SectionTitle>ביצוע לפי קטגוריה</SectionTitle>
          <div className="card space-y-3 p-4">
            {data.cats.length === 0 ? <p className="text-[13px] text-muted">אין נתונים בטווח.</p> : null}
            {data.cats.slice(0, 7).map((c) => (
              <div key={c.categoryId ?? 'none'}>
                <div className="mb-1 flex justify-between text-[13px]">
                  <span className="truncate">{catName(c.categoryId)}</span>
                  <span className="num text-muted">{Math.round(c.rate * 100)}%</span>
                </div>
                <Bar value={c.rate} max={1} />
              </div>
            ))}
          </div>
        </div>
      </div>

      <SectionTitle>הרגלים ומשימות חוזרות</SectionTitle>
      {data.habits.length === 0 ? (
        <Empty title="אין הרגלים עדיין" />
      ) : (
        <div className="card divide-y divide-line">
          {data.habits.map(({ t, streak, rate }) => (
            <div key={t.id} className="flex items-center gap-3 px-4 py-2.5">
              <span className="min-w-0 flex-1 truncate text-[14px]">{t.title}</span>
              <span className="w-24">
                <Bar value={rate ?? 0} max={1} />
              </span>
              <span className="num w-10 text-end text-[13px] text-muted">{rate === null ? '—' : `${Math.round(rate * 100)}%`}</span>
              <span className="inline-flex w-12 items-center justify-end gap-1 text-[13px]" title="רצף">
                <IconFlame size={13} className={streak ? 'text-warn' : 'text-faint'} />
                <span className="num">{streak}</span>
              </span>
            </div>
          ))}
        </div>
      )}

      {data.postponed.length ? (
        <>
          <SectionTitle>נדחות שוב ושוב (30 יום)</SectionTitle>
          <div className="card divide-y divide-line">
            {data.postponed.map((p) => (
              <div key={p.taskId} className="flex items-center justify-between px-4 py-2.5 text-[14px]">
                <span className="truncate">{taskTitle(p.taskId)}</span>
                <span className="num shrink-0 text-warn">{p.moves} דחיות</span>
              </div>
            ))}
            <p className="px-4 py-2.5 text-[12px] text-muted">משימה שנדחית 3 פעמים ומעלה: תפרק אותה לצעד קטן, תשבץ אותה לבוקר, או תחליט שהיא לא חשובה ותמחק.</p>
          </div>
        </>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2">
        <Report title="דוח שבועי (ממוצע)" rows={data.weeks.map((w) => ({ label: `שבוע ${w.label}`, v: w.avg }))} />
        <Report title="דוח חודשי (ממוצע)" rows={data.months.map((m) => ({ label: m.label, v: m.avg }))} />
      </div>
    </div>
  );
}

function Report({ title, rows }: { title: string; rows: Array<{ label: string; v: number | null }> }) {
  return (
    <div>
      <SectionTitle>{title}</SectionTitle>
      <div className="card divide-y divide-line">
        {rows.map((r) => (
          <div key={r.label} className="flex items-center gap-3 px-4 py-2 text-[13px]">
            <span className="w-24 shrink-0 text-muted">{r.label}</span>
            <Bar value={r.v ?? 0} max={100} className="flex-1" />
            <span className="num w-8 text-end font-medium">{r.v === null ? '—' : fmtNum(r.v, 0)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
