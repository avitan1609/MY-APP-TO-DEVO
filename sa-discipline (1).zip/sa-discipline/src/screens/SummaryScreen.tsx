import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { coachMessage } from '../core/coach';
import { addDays, formatHebrewDate, isISODate, parseHHMM } from '../core/dates';
import { isScheduledOn } from '../core/recurrence';
import { buildDaySummary } from '../core/summary';
import { applyMove, getDay, saveDay, snapshotDay } from '../data/repo';
import { useApp, useDay, useLogs, useSnapshots, useTasks } from '../state/app';
import { IconCheck, IconChevronBack, IconChevronForward } from '../ui/icons';
import { Bar, Button, IconButton, PageHeader, ScoreRing, SectionTitle, Stat, TextArea, cx, useToast } from '../ui/kit';
import { fmtNum, minutesText, relDay } from '../ui/labels';

export function SummaryScreen() {
  const params = useParams();
  const { today, minutesNow, settings, ctx, account, db } = useApp();
  const date = params.date && isISODate(params.date) ? params.date : today;
  const tasks = useTasks();
  const logs = useLogs();
  const snapshots = useSnapshots();
  const day = useDay(date);
  const toast = useToast();
  const navigate = useNavigate();

  const summary = useMemo(() => {
    if (!tasks || !logs || !snapshots) return null;
    return buildDaySummary({ date, today, minutesNow, tasks, logs, settings, snapshots });
  }, [tasks, logs, snapshots, date, today, minutesNow, settings]);

  const [journal, setJournal] = useState('');
  const [blockers, setBlockers] = useState('');
  const [picked, setPicked] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (day === undefined) return;
    setJournal(day?.journal ?? '');
    setBlockers(day?.blockers ?? '');
  }, [day?.id, day === undefined]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!summary) return;
    setPicked((p) => {
      const next: Record<string, string> = {};
      for (const pr of summary.proposals) next[pr.item.task.id] = p[pr.item.task.id] ?? '';
      return next;
    });
  }, [summary?.proposals.length]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!summary) return <div className="h-40 animate-pulse rounded-2xl bg-raised" />;

  const summaryAt = parseHHMM(settings.summaryTime) ?? 1290;
  const dayOver = date < today || (date === today && minutesNow >= summaryAt);
  const coach = coachMessage({
    score: summary.snapshot.score,
    avg7: summary.avg7,
    streak: summary.streak,
    threshold: settings.streakThreshold,
    criticalOpen: summary.importantOpen.filter((i) => i.task.importance === 'critical').length,
    criticalMissed: dayOver ? summary.importantOpen.filter((i) => i.task.importance === 'critical').length : 0,
    recovery: summary.recovery,
    overloaded: summary.tomorrow.overloaded,
    dayOver: true,
  });
  const delta = summary.avg7 !== null && summary.snapshot.score !== null ? summary.snapshot.score - summary.avg7 : null;
  const selected = Object.entries(picked).filter(([, d]) => d);

  const close = async () => {
    setBusy(true);
    try {
      const base = await getDay(db, account.id, date);
      await saveDay(ctx, { ...base, journal, blockers });
      await snapshotDay(ctx, date, true);
      toast('היום נסגר. הציון נשמר עם פירוט מלא.');
    } finally {
      setBusy(false);
    }
  };

  const moveSelected = async () => {
    setBusy(true);
    try {
      for (const [taskId, to] of selected) {
        const pr = summary.proposals.find((p) => p.item.task.id === taskId);
        if (!pr || !isISODate(to) || to <= date) continue;
        if (pr.item.task.kind !== 'one_time' && isScheduledOn(pr.item.task, to)) continue;
        await applyMove(ctx, pr.item.task, date, to, pr.afterTheFact, today);
      }
      toast(`הועברו ${selected.length} משימות`);
      setPicked({});
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <PageHeader
        title="סיכום יום"
        sub={`${relDay(date, today)} · ${formatHebrewDate(date)}`}
        actions={
          <>
            <IconButton label="יום קודם" onClick={() => navigate(`/summary/${addDays(date, -1)}`)}>
              <IconChevronBack />
            </IconButton>
            <IconButton label="יום הבא" disabled={date >= today} onClick={() => navigate(`/summary/${addDays(date, 1)}`)} className="disabled:opacity-30">
              <IconChevronForward />
            </IconButton>
          </>
        }
      />

      <section className="card mb-4 flex flex-col items-center gap-4 p-5 sm:flex-row sm:items-center">
        <ScoreRing score={summary.snapshot.score} size={128} />
        <div className="w-full flex-1 space-y-2">
          <p className={cx('text-[15px] font-medium leading-snug', coach.tone === 'warn' ? 'text-warn' : coach.tone === 'good' ? 'text-accent' : 'text-ink')}>{coach.text}</p>
          {day?.summaryGeneratedAt ? (
            <p className="text-[12px] text-muted">
              נסגר ב־{new Date(day.summaryGeneratedAt).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit', timeZone: settings.timezone })} · נוסחה {day.scoreSnapshot?.formulaVersion}
            </p>
          ) : null}
        </div>
      </section>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 sm:gap-3">
        <Stat label="הושלמו" value={`${summary.done}/${summary.planned}`} />
        <Stat label="רצף" value={summary.streak} sub={`סף ${settings.streakThreshold}`} />
        <Stat label="ממוצע 7 ימים" value={summary.avg7 === null ? '—' : Math.round(summary.avg7)} sub={delta === null ? undefined : `${delta >= 0 ? '+' : ''}${Math.round(delta)} מול הממוצע`} />
        <Stat label="ממוצע 30 ימים" value={summary.avg30 === null ? '—' : Math.round(summary.avg30)} />
      </div>

      {summary.numeric.length ? (
        <>
          <SectionTitle>יעדים מספריים</SectionTitle>
          <div className="card divide-y divide-line">
            {summary.numeric.map((n) => (
              <div key={n.task.id} className="flex items-center gap-3 px-4 py-2.5 text-[14px]">
                <span className="min-w-0 flex-1 truncate">{n.task.title}</span>
                <Bar value={n.value} max={n.target} className="w-20" />
                <span className={cx('num w-28 text-end text-[13px]', n.met ? 'text-accent' : 'text-muted')}>
                  {fmtNum(n.value, 2)} / {fmtNum(n.target, 2)} {n.task.measure === 'duration' ? 'דק׳' : n.task.unit}
                </span>
              </div>
            ))}
          </div>
        </>
      ) : null}

      {summary.importantOpen.length ? (
        <>
          <SectionTitle>חשובות שלא הושלמו</SectionTitle>
          <ul className="card divide-y divide-line">
            {summary.importantOpen.map((i) => (
              <li key={i.task.id} className="flex items-center justify-between px-4 py-2.5 text-[14px]">
                <span className="truncate">{i.task.title}</span>
                <span className={cx('text-[12px]', i.task.importance === 'critical' ? 'text-danger' : 'text-warn')}>{i.task.importance === 'critical' ? 'קריטית' : 'חשובה'}</span>
              </li>
            ))}
          </ul>
        </>
      ) : null}

      <SectionTitle>פירוט הציון</SectionTitle>
      <div className="card overflow-x-auto">
        <table className="w-full text-[13px]">
          <thead className="text-muted">
            <tr className="border-b border-line">
              <th className="px-4 py-2 text-start font-medium">משימה</th>
              <th className="px-2 py-2 text-center font-medium">משקל</th>
              <th className="px-2 py-2 text-center font-medium">ביצוע</th>
              <th className="px-4 py-2 text-end font-medium">תרומה</th>
            </tr>
          </thead>
          <tbody>
            {summary.snapshot.lines.map((l) => (
              <tr key={l.taskId} className={cx('border-b border-line last:border-0', l.excluded && 'text-faint')}>
                <td className="max-w-[12rem] truncate px-4 py-2">
                  {l.title}
                  {l.excluded ? ' (לא נכלל)' : l.reason === 'moved' ? ' (הועבר)' : ''}
                </td>
                <td className="num px-2 py-2 text-center">{fmtNum(l.weight)}</td>
                <td className="num px-2 py-2 text-center">{l.excluded ? '—' : `${Math.round(l.ratio * 100)}%`}</td>
                <td className="num px-4 py-2 text-end">{l.excluded ? '—' : fmtNum(l.contribution, 2)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="border-t border-line font-medium">
              <td className="px-4 py-2" colSpan={3}>
                100 × {fmtNum(summary.snapshot.earned, 2)} / {fmtNum(summary.snapshot.totalWeight, 2)}
              </td>
              <td className="num px-4 py-2 text-end">{summary.snapshot.score === null ? 'אין נתונים' : fmtNum(summary.snapshot.score)}</td>
            </tr>
          </tfoot>
        </table>
      </div>

      {summary.proposals.length ? (
        <>
          <SectionTitle>מה שלא הושלם — להעביר?</SectionTitle>
          <div className="card divide-y divide-line">
            {summary.proposals.map((p) => {
              const id = p.item.task.id;
              const on = !!picked[id];
              return (
                <div key={id} className="flex flex-wrap items-center gap-3 px-4 py-2.5">
                  <button
                    type="button"
                    role="checkbox"
                    aria-checked={on}
                    onClick={() => setPicked((x) => ({ ...x, [id]: on ? '' : p.suggestion.date }))}
                    className={cx('flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-2', on ? 'border-accent bg-accent text-accent-ink' : 'border-line')}
                    aria-label={`העבר: ${p.item.task.title}`}
                  >
                    {on ? <IconCheck size={12} strokeWidth={3} /> : null}
                  </button>
                  <span className="min-w-0 flex-1 truncate text-[14px]">{p.item.task.title}</span>
                  {on ? (
                    <input type="date" className="field w-40 py-1.5 text-[13px]" value={picked[id]} min={addDays(date, 1)} onChange={(e) => setPicked((x) => ({ ...x, [id]: e.target.value }))} aria-label="תאריך יעד" />
                  ) : (
                    <span className="text-[12px] text-muted">הצעה: {relDay(p.suggestion.date, today)}</span>
                  )}
                </div>
              );
            })}
          </div>
          {summary.proposals[0]?.afterTheFact ? <p className="mt-2 text-[12px] text-muted">העברה אחרי שעת הסיכום לא מוחקת את המשימה מהיום — היא נספרת כ־0, כדי שהציון יישאר אמין.</p> : null}
          <Button className="mt-3" variant="primary" disabled={!selected.length} loading={busy} onClick={() => void moveSelected()}>
            אשר העברה ({selected.length})
          </Button>
        </>
      ) : null}

      <SectionTitle>מחר — {formatHebrewDate(summary.tomorrow.date, false)}</SectionTitle>
      <div className="card p-4">
        <div className="mb-2 flex justify-between text-[13px]">
          <span>
            {summary.tomorrow.items.length} משימות · {minutesText(summary.tomorrow.load)}
          </span>
          {summary.tomorrow.overloaded ? <span className="font-medium text-danger">מעל הקיבולת</span> : null}
        </div>
        {settings.dailyCapacityMin > 0 ? <Bar value={summary.tomorrow.load} max={settings.dailyCapacityMin} tone={summary.tomorrow.overloaded ? 'danger' : 'accent'} /> : null}
        {summary.recovery ? <p className="mt-3 text-[13px] text-warn">שלושה ימים מתחת לסף: תשאיר למחר רק את הקריטי ואת החשוב ביותר. העבר את השאר מתוך מסך מחר.</p> : null}
        <Link to={`/day/${summary.tomorrow.date}`} className="mt-3 inline-block text-[13px] text-accent underline-offset-4 hover:underline">
          פתח את מחר לתכנון
        </Link>
      </div>

      <SectionTitle>חסמים ויומן</SectionTitle>
      <div className="space-y-3">
        <TextArea label="מה עצר אותך היום?" value={blockers} onChange={(e) => setBlockers(e.target.value)} maxLength={2000} placeholder="עייפות, הסחות, עומס, תכנון לא מציאותי…" />
        <TextArea label="יומן" value={journal} onChange={(e) => setJournal(e.target.value)} maxLength={10000} placeholder="מה עבד, מה לומדים, מה משנים מחר" />
      </div>

      <div className="sticky bottom-[calc(72px+env(safe-area-inset-bottom))] z-20 mt-5 lg:bottom-4">
        <Button variant="primary" size="lg" className="w-full shadow-lg" loading={busy} onClick={() => void close()}>
          {day?.summaryGeneratedAt ? 'עדכן סיכום' : 'סגור את היום ושמור ציון'}
        </Button>
      </div>
    </div>
  );
}
