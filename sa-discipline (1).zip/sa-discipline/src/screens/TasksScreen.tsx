import { useMemo, useState } from 'react';
import { addDays } from '../core/dates';
import { habitCompletionRate, habitStreak } from '../core/streaks';
import type { Task } from '../core/types';
import { saveTask } from '../data/repo';
import { useApp, useCategories, useLogs, useTasks } from '../state/app';
import { IconFlag, IconFlame, IconPlus, IconSearch } from '../ui/icons';
import { Button, Empty, PageHeader, Segmented, cx, useToast } from '../ui/kit';
import { IMPORTANCE_LABEL, KIND_LABEL, minutesText, recurrenceText, relDay } from '../ui/labels';
import { useOverlays } from '../ui/Shell';

type Tab = 'active' | 'habits' | 'backlog' | 'done' | 'archived';

export function TasksScreen() {
  const { today, ctx } = useApp();
  const tasks = useTasks();
  const logs = useLogs();
  const categories = useCategories(true);
  const { editTask } = useOverlays();
  const toast = useToast();
  const [tab, setTab] = useState<Tab>('active');
  const [q, setQ] = useState('');
  const [cat, setCat] = useState<string>('');

  const catById = useMemo(() => new Map((categories ?? []).map((c) => [c.id, c])), [categories]);

  const list = useMemo(() => {
    if (!tasks) return [];
    const term = q.trim().toLowerCase();
    return tasks
      .filter((t) => {
        if (term && !(t.title.toLowerCase().includes(term) || t.description.toLowerCase().includes(term))) return false;
        if (cat && t.categoryId !== cat) return false;
        switch (tab) {
          case 'archived':
            return t.archived;
          case 'habits':
            return !t.archived && t.kind !== 'one_time';
          case 'backlog':
            return !t.archived && t.kind === 'one_time' && !t.date;
          case 'done':
            return !t.archived && t.kind === 'one_time' && !!t.date && t.date < today;
          case 'active':
            return !t.archived && (t.kind !== 'one_time' || (!!t.date && t.date >= today));
        }
      })
      .sort((a, b) => {
        if (tab === 'active' && a.kind === 'one_time' && b.kind === 'one_time') return (a.date ?? '').localeCompare(b.date ?? '');
        if (a.kind !== b.kind) return a.kind === 'one_time' ? 1 : -1;
        return a.title.localeCompare(b.title, 'he');
      });
  }, [tasks, q, cat, tab, today]);

  return (
    <div>
      <PageHeader
        title="משימות והרגלים"
        sub={tasks ? `${tasks.filter((t) => !t.archived).length} פעילות` : undefined}
        actions={
          <Button variant="primary" size="sm" onClick={() => editTask('new')}>
            <IconPlus size={16} /> חדשה
          </Button>
        }
      />

      <div className="mb-3 overflow-x-auto">
        <div className="min-w-[440px]">
          <Segmented<Tab>
            value={tab}
            onChange={setTab}
            size="sm"
            options={[
              { value: 'active', label: 'פעילות' },
              { value: 'habits', label: 'חוזרות והרגלים' },
              { value: 'backlog', label: 'ללא תאריך' },
              { value: 'done', label: 'עבר' },
              { value: 'archived', label: 'ארכיון' },
            ]}
          />
        </div>
      </div>

      <div className="mb-3 flex gap-2">
        <div className="relative flex-1">
          <IconSearch size={17} className="pointer-events-none absolute start-3 top-1/2 -translate-y-1/2 text-faint" />
          <input className="field ps-9" placeholder="חיפוש" value={q} onChange={(e) => setQ(e.target.value)} aria-label="חיפוש משימות" />
        </div>
        <select className="field w-40" value={cat} onChange={(e) => setCat(e.target.value)} aria-label="סינון לפי קטגוריה">
          <option value="">כל הקטגוריות</option>
          {categories
            ?.filter((c) => !c.archived)
            .map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
        </select>
      </div>

      {!tasks ? (
        <div className="h-32 animate-pulse rounded-2xl bg-raised" />
      ) : list.length === 0 ? (
        <Empty
          title={tab === 'backlog' ? 'אין משימות ממתינות' : 'אין משימות כאן'}
          body={tab === 'habits' ? 'הרגל = משימה חוזרת עם רצף משלה. לדוגמה: פיזיותרפיה 3 פעמים בשבוע.' : undefined}
          action={
            <Button variant="primary" onClick={() => editTask('new', tab === 'habits' ? { kind: 'habit', date: null, recurrence: { type: 'daily', startDate: today } } : tab === 'backlog' ? { date: null } : undefined)}>
              <IconPlus size={16} /> משימה חדשה
            </Button>
          }
        />
      ) : (
        <ul className="space-y-2">
          {list.map((t) => (
            <li key={t.id}>
              <Row
                task={t}
                category={t.categoryId ? catById.get(t.categoryId) : undefined}
                streak={t.kind !== 'one_time' && logs ? habitStreak(t, logs, today) : null}
                rate={t.kind !== 'one_time' && logs ? habitCompletionRate(t, logs, addDays(today, -29), today) : null}
                today={today}
                onOpen={() => editTask(t.id)}
                onSchedule={
                  tab === 'backlog'
                    ? async () => {
                        await saveTask(ctx, { ...t, date: today });
                        toast('שובץ להיום');
                      }
                    : undefined
                }
                onRestore={
                  tab === 'archived'
                    ? async () => {
                        await saveTask(ctx, { ...t, archived: false });
                        toast('הוחזר מהארכיון');
                      }
                    : undefined
                }
                onArchive={
                  tab !== 'archived'
                    ? async () => {
                        await saveTask(ctx, { ...t, archived: true });
                        toast('הועבר לארכיון');
                      }
                    : undefined
                }
              />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Row({
  task,
  category,
  streak,
  rate,
  today,
  onOpen,
  onSchedule,
  onRestore,
  onArchive,
}: {
  task: Task;
  category?: { name: string; color: string };
  streak: number | null;
  rate: number | null;
  today: string;
  onOpen: () => void;
  onSchedule?: () => void;
  onRestore?: () => void;
  onArchive?: () => void;
}) {
  return (
    <div className="card flex items-center gap-3 px-4 py-3">
      <button type="button" onClick={onOpen} className="min-w-0 flex-1 text-start">
        <div className="flex items-center gap-2">
          {task.importance !== 'normal' ? <IconFlag size={14} className={cx('shrink-0', task.importance === 'critical' ? 'text-danger' : 'text-warn')} /> : null}
          <span className="truncate text-[15px] font-medium">{task.title}</span>
        </div>
        <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[12px] text-muted">
          <span>{task.kind === 'one_time' ? (task.date ? relDay(task.date, today) : 'ללא תאריך') : recurrenceText(task.recurrence)}</span>
          <span>{KIND_LABEL[task.kind]}</span>
          {task.importance !== 'normal' ? <span>{IMPORTANCE_LABEL[task.importance]}</span> : null}
          {category ? (
            <span className="inline-flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full" style={{ background: category.color }} />
              {category.name}
            </span>
          ) : null}
          {task.estMinutes ? <span>{minutesText(task.estMinutes)}</span> : null}
          {streak !== null ? (
            <span className="inline-flex items-center gap-1">
              <IconFlame size={13} className={streak ? 'text-warn' : 'text-faint'} />
              <span className="num">{streak}</span>
            </span>
          ) : null}
          {rate !== null ? <span className="num">{Math.round(rate * 100)}% ב־30 יום</span> : null}
        </div>
      </button>
      <div className="flex shrink-0 gap-1">
        {onSchedule ? (
          <Button size="sm" onClick={onSchedule}>
            להיום
          </Button>
        ) : null}
        {onRestore ? (
          <Button size="sm" onClick={onRestore}>
            שחזר
          </Button>
        ) : null}
        {onArchive ? (
          <Button size="sm" variant="ghost" onClick={onArchive} aria-label={`העבר לארכיון: ${task.title}`}>
            ארכיון
          </Button>
        ) : null}
      </div>
    </div>
  );
}
