import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { addDays, formatShortDate, hebrewWeekday, weekDates } from '../core/dates';
import { average } from '../core/patterns';
import { dayLoad, isActiveOnDay, sortItems } from '../core/planning';
import { plannedItemsForDate } from '../core/recurrence';
import { computeDailyScore, isComplete } from '../core/score';
import { useApp, useLogs, useSnapshots, useTasks } from '../state/app';
import { IconCheck, IconChevronBack, IconChevronForward, IconPlus } from '../ui/icons';
import { Bar, IconButton, PageHeader, Stat, cx } from '../ui/kit';
import { minutesText } from '../ui/labels';
import { useOverlays } from '../ui/Shell';

export function WeekScreen() {
  const { today, settings } = useApp();
  const tasks = useTasks();
  const logs = useLogs();
  const snapshots = useSnapshots();
  const navigate = useNavigate();
  const { quickAdd } = useOverlays();
  const [offset, setOffset] = useState(0);
  const dates = weekDates(addDays(today, offset * 7), settings.weekStart);

  const days = useMemo(() => {
    if (!tasks || !logs || !snapshots) return null;
    return dates.map((d) => {
      const items = sortItems(plannedItemsForDate(tasks, logs, d));
      const live = computeDailyScore(items, settings.weights).score;
      const score = d < today && snapshots.has(d) ? snapshots.get(d)! : live;
      const active = items.filter(isActiveOnDay);
      return { date: d, items, score, load: dayLoad(items), done: active.filter((i) => isComplete(i.task, i.log)).length, total: active.length };
    });
  }, [tasks, logs, snapshots, dates.join(), settings.weights, today]);

  if (!days) return <div className="h-40 animate-pulse rounded-2xl bg-raised" />;

  const past = days.filter((d) => d.date <= today);
  const avg = average(past.map((d) => d.score));
  const done = days.reduce((a, d) => a + d.done, 0);
  const total = days.reduce((a, d) => a + d.total, 0);
  const load = days.reduce((a, d) => a + d.load, 0);

  return (
    <div>
      <PageHeader
        title="תכנון שבועי"
        sub={`${formatShortDate(dates[0])} – ${formatShortDate(dates[6])}`}
        actions={
          <>
            <IconButton label="שבוע קודם" onClick={() => setOffset((o) => o - 1)}>
              <IconChevronBack />
            </IconButton>
            {offset !== 0 ? (
              <button type="button" className="px-2 text-[13px] text-accent" onClick={() => setOffset(0)}>
                השבוע
              </button>
            ) : null}
            <IconButton label="שבוע הבא" onClick={() => setOffset((o) => o + 1)}>
              <IconChevronForward />
            </IconButton>
          </>
        }
      />

      <div className="mb-5 grid grid-cols-3 gap-2 sm:gap-3">
        <Stat label="ממוצע ציון" value={avg === null ? '—' : Math.round(avg)} />
        <Stat label="הושלמו" value={`${done}/${total}`} />
        <Stat label="עומס שבועי" value={minutesText(load)} />
      </div>

      <ul className="space-y-2.5">
        {days.map((d) => {
          const over = settings.dailyCapacityMin > 0 && d.load > settings.dailyCapacityMin;
          const isToday = d.date === today;
          return (
            <li key={d.date} className={cx('card overflow-hidden', isToday && 'border-accent/60')}>
              <div className="flex items-center gap-3 px-4 py-3">
                <button type="button" onClick={() => navigate(`/day/${d.date}`)} className="flex min-w-0 flex-1 items-center gap-3 text-start">
                  <div className="w-14 shrink-0">
                    <div className={cx('text-[14px] font-semibold', isToday && 'text-accent')}>{hebrewWeekday(d.date)}</div>
                    <div className="num text-start text-[12px] text-muted">{formatShortDate(d.date)}</div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="mb-1 flex items-center justify-between text-[12px] text-muted">
                      <span>
                        {d.total ? `${d.done}/${d.total} משימות` : 'אין משימות'}
                        {d.load ? ` · ${minutesText(d.load)}` : ''}
                      </span>
                      {over ? <span className="font-medium text-danger">עומס יתר</span> : null}
                    </div>
                    {settings.dailyCapacityMin > 0 ? <Bar value={d.load} max={settings.dailyCapacityMin} tone={over ? 'danger' : 'accent'} /> : null}
                  </div>
                  <div className="num w-10 shrink-0 text-center text-[18px] font-semibold">{d.date <= today && d.score !== null ? Math.round(d.score) : <span className="text-faint">—</span>}</div>
                </button>
                <IconButton label={`הוסף משימה ל${hebrewWeekday(d.date)}`} onClick={() => quickAdd(d.date)}>
                  <IconPlus size={18} />
                </IconButton>
              </div>
              {d.items.length ? (
                <div className="flex flex-wrap gap-1.5 border-t border-line px-4 py-2.5">
                  {d.items.slice(0, 8).map((i) => {
                    const ok = isComplete(i.task, i.log);
                    const off = !isActiveOnDay(i);
                    return (
                      <span
                        key={i.task.id}
                        className={cx(
                          'inline-flex max-w-[12rem] items-center gap-1 truncate rounded-lg px-2 py-1 text-[12px]',
                          ok ? 'bg-accent-soft text-accent' : off ? 'bg-raised text-faint line-through' : i.task.importance === 'critical' ? 'bg-danger/10 text-danger' : 'bg-raised text-muted',
                        )}
                      >
                        {ok ? <IconCheck size={12} strokeWidth={3} /> : null}
                        <span className="truncate">{i.task.title}</span>
                      </span>
                    );
                  })}
                  {d.items.length > 8 ? <span className="px-1 py-1 text-[12px] text-faint">+{d.items.length - 8}</span> : null}
                </div>
              ) : null}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
