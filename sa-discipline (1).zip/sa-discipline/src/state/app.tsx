/**
 * App context for a signed-in account: local DB, repo ctx, sync engine,
 * live settings, the user's "today" in their time zone, theme and reminders.
 */
import { useLiveQuery } from 'dexie-react-hooks';
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { deviceTimeZone, minutesNowIn, parseHHMM, todayIn } from '../core/dates';
import { defaultSettings } from '../core/factories';
import type { Category, DayEntry, Goal, ISODate, Settings, Task, TaskLog } from '../core/types';
import { getMeta, openDB, setMeta, type AppDB } from '../data/db';
import { ensureSeed, finalizePastDays, type Ctx } from '../data/repo';
import { supabase } from '../data/supabase';
import { SyncEngine, type SyncState } from '../data/sync';
import type { Account } from './auth';

interface AppValue {
  account: Account;
  db: AppDB;
  ctx: Ctx;
  sync: SyncEngine;
  syncState: SyncState;
  settings: Settings;
  today: ISODate;
  minutesNow: number;
  ready: boolean;
}

const AppCtx = createContext<AppValue | null>(null);

export function AppProvider({ account, children }: { account: Account; children: ReactNode }) {
  const db = useMemo(() => openDB(account.id), [account.id]);
  const sync = useMemo(() => new SyncEngine(db, account.id, supabase), [db, account.id]);
  const ctx = useMemo<Ctx>(() => ({ db, userId: account.id, notify: sync.schedule }), [db, account.id, sync]);
  const [syncState, setSyncState] = useState<SyncState>(sync.state);
  const [seeded, setSeeded] = useState(false);
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    let alive = true;
    ensureSeed(ctx, deviceTimeZone())
      .catch((e) => console.error('[seed]', e))
      .finally(() => alive && setSeeded(true));
    const unsub = sync.subscribe(setSyncState);
    sync.start();
    return () => {
      alive = false;
      unsub();
      sync.stop();
    };
  }, [ctx, sync]);

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30_000);
    const vis = () => document.visibilityState === 'visible' && setNow(new Date());
    document.addEventListener('visibilitychange', vis);
    return () => {
      clearInterval(t);
      document.removeEventListener('visibilitychange', vis);
    };
  }, []);

  const stored = useLiveQuery(() => db.settings.get('settings'), [db]);
  const settings: Settings = useMemo(() => {
    if (stored && !stored.deleted) {
      const { _dirty, ...s } = stored;
      void _dirty;
      return s;
    }
    return defaultSettings(account.id, deviceTimeZone());
  }, [stored, account.id]);

  const today = todayIn(settings.timezone, now);
  const minutesNow = minutesNowIn(settings.timezone, now);

  // Freeze yesterday's score etc. once per day.
  useEffect(() => {
    if (seeded) void finalizePastDays(ctx, today).catch((e) => console.error('[finalize]', e));
  }, [seeded, ctx, today]);

  // Theme
  useEffect(() => {
    const apply = () => {
      const dark = settings.theme === 'dark' || (settings.theme === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
      document.documentElement.classList.toggle('dark', dark);
    };
    apply();
    try {
      localStorage.setItem('sa-theme', settings.theme);
    } catch {
      /* ignore */
    }
    const mq = matchMedia('(prefers-color-scheme: dark)');
    mq.addEventListener('change', apply);
    return () => mq.removeEventListener('change', apply);
  }, [settings.theme]);

  // End-of-day reminder (while the app is open or installed and alive in the background)
  useEffect(() => {
    if (!seeded || !settings.remindersEnabled) return;
    const at = parseHHMM(settings.summaryTime);
    if (at === null || minutesNow < at) return;
    void (async () => {
      const key = `notified:${today}`;
      if (await getMeta(db, key)) return;
      const day = await db.days.get(`day:${today}`);
      if (day?.summaryGeneratedAt) return;
      await setMeta(db, key, true);
      await showNotification('הגיע זמן הסיכום היומי', 'שתי דקות: סגור את היום ותכנן את מחר.');
    })();
  }, [seeded, settings.remindersEnabled, settings.summaryTime, minutesNow, today, db]);

  const value: AppValue = { account, db, ctx, sync, syncState, settings, today, minutesNow, ready: seeded && stored !== undefined };
  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

async function showNotification(title: string, body: string) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  try {
    const reg = await navigator.serviceWorker?.getRegistration();
    if (reg) await reg.showNotification(title, { body, icon: '/icon-192.png', badge: '/icon-192.png', tag: 'daily-summary', lang: 'he', dir: 'rtl' });
    else new Notification(title, { body, icon: '/icon-192.png', lang: 'he', dir: 'rtl' });
  } catch (e) {
    console.warn('[notify]', e);
  }
}

export function useApp() {
  const v = useContext(AppCtx);
  if (!v) throw new Error('useApp outside AppProvider');
  return v;
}

// ---------------------------------------------------------------------------
// Live data hooks
// ---------------------------------------------------------------------------
const strip = <T,>(r: T & { _dirty: 0 | 1 }): T => {
  const { _dirty, ...rest } = r;
  void _dirty;
  return rest as T;
};

export function useTasks(): Task[] | undefined {
  const { db } = useApp();
  return useLiveQuery(async () => (await db.tasks.filter((t) => !t.deleted).toArray()).map(strip), [db]);
}

export function useLogs(): TaskLog[] | undefined {
  const { db } = useApp();
  return useLiveQuery(async () => (await db.logs.filter((l) => !l.deleted).toArray()).map(strip), [db]);
}

export function useCategories(includeArchived = false): Category[] | undefined {
  const { db } = useApp();
  return useLiveQuery(
    async () =>
      (await db.categories.orderBy('sortOrder').toArray())
        .filter((c) => !c.deleted && (includeArchived || !c.archived))
        .map(strip),
    [db, includeArchived],
  );
}

export function useGoals(): Goal[] | undefined {
  const { db } = useApp();
  return useLiveQuery(async () => (await db.goals.filter((g) => !g.deleted).toArray()).map(strip), [db]);
}

export function useDays(): DayEntry[] | undefined {
  const { db } = useApp();
  return useLiveQuery(async () => (await db.days.filter((d) => !d.deleted).toArray()).map(strip), [db]);
}

export function useDay(date: ISODate): DayEntry | null | undefined {
  const { db } = useApp();
  return useLiveQuery(async () => {
    const d = await db.days.get(`day:${date}`);
    return d && !d.deleted ? strip(d) : null;
  }, [db, date]);
}

/** Map date → frozen snapshot score (for history consistency). */
export function useSnapshots(): Map<ISODate, number | null> | undefined {
  const days = useDays();
  return useMemo(() => {
    if (!days) return undefined;
    const m = new Map<ISODate, number | null>();
    for (const d of days) if (d.scoreSnapshot) m.set(d.date, d.scoreSnapshot.score);
    return m;
  }, [days]);
}
