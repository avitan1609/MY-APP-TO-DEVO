import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { authErrorMessage, cloudConfigured, supabase } from '../data/supabase';

export interface Account {
  id: string;
  email: string | null;
  mode: 'cloud' | 'local';
}

interface AuthValue {
  status: 'loading' | 'signedOut' | 'signedIn';
  account: Account | null;
  cloudConfigured: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string) => Promise<'confirm' | 'done'>;
  signInWithGoogle: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  continueLocal: () => void;
  /** Leave local mode to sign in with a cloud account (local data can then be imported). */
  leaveLocal: () => void;
  signOut: () => Promise<void>;
}

const LOCAL_FLAG = 'sa-local-mode';
const LOCAL: Account = { id: 'local', email: null, mode: 'local' };
const Ctx = createContext<AuthValue | null>(null);

function readLocalFlag() {
  try {
    return localStorage.getItem(LOCAL_FLAG) === '1';
  } catch {
    return false;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<AuthValue['status']>('loading');
  const [account, setAccount] = useState<Account | null>(null);

  useEffect(() => {
    if (!cloudConfigured || !supabase || readLocalFlag()) {
      setAccount(LOCAL);
      setStatus('signedIn');
      return;
    }
    let alive = true;
    // getSession reads the persisted session — works offline.
    supabase.auth.getSession().then(({ data }) => {
      if (!alive) return;
      const u = data.session?.user;
      setAccount(u ? { id: u.id, email: u.email ?? null, mode: 'cloud' } : null);
      setStatus(u ? 'signedIn' : 'signedOut');
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_evt, session) => {
      if (readLocalFlag()) return;
      const u = session?.user;
      setAccount(u ? { id: u.id, email: u.email ?? null, mode: 'cloud' } : null);
      setStatus(u ? 'signedIn' : 'signedOut');
    });
    return () => {
      alive = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const wrap = <A extends unknown[], R>(fn: (...a: A) => Promise<R>) =>
    async (...a: A): Promise<R> => {
      try {
        return await fn(...a);
      } catch (e) {
        throw new Error(authErrorMessage(e));
      }
    };

  const signIn = useCallback(
    wrap(async (email: string, password: string) => {
      const { error } = await supabase!.auth.signInWithPassword({ email, password });
      if (error) throw error;
    }),
    [],
  );

  const signUp = useCallback(
    wrap(async (email: string, password: string) => {
      const { data, error } = await supabase!.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin } });
      if (error) throw error;
      return data.session ? ('done' as const) : ('confirm' as const);
    }),
    [],
  );

  const signInWithGoogle = useCallback(
    wrap(async () => {
      const { error } = await supabase!.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: window.location.origin } });
      if (error) throw error;
    }),
    [],
  );

  const resetPassword = useCallback(
    wrap(async (email: string) => {
      const { error } = await supabase!.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin });
      if (error) throw error;
    }),
    [],
  );

  const continueLocal = useCallback(() => {
    try {
      localStorage.setItem(LOCAL_FLAG, '1');
    } catch {
      /* storage blocked — local mode for this session only */
    }
    setAccount(LOCAL);
    setStatus('signedIn');
  }, []);

  const leaveLocal = useCallback(() => {
    try {
      localStorage.removeItem(LOCAL_FLAG);
    } catch {
      /* ignore */
    }
    setAccount(null);
    setStatus('signedOut');
  }, []);

  const signOut = useCallback(async () => {
    if (account?.mode === 'cloud' && supabase) await supabase.auth.signOut({ scope: 'local' });
    setAccount(null);
    setStatus(cloudConfigured ? 'signedOut' : 'signedIn');
    if (!cloudConfigured) setAccount(LOCAL);
  }, [account]);

  const value = useMemo<AuthValue>(
    () => ({ status, account, cloudConfigured, signIn, signUp, signInWithGoogle, resetPassword, continueLocal, leaveLocal, signOut }),
    [status, account, signIn, signUp, signInWithGoogle, resetPassword, continueLocal, leaveLocal, signOut],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth outside AuthProvider');
  return v;
}
