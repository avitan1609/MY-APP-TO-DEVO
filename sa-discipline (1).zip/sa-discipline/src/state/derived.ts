import { useMemo } from 'react';
import { sortItems } from '../core/planning';
import { plannedItemsForDate } from '../core/recurrence';
import { computeDailyScore } from '../core/score';
import type { ISODate } from '../core/types';
import { useApp, useLogs, useTasks } from './app';

/** Everything a day view needs, computed from live data. */
export function useDayItems(date: ISODate) {
  const { settings } = useApp();
  const tasks = useTasks();
  const logs = useLogs();
  return useMemo(() => {
    if (!tasks || !logs) return null;
    const items = sortItems(plannedItemsForDate(tasks, logs, date));
    const score = computeDailyScore(items, settings.weights);
    return { tasks, logs, items, score };
  }, [tasks, logs, date, settings.weights]);
}
