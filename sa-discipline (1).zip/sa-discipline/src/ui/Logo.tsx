/** The SA monogram. Two pre-rendered variants switch with the theme via CSS (no JS flash). */
export function Logo({ size = 32, className }: { size?: number; className?: string }) {
  return (
    <span className={className} style={{ width: size, height: size, display: 'inline-block', flexShrink: 0 }}>
      <img src="/logo-light.png" alt="SA" width={size} height={size} className="block dark:hidden" draggable={false} />
      <img src="/logo-dark.png" alt="SA" width={size} height={size} className="hidden dark:block" draggable={false} />
    </span>
  );
}
