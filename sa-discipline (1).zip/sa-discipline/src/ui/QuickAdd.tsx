import { useEffect, useState } from 'react';
import { addDays } from '../core/dates';
import { newTask } from '../core/factories';
import type { Importance, ISODate, Task } from '../core/types';
import { validateTask } from '../core/validation';
import { saveTask } from '../data/repo';
import { useApp, useCategories } from '../state/app';
import { Button, NumberInput, Segmented, Select, Sheet, TextInput, useToast } from './kit';
import { IMPORTANCE_LABEL } from './labels';

type When = 'today' | 'tomorrow' | 'backlog';

/** Fast capture: title + when + importance. "More details" hands off to the full editor. */
export function QuickAdd({ open, onClose, onMore, defaultDate }: { open: boolean; onClose: () => void; onMore: (preset: Partial<Task>) => void; defaultDate?: ISODate }) {
  const { account, today, ctx } = useApp();
  const categories = useCategories();
  const toast = useToast();
  const [title, setTitle] = useState('');
  const [when, setWhen] = useState<When>('today');
  const [importance, setImportance] = useState<Importance>('normal');
  const [categoryId, setCategoryId] = useState('');
  const [est, setEst] = useState<number | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!open) return;
    setTitle('');
    setError('');
    setImportance('normal');
    setEst(null);
    setWhen(defaultDate && defaultDate !== today ? (defaultDate === addDays(today, 1) ? 'tomorrow' : 'today') : 'today');
  }, [open, defaultDate, today]);

  const date: ISODate | null = defaultDate && defaultDate !== today && defaultDate !== addDays(today, 1) && when === 'today' ? defaultDate : when === 'today' ? today : when === 'tomorrow' ? addDays(today, 1) : null;

  const build = () => newTask(account.id, today, { title: title.trim(), date, importance, categoryId: categoryId || null, estMinutes: est });

  const submit = async (keepOpen: boolean) => {
    const t = build();
    const e = validateTask(t);
    if (Object.keys(e).length) return setError(e.title ?? e.estMinutes ?? 'בדוק את הפרטים');
    await saveTask(ctx, t);
    toast('נוסף');
    if (keepOpen) {
      setTitle('');
      setError('');
    } else onClose();
  };

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="הוספה מהירה"
      footer={
        <>
          <Button variant="primary" onClick={() => void submit(false)}>
            הוסף
          </Button>
          <Button onClick={() => void submit(true)}>הוסף ועוד</Button>
          <Button
            variant="ghost"
            className="ms-auto"
            onClick={() => {
              const { title: t, date: d, importance: i, categoryId: c, estMinutes: m } = build();
              onMore({ title: t, date: d, importance: i, categoryId: c, estMinutes: m });
            }}
          >
            פרטים נוספים
          </Button>
        </>
      }
    >
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          void submit(false);
        }}
      >
        <TextInput value={title} onChange={(e) => setTitle(e.target.value)} placeholder="מה צריך לעשות?" aria-label="שם המשימה" error={error} maxLength={120} data-autofocus />
        <Segmented<When>
          value={when}
          onChange={setWhen}
          options={[
            { value: 'today', label: defaultDate && defaultDate !== today && defaultDate !== addDays(today, 1) ? 'ביום הנבחר' : 'היום' },
            { value: 'tomorrow', label: 'מחר' },
            { value: 'backlog', label: 'ללא תאריך' },
          ]}
        />
        <Segmented<Importance> value={importance} onChange={setImportance} options={(['normal', 'important', 'critical'] as const).map((k) => ({ value: k, label: IMPORTANCE_LABEL[k] }))} />
        <div className="grid grid-cols-2 gap-3">
          <Select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} aria-label="קטגוריה">
            <option value="">ללא קטגוריה</option>
            {categories?.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </Select>
          <NumberInput value={est} onValue={(v) => setEst(v === null ? null : Math.round(v))} placeholder="דקות משוערות" aria-label="זמן משוער בדקות" min={0} max={1440} />
        </div>
        <button type="submit" className="hidden" aria-hidden="true" tabIndex={-1} />
      </form>
    </Sheet>
  );
}
