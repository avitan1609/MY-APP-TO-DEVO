import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import type { ISODate, PlannedItem, Task } from '../core/types';
import { useApp } from '../state/app';
import { IconChart, IconCloud, IconCloudOff, IconDevice, IconList, IconPlus, IconSettings, IconSummary, IconTarget, IconToday, IconWeek } from './icons';
import { cx } from './kit';
import { Logo } from './Logo';
import { QuickAdd } from './QuickAdd';
import { TaskDetail } from './TaskDetail';
import { TaskEditor } from './TaskEditor';

interface Overlays {
  quickAdd: (date?: ISODate) => void;
  editTask: (id: string | 'new', preset?: Partial<Task>) => void;
  openItem: (item: PlannedItem) => void;
}
const OverlayCtx = createContext<Overlays | null>(null);
export function useOverlays() {
  const v = useContext(OverlayCtx);
  if (!v) throw new Error('useOverlays outside Shell');
  return v;
}

type NavItem = { to: string; label: string; icon: (p: { size?: number }) => JSX.Element; end?: boolean };
const NAV: NavItem[] = [
  { to: '/', label: 'היום', icon: IconToday, end: true },
  { to: '/week', label: 'שבוע', icon: IconWeek },
  { to: '/tasks', label: 'משימות', icon: IconList },
  { to: '/goals', label: 'מטרות', icon: IconTarget },
  { to: '/stats', label: 'נתונים', icon: IconChart },
];
const NAV_DESKTOP_EXTRA: NavItem[] = [
  { to: '/summary', label: 'סיכום יום', icon: IconSummary },
  { to: '/settings', label: 'הגדרות', icon: IconSettings },
];

export function Shell({ children }: { children: ReactNode }) {
  const [quick, setQuick] = useState<{ open: boolean; date?: ISODate }>({ open: false });
  const [editor, setEditor] = useState<{ id: string | null; preset?: Partial<Task> }>({ id: null });
  const [item, setItem] = useState<PlannedItem | null>(null);
  const loc = useLocation();

  const overlays = useMemo<Overlays>(
    () => ({
      quickAdd: (date) => setQuick({ open: true, date }),
      editTask: (id, preset) => setEditor({ id, preset }),
      openItem: (i) => setItem(i),
    }),
    [],
  );

  // Keyboard: "n" opens quick add (when not typing).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (e.key === 'n' && !e.metaKey && !e.ctrlKey && !/INPUT|TEXTAREA|SELECT/.test(t.tagName) && !t.isContentEditable && !document.querySelector('[role="dialog"]')) {
        e.preventDefault();
        setQuick({ open: true });
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  useEffect(() => window.scrollTo(0, 0), [loc.pathname]);
  const closeQuick = useCallback(() => setQuick({ open: false }), []);
  const closeEditor = useCallback(() => setEditor({ id: null }), []);
  const closeItem = useCallback(() => setItem(null), []);

  return (
    <OverlayCtx.Provider value={overlays}>
      <div className="min-h-dvh lg:flex">
        {/* Desktop sidebar (start side = right in RTL) */}
        <aside className="sticky top-0 hidden h-dvh w-60 shrink-0 flex-col border-e border-line bg-surface px-3 py-5 lg:flex">
          <div className="mb-6 flex items-center gap-2.5 px-2">
            <Logo size={34} />
            <div className="leading-tight">
              <div className="text-[15px] font-bold">משמעת</div>
              <div className="text-[11px] text-muted">מערכת אישית</div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setQuick({ open: true })}
            className="mb-4 flex h-10 items-center justify-center gap-2 rounded-xl bg-accent text-[14px] font-medium text-accent-ink hover:brightness-110"
          >
            <IconPlus size={18} /> משימה חדשה
          </button>
          <nav className="flex flex-col gap-0.5" aria-label="ניווט ראשי">
            {[...NAV, ...NAV_DESKTOP_EXTRA].map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                end={n.end}
                className={({ isActive }) =>
                  cx('flex h-10 items-center gap-3 rounded-xl px-3 text-[14px] transition', isActive ? 'bg-raised font-semibold text-ink' : 'text-muted hover:bg-raised hover:text-ink')
                }
              >
                <n.icon size={19} />
                {n.label}
              </NavLink>
            ))}
          </nav>
          <div className="mt-auto px-2">
            <SyncBadge full />
          </div>
        </aside>

        <div className="min-w-0 flex-1">
          {/* Mobile top bar */}
          <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-line bg-bg/85 px-4 backdrop-blur lg:hidden">
            <NavLink to="/" className="flex items-center gap-2" aria-label="מסך הבית">
              <Logo size={28} />
              <span className="text-[15px] font-bold">משמעת</span>
            </NavLink>
            <div className="flex items-center gap-1">
              <SyncBadge />
              <NavLink to="/summary" className="flex h-10 w-10 items-center justify-center rounded-xl text-muted hover:bg-raised" aria-label="סיכום יום">
                <IconSummary size={20} />
              </NavLink>
              <NavLink to="/settings" className="flex h-10 w-10 items-center justify-center rounded-xl text-muted hover:bg-raised" aria-label="הגדרות">
                <IconSettings size={20} />
              </NavLink>
            </div>
          </header>

          <main className="mx-auto w-full max-w-3xl px-4 pb-32 pt-5 sm:px-6 lg:pb-12 lg:pt-8">{children}</main>
        </div>

        {/* Mobile FAB + bottom nav */}
        <button
          type="button"
          onClick={() => setQuick({ open: true })}
          aria-label="הוספת משימה"
          className="fixed bottom-[calc(76px+env(safe-area-inset-bottom))] end-4 z-30 flex h-14 w-14 items-center justify-center rounded-2xl bg-accent text-accent-ink shadow-lg shadow-black/30 lg:hidden"
        >
          <IconPlus size={26} />
        </button>
        <nav className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface/95 backdrop-blur lg:hidden" aria-label="ניווט ראשי">
          <div className="mx-auto flex max-w-lg">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                end={n.end}
                className={({ isActive }) => cx('flex h-16 flex-1 flex-col items-center justify-center gap-1 text-[11px]', isActive ? 'font-semibold text-accent' : 'text-muted')}
              >
                <n.icon size={21} />
                {n.label}
              </NavLink>
            ))}
          </div>
        </nav>
      </div>

      <QuickAdd
        open={quick.open}
        defaultDate={quick.date}
        onClose={closeQuick}
        onMore={(preset) => {
          setQuick({ open: false });
          setEditor({ id: 'new', preset });
        }}
      />
      <TaskEditor taskId={editor.id} preset={editor.preset} onClose={closeEditor} />
      <TaskDetail
        item={item}
        onClose={closeItem}
        onEdit={(id) => {
          setItem(null);
          setEditor({ id });
        }}
      />
    </OverlayCtx.Provider>
  );
}

function SyncBadge({ full }: { full?: boolean }) {
  const { syncState, account } = useApp();
  const map = {
    local: { icon: IconDevice, text: 'שמור במכשיר בלבד', tone: 'text-muted' },
    offline: { icon: IconCloudOff, text: 'לא מקוון — נשמר מקומית', tone: 'text-warn' },
    idle: { icon: IconCloud, text: 'מסונכרן', tone: 'text-muted' },
    syncing: { icon: IconCloud, text: 'מסנכרן…', tone: 'text-accent' },
    error: { icon: IconCloudOff, text: 'שגיאת סנכרון — ינסה שוב', tone: 'text-danger' },
  } as const;
  const s = map[syncState.status];
  return (
    <NavLink to="/settings" className={cx('flex items-center gap-2 rounded-xl text-[12px]', full ? 'py-2' : 'h-10 w-10 justify-center', s.tone)} title={s.text} aria-label={s.text}>
      <s.icon size={full ? 16 : 19} className={syncState.status === 'syncing' ? 'animate-pulse' : undefined} />
      {full ? (
        <span className="min-w-0">
          <span className="block">{s.text}</span>
          {account.email ? <span className="block truncate text-faint">{account.email}</span> : null}
        </span>
      ) : null}
    </NavLink>
  );
}
