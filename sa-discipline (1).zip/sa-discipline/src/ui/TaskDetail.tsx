import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { addDays } from '../core/dates';
import { formatPace, paceMinPerKm } from '../core/factories';
import { isAfterTheFact, loadForFactory, suggestDate } from '../core/planning';
import { isScheduledOn } from '../core/recurrence';
import { completionRatio, isComplete, taskWeight } from '../core/score';
import type { ISODate, PlannedItem } from '../core/types';
import { applyMove, setLog, toggleDone, toggleSubtask } from '../data/repo';
import { useApp, useLogs, useTasks } from '../state/app';
import { IconCheck, IconEdit, IconMove } from './icons';
import { Button, NumberInput, Sheet, TextArea, TextInput, cx, useToast } from './kit';
import { IMPORTANCE_LABEL, KIND_LABEL, fmtNum, minutesText, recurrenceText, relDay } from './labels';

export function TaskDetail({ item, onClose, onEdit }: { item: PlannedItem | null; onClose: () => void; onEdit: (taskId: string) => void }) {
  return (
    <Sheet open={!!item} onClose={onClose} title={item?.task.title ?? ''}>
      {item ? <Body item={item} onClose={onClose} onEdit={onEdit} /> : null}
    </Sheet>
  );
}

function Body({ item, onClose, onEdit }: { item: PlannedItem; onClose: () => void; onEdit: (taskId: string) => void }) {
  const { ctx, today, minutesNow, settings } = useApp();
  const toast = useToast();
  const tasks = useTasks();
  const logs = useLogs();
  // Re-read the live log so the sheet reflects changes immediately.
  const log = useMemo(() => logs?.find((l) => l.taskId === item.task.id && l.date === item.date) ?? item.log, [logs, item]);
  const task = useMemo(() => tasks?.find((t) => t.id === item.task.id) ?? item.task, [tasks, item]);
  const date = item.date;
  const done = isComplete(task, log);
  const inactive = log?.status === 'not_relevant' || log?.status === 'moved';

  const [value, setValue] = useState<number | null>(log?.value ?? null);
  const [dist, setDist] = useState<number | null>(log?.distanceKm ?? null);
  const [dur, setDur] = useState<number | null>(log?.durationMin ?? null);
  const [note, setNote] = useState(log?.note ?? '');
  useEffect(() => {
    setValue(log?.value ?? null);
    setDist(log?.distanceKm ?? null);
    setDur(log?.durationMin ?? null);
  }, [log?.value, log?.distanceKm, log?.durationMin]);

  const suggestion = useMemo(() => {
    if (!tasks || !logs) return null;
    return suggestDate(task, date, loadForFactory(tasks, logs), settings.dailyCapacityMin);
  }, [tasks, logs, task, date, settings.dailyCapacityMin]);
  const [moveTo, setMoveTo] = useState<ISODate | ''>('');
  useEffect(() => {
    if (suggestion && !moveTo) setMoveTo(suggestion.date);
  }, [suggestion, moveTo]);
  const afterTheFact = isAfterTheFact(date, today, minutesNow, settings.summaryTime);
  const moveError =
    moveTo && moveTo <= date
      ? 'יש לבחור תאריך אחרי היום הנוכחי'
      : moveTo && task.kind !== 'one_time' && isScheduledOn(task, moveTo)
        ? 'המשימה כבר מתוכננת בתאריך הזה'
        : '';

  const saveRun = async () => {
    const patch = { distanceKm: dist, durationMin: dur, note } as const;
    if (task.measure === 'binary') await setLog(ctx, task, date, { ...patch, status: dist || dur ? 'done' : log?.status ?? 'pending' }, today);
    else {
      const v = task.measure === 'duration' ? dur : (task.unit ?? '').includes('דק') ? dur : dist;
      await setLog(ctx, task, date, { ...patch, value: v }, today);
    }
    toast('נשמר');
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2 text-[12px]">
        <Chip>{KIND_LABEL[task.kind]}</Chip>
        <Chip>חשיבות {IMPORTANCE_LABEL[task.importance]} · משקל {fmtNum(taskWeight(task, settings.weights))}</Chip>
        {task.recurrence ? <Chip>{recurrenceText(task.recurrence)}</Chip> : null}
        {task.estMinutes ? <Chip>{minutesText(task.estMinutes)}</Chip> : null}
        <Chip>{relDay(date, today)}</Chip>
      </div>
      {task.description ? <p className="whitespace-pre-wrap text-[14px] text-muted">{task.description}</p> : null}

      {/* Progress */}
      {!inactive ? (
        <section className="space-y-3">
          {task.measure === 'binary' && task.activity !== 'run' ? (
            <Button variant={done ? 'secondary' : 'primary'} size="lg" className="w-full" onClick={() => void toggleDone(ctx, task, date, log, today)}>
              <IconCheck size={18} /> {done ? 'בטל סימון ביצוע' : 'סמן כבוצע'}
            </Button>
          ) : null}

          {task.activity === 'run' ? (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <NumberInput label='מרחק (ק"מ)' value={dist} onValue={setDist} min={0} step="0.01" />
                <NumberInput label="זמן (דקות)" value={dur} onValue={setDur} min={0} step="0.5" />
              </div>
              <div className="flex items-center justify-between rounded-xl bg-raised px-3 py-2 text-[13px]">
                <span className="text-muted">קצב</span>
                <span className="num font-semibold">{formatPace(paceMinPerKm(dist, dur))} דק׳/ק"מ</span>
              </div>
              <Button variant="primary" className="w-full" onClick={() => void saveRun()}>
                שמור ריצה
              </Button>
            </div>
          ) : task.measure !== 'binary' ? (
            <div className="flex items-end gap-2">
              <div className="flex-1">
                <NumberInput
                  label={`בוצע (${task.measure === 'duration' ? 'דקות' : task.unit ?? ''}) · יעד ${fmtNum(task.target, 2)}`}
                  value={value}
                  onValue={setValue}
                  min={0}
                  step="any"
                />
              </div>
              <Button
                variant="primary"
                onClick={() => {
                  void setLog(ctx, task, date, { value: value === null ? null : Math.max(0, value) }, today);
                  toast('נשמר');
                }}
              >
                שמור
              </Button>
            </div>
          ) : null}

          {task.measure !== 'binary' ? (
            <div className="text-[12px] text-muted">
              התקדמות: <span className="num font-semibold text-ink">{Math.round(completionRatio(task, log) * 100)}%</span>
            </div>
          ) : null}

          {task.subtasks.length ? (
            <ul className="space-y-1.5" aria-label="תתי־משימות">
              {task.subtasks.map((s) => {
                const on = (log?.subtaskDone ?? []).includes(s.id);
                return (
                  <li key={s.id}>
                    <button
                      type="button"
                      role="checkbox"
                      aria-checked={on}
                      onClick={() => void toggleSubtask(ctx, task, date, log, s.id, today)}
                      className="flex w-full items-center gap-3 rounded-xl px-2 py-1.5 text-start hover:bg-raised"
                    >
                      <span className={cx('flex h-5 w-5 items-center justify-center rounded-md border-2', on ? 'border-accent bg-accent text-accent-ink' : 'border-line')}>
                        {on ? <IconCheck size={12} strokeWidth={3} /> : null}
                      </span>
                      <span className={cx('text-[14px]', on && 'text-muted line-through')}>{s.title}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          ) : null}

          <TextArea
            label="הערה ליום הזה"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            onBlur={() => note !== (log?.note ?? '') && void setLog(ctx, task, date, { note }, today)}
            maxLength={2000}
            placeholder="מה עבד, מה עצר אותך"
          />
        </section>
      ) : (
        <div className="rounded-xl bg-raised px-3 py-2.5 text-[13px] text-muted">
          {log?.status === 'not_relevant' ? 'המשימה סומנה כלא רלוונטית ליום הזה ואינה נכללת בציון.' : `המשימה הועברה ל־${log?.movedTo ? relDay(log.movedTo, today) : ''}.`}
        </div>
      )}

      {/* Plan */}
      {!inactive && !done ? (
        <section className="space-y-2 rounded-2xl border border-line p-3">
          <h3 className="flex items-center gap-2 text-[14px] font-semibold">
            <IconMove size={16} /> העברה למועד אחר
          </h3>
          {suggestion ? (
            <p className="text-[12px] text-muted">
              הצעה: {relDay(suggestion.date, today)}
              {suggestion.fits ? ' — יש מקום ביום הזה.' : ' — אין יום פנוי לגמרי; זה היום הכי פחות עמוס.'}
              {!suggestion.beforeDeadline ? ' שים לב: אחרי הדדליין.' : ''}
            </p>
          ) : null}
          <div className="flex items-end gap-2">
            <div className="flex-1">
              <TextInput type="date" value={moveTo} min={addDays(date, 1)} onChange={(e) => setMoveTo(e.target.value)} aria-label="תאריך יעד" error={moveError} />
            </div>
            <Button
              variant="primary"
              disabled={!moveTo || !!moveError}
              onClick={async () => {
                await applyMove(ctx, task, date, moveTo as ISODate, afterTheFact, today);
                toast(`הועבר ל${relDay(moveTo as ISODate, today)}`);
                onClose();
              }}
            >
              אשר העברה
            </Button>
          </div>
          {afterTheFact ? <p className="text-[12px] text-warn">היום כבר עבר את שעת הסיכום — המשימה תיספר כ־0 ביום הזה.</p> : null}
        </section>
      ) : null}

      <div className="flex flex-wrap gap-2">
        {log?.status === 'not_relevant' ? (
          <Button onClick={() => void setLog(ctx, task, date, { status: 'pending' }, today)}>החזר ליום</Button>
        ) : !inactive ? (
          <Button
            onClick={() => {
              void setLog(ctx, task, date, { status: 'not_relevant' }, today);
              toast('סומן כלא רלוונטי להיום');
            }}
          >
            לא רלוונטי היום
          </Button>
        ) : null}
        <Button variant="ghost" onClick={() => onEdit(task.id)}>
          <IconEdit size={16} /> עריכת משימה
        </Button>
      </div>
    </div>
  );
}

function Chip({ children }: { children: ReactNode }) {
  return <span className="rounded-lg bg-raised px-2 py-1 text-muted">{children}</span>;
}
