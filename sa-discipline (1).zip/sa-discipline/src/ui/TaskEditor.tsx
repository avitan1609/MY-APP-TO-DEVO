import { useEffect, useState } from 'react';
import { weekday } from '../core/dates';
import { newTask, uid } from '../core/factories';
import type { Importance, Measure, Recurrence, RecurrenceType, Task, TaskKind, Urgency } from '../core/types';
import { validateTask, type Errors } from '../core/validation';
import { deleteTask, saveTask } from '../data/repo';
import { useApp, useCategories, useGoals, useTasks } from '../state/app';
import { IconPlus, IconTrash, IconX } from './icons';
import { Button, ConfirmSheet, IconButton, NumberInput, Segmented, Select, Sheet, TextArea, TextInput, Toggle, cx, useToast } from './kit';
import { IMPORTANCE_LABEL, KIND_LABEL, MEASURE_LABEL, URGENCY_LABEL } from './labels';

const DAYS = ['א׳', 'ב׳', 'ג׳', 'ד׳', 'ה׳', 'ו׳', 'ש׳'];

/** taskId: existing id to edit, 'new' for a new task, null = closed. */
export function TaskEditor({ taskId, onClose, preset }: { taskId: string | null; onClose: () => void; preset?: Partial<Task> }) {
  const { account, today, ctx } = useApp();
  const tasks = useTasks();
  const toast = useToast();
  const [draft, setDraft] = useState<Task | null>(null);
  const [errors, setErrors] = useState<Errors>({});
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    if (taskId === null) return setDraft(null);
    if (taskId === 'new') setDraft(newTask(account.id, today, preset));
    else {
      const t = tasks?.find((x) => x.id === taskId);
      if (t) setDraft(structuredClone(t));
    }
    setErrors({});
    // Re-run once tasks finish loading; not on every live update (would discard edits).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [taskId, tasks === undefined]);

  const isNew = taskId === 'new';
  const set = (p: Partial<Task>) => setDraft((d) => (d ? { ...d, ...p } : d));

  const save = async () => {
    if (!draft) return;
    const clean: Task = { ...draft, title: draft.title.trim(), unit: draft.unit?.trim() || null };
    if (clean.measure === 'binary') {
      clean.target = null;
      clean.unit = null;
    }
    if (clean.measure === 'duration') clean.unit = 'דקות';
    if (clean.kind === 'one_time') clean.recurrence = null;
    const e = validateTask(clean);
    setErrors(e);
    if (Object.keys(e).length) return;
    await saveTask(ctx, clean);
    toast(isNew ? 'המשימה נוספה' : 'המשימה עודכנה');
    onClose();
  };

  return (
    <>
      <Sheet
        open={!!draft}
        onClose={onClose}
        title={isNew ? 'משימה חדשה' : 'עריכת משימה'}
        wide
        footer={
          <>
            <Button variant="primary" onClick={() => void save()}>
              שמירה
            </Button>
            <Button variant="ghost" onClick={onClose}>
              ביטול
            </Button>
            {!isNew ? (
              <Button variant="danger" className="ms-auto" onClick={() => setConfirmDelete(true)}>
                <IconTrash size={16} /> מחיקה
              </Button>
            ) : null}
          </>
        }
      >
        {draft ? <Form draft={draft} set={set} errors={errors} /> : null}
      </Sheet>
      <ConfirmSheet
        open={confirmDelete}
        title="למחוק את המשימה?"
        body="המשימה תוסר מכל הימים הבאים. ציונים של ימים שכבר נסגרו נשמרים בהיסטוריה."
        confirmLabel="מחק"
        danger
        onClose={() => setConfirmDelete(false)}
        onConfirm={async () => {
          if (draft) await deleteTask(ctx, draft);
          setConfirmDelete(false);
          toast('המשימה נמחקה');
          onClose();
        }}
      />
    </>
  );
}

function Form({ draft, set, errors }: { draft: Task; set: (p: Partial<Task>) => void; errors: Errors }) {
  const { today } = useApp();
  const categories = useCategories();
  const goals = useGoals();
  const [more, setMore] = useState(!!(draft.description || draft.notes || draft.subtasks.length || draft.weightOverride || draft.deadline));

  const setKind = (kind: TaskKind) => {
    if (kind === 'one_time') set({ kind, recurrence: null, date: draft.date ?? today });
    else set({ kind, date: null, recurrence: draft.recurrence ?? { type: 'daily', startDate: today } });
  };
  const rec = draft.recurrence;
  const setRec = (p: Partial<Recurrence>) => set({ recurrence: { ...(rec ?? { type: 'daily', startDate: today }), ...p } });

  return (
    <div className="space-y-4">
      <TextInput
        label="שם המשימה"
        value={draft.title}
        onChange={(e) => set({ title: e.target.value })}
        error={errors.title}
        maxLength={120}
        placeholder="לדוגמה: אימון כוח — רגליים"
        data-autofocus
      />

      <Segmented<TaskKind> label="סוג" value={draft.kind} onChange={setKind} options={(['one_time', 'recurring', 'habit'] as const).map((k) => ({ value: k, label: KIND_LABEL[k] }))} />

      {draft.kind === 'one_time' ? (
        <div className="grid grid-cols-2 gap-3">
          <TextInput
            label="תאריך מתוכנן"
            type="date"
            value={draft.date ?? ''}
            onChange={(e) => set({ date: e.target.value || null })}
            error={errors.date}
            hint={draft.date ? undefined : 'ללא תאריך — נשמר ברשימת ההמתנה'}
          />
          <TextInput label="דדליין (אופציונלי)" type="date" value={draft.deadline ?? ''} onChange={(e) => set({ deadline: e.target.value || null })} error={errors.deadline} />
        </div>
      ) : (
        <div className="space-y-3 rounded-2xl border border-line p-3">
          <Segmented<RecurrenceType>
            label="תדירות"
            size="sm"
            value={rec?.type ?? 'daily'}
            onChange={(type) => setRec({ type, weekdays: type === 'weekly' ? rec?.weekdays ?? [weekday(today)] : rec?.weekdays, interval: type === 'interval' ? rec?.interval ?? 2 : rec?.interval, monthDay: type === 'monthly' ? rec?.monthDay ?? +today.slice(8, 10) : rec?.monthDay })}
            options={[
              { value: 'daily', label: 'כל יום' },
              { value: 'weekly', label: 'ימים בשבוע' },
              { value: 'interval', label: 'כל X ימים' },
              { value: 'monthly', label: 'חודשי' },
            ]}
          />
          {rec?.type === 'weekly' ? (
            <div className="flex gap-1.5" role="group" aria-label="ימים בשבוע">
              {DAYS.map((d, i) => {
                const on = rec.weekdays?.includes(i) ?? false;
                return (
                  <button
                    key={i}
                    type="button"
                    aria-pressed={on}
                    onClick={() => setRec({ weekdays: on ? rec.weekdays!.filter((x) => x !== i) : [...(rec.weekdays ?? []), i].sort() })}
                    className={cx('h-10 flex-1 rounded-xl border text-[13px] font-medium', on ? 'border-accent bg-accent text-accent-ink' : 'border-line text-muted')}
                  >
                    {d}
                  </button>
                );
              })}
            </div>
          ) : null}
          {rec?.type === 'interval' ? <NumberInput label="כל כמה ימים" value={rec.interval ?? null} onValue={(v) => setRec({ interval: v ?? undefined })} min={1} max={365} /> : null}
          {rec?.type === 'monthly' ? <NumberInput label="יום בחודש" value={rec.monthDay ?? null} onValue={(v) => setRec({ monthDay: v ?? undefined })} min={1} max={31} hint="31 = היום האחרון בחודש" /> : null}
          <div className="grid grid-cols-2 gap-3">
            <TextInput label="מתאריך" type="date" value={rec?.startDate ?? today} onChange={(e) => setRec({ startDate: e.target.value })} />
            <TextInput label="עד תאריך (אופציונלי)" type="date" value={rec?.endDate ?? ''} onChange={(e) => setRec({ endDate: e.target.value || null })} />
          </div>
          {errors.recurrence ? (
            <p className="text-[12px] text-danger" role="alert">
              {errors.recurrence}
            </p>
          ) : null}
        </div>
      )}

      <div className="grid grid-cols-2 gap-3">
        <Select label="חשיבות" value={draft.importance} onChange={(e) => set({ importance: e.target.value as Importance })}>
          {(['normal', 'important', 'critical'] as const).map((k) => (
            <option key={k} value={k}>
              {IMPORTANCE_LABEL[k]}
            </option>
          ))}
        </Select>
        <Select label="דחיפות" value={draft.urgency} onChange={(e) => set({ urgency: e.target.value as Urgency })}>
          {(['low', 'medium', 'high'] as const).map((k) => (
            <option key={k} value={k}>
              {URGENCY_LABEL[k]}
            </option>
          ))}
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Select label="קטגוריה" value={draft.categoryId ?? ''} onChange={(e) => set({ categoryId: e.target.value || null })}>
          <option value="">ללא</option>
          {categories?.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </Select>
        <NumberInput label="זמן משוער (דקות)" value={draft.estMinutes} onValue={(v) => set({ estMinutes: v === null ? null : Math.round(v) })} min={0} max={1440} error={errors.estMinutes} />
      </div>

      <Select label="מדידה" value={draft.measure} onChange={(e) => set({ measure: e.target.value as Measure })}>
        {(['binary', 'numeric', 'duration'] as const).map((k) => (
          <option key={k} value={k}>
            {MEASURE_LABEL[k]}
          </option>
        ))}
      </Select>
      {draft.measure !== 'binary' ? (
        <div className="grid grid-cols-2 gap-3">
          <NumberInput label={draft.measure === 'duration' ? 'יעד (דקות)' : 'יעד'} value={draft.target} onValue={(v) => set({ target: v })} min={0} step="any" error={errors.target} />
          {draft.measure === 'numeric' ? (
            <TextInput label="יחידה" value={draft.unit ?? ''} onChange={(e) => set({ unit: e.target.value })} placeholder='צעדים / עמודים / ק"מ' maxLength={30} error={errors.unit} list="unit-suggestions" />
          ) : null}
          <datalist id="unit-suggestions">
            {['צעדים', 'עמודים', 'ק"מ', 'דקות', 'שעות', 'חזרות', 'כוסות מים', 'ספרים'].map((u) => (
              <option key={u} value={u} />
            ))}
          </datalist>
        </div>
      ) : null}

      <Toggle checked={draft.activity === 'run'} onChange={(on) => set({ activity: on ? 'run' : 'none' })} label="מעקב ריצה" description='רישום מרחק וזמן, חישוב קצב אוטומטי' />

      {!more ? (
        <Button variant="ghost" size="sm" onClick={() => setMore(true)}>
          <IconPlus size={16} /> עוד אפשרויות: תתי־משימות, מטרה, תיאור, משקל
        </Button>
      ) : (
        <div className="space-y-4">
          <Select label="קישור למטרה" value={draft.goalId ?? ''} onChange={(e) => set({ goalId: e.target.value || null })}>
            <option value="">ללא</option>
            {goals
              ?.filter((g) => g.status === 'active')
              .map((g) => (
                <option key={g.id} value={g.id}>
                  {g.title}
                </option>
              ))}
          </Select>
          {draft.kind !== 'one_time' ? (
            <TextInput label="דדליין (אופציונלי)" type="date" value={draft.deadline ?? ''} onChange={(e) => set({ deadline: e.target.value || null })} error={errors.deadline} />
          ) : null}
          <NumberInput
            label="משקל מותאם לציון (אופציונלי)"
            hint="ריק = לפי החשיבות"
            value={draft.weightOverride}
            onValue={(v) => set({ weightOverride: v })}
            min={0.1}
            max={10}
            step="0.5"
            error={errors.weightOverride}
          />
          <Subtasks draft={draft} set={set} error={errors.subtasks} />
          <TextArea label="תיאור" value={draft.description} onChange={(e) => set({ description: e.target.value })} maxLength={2000} error={errors.description} />
          <TextArea label="הערות" value={draft.notes} onChange={(e) => set({ notes: e.target.value })} maxLength={5000} error={errors.notes} />
        </div>
      )}
    </div>
  );
}

function Subtasks({ draft, set, error }: { draft: Task; set: (p: Partial<Task>) => void; error?: string }) {
  const [text, setText] = useState('');
  const add = () => {
    const t = text.trim();
    if (!t) return;
    set({ subtasks: [...draft.subtasks, { id: uid(), title: t.slice(0, 120) }] });
    setText('');
  };
  return (
    <div>
      <span className="label">תתי־משימות</span>
      <ul className="mb-2 space-y-1.5">
        {draft.subtasks.map((s, i) => (
          <li key={s.id} className="flex items-center gap-2">
            <input
              className="field py-2"
              value={s.title}
              aria-label={`תת־משימה ${i + 1}`}
              onChange={(e) => set({ subtasks: draft.subtasks.map((x) => (x.id === s.id ? { ...x, title: e.target.value } : x)) })}
            />
            <IconButton label="הסר" onClick={() => set({ subtasks: draft.subtasks.filter((x) => x.id !== s.id) })}>
              <IconX size={16} />
            </IconButton>
          </li>
        ))}
      </ul>
      <div className="flex gap-2">
        <input
          className="field py-2"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              add();
            }
          }}
          placeholder="הוסף תת־משימה"
          aria-label="תת־משימה חדשה"
        />
        <Button onClick={add}>הוסף</Button>
      </div>
      {error ? <p className="mt-1 text-[12px] text-danger">{error}</p> : null}
    </div>
  );
}
