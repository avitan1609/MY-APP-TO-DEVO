import { useState, type ReactNode } from 'react';
import { completionRatio, isComplete } from '../core/score';
import type { Category, PlannedItem } from '../core/types';
import { setLog, toggleDone } from '../data/repo';
import { useApp } from '../state/app';
import { IconCheck, IconClock, IconFlag, IconMove, IconRun } from './icons';
import { cx } from './kit';
import { useThemeColors } from './useThemeColors';
import { fmtNum, minutesText } from './labels';

export function TaskRow({ item, category, onOpen }: { item: PlannedItem; category?: Category; onOpen: () => void }) {
  const { ctx, today } = useApp();
  const { task, log, date } = item;
  const done = isComplete(task, log);
  const cancelled = log?.status === 'not_relevant';
  const movedAway = log?.status === 'moved';
  const inactive = cancelled || movedAway;
  const ratio = completionRatio(task, log);
  const [quick, setQuick] = useState('');
  const colors = useThemeColors();

  const meta: ReactNode[] = [];
  if (category)
    meta.push(
      <span key="c" className="inline-flex items-center gap-1.5">
        <span className="h-2 w-2 rounded-full" style={{ background: category.color }} />
        {category.name}
      </span>,
    );
  if (task.estMinutes)
    meta.push(
      <span key="e" className="inline-flex items-center gap-1">
        <IconClock size={13} />
        {minutesText(task.estMinutes)}
      </span>,
    );
  if (task.subtasks.length)
    meta.push(
      <span key="s" className="num">
        {(log?.subtaskDone ?? []).filter((id) => task.subtasks.some((s) => s.id === id)).length}/{task.subtasks.length}
      </span>,
    );
  if (task.deadline) meta.push(<span key="d">דדליין {task.deadline.slice(8, 10)}.{+task.deadline.slice(5, 7)}</span>);
  if (log?.extra) meta.push(<span key="x">הועבר לכאן</span>);

  return (
    <div className={cx('card flex items-stretch gap-3 px-3 py-2.5 transition', inactive && 'opacity-55', task.importance === 'critical' && !done && !inactive && 'border-danger/40')}>
      {task.measure === 'binary' || inactive ? (
        <button
          type="button"
          disabled={inactive}
          onClick={() => void toggleDone(ctx, task, date, log, today)}
          aria-pressed={done}
          aria-label={done ? `בטל סימון: ${task.title}` : `סמן כבוצע: ${task.title}`}
          className={cx(
            'mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border-2 transition',
            done ? 'border-accent bg-accent text-accent-ink' : 'border-line hover:border-accent',
          )}
        >
          {done ? <IconCheck size={16} strokeWidth={2.6} /> : null}
        </button>
      ) : (
        <div className="relative mt-0.5 h-7 w-7 shrink-0" aria-hidden="true">
          <svg viewBox="0 0 28 28" className="-rotate-90">
            <circle cx="14" cy="14" r="12" fill="none" stroke={colors.line} strokeWidth="3" />
            <circle cx="14" cy="14" r="12" fill="none" stroke={colors.accent} strokeWidth="3" strokeLinecap="round" strokeDasharray={75.4} strokeDashoffset={75.4 * (1 - ratio)} />
          </svg>
          {done ? <IconCheck size={13} strokeWidth={3} className="absolute inset-0 m-auto text-accent" /> : null}
        </div>
      )}

      <button type="button" onClick={onOpen} className="min-w-0 flex-1 text-start">
        <div className="flex items-center gap-2">
          {task.importance !== 'normal' ? (
            <>
              <IconFlag size={14} className={task.importance === 'critical' ? 'shrink-0 text-danger' : 'shrink-0 text-warn'} />
              <span className="sr-only">{task.importance === 'critical' ? 'קריטית' : 'חשובה'}</span>
            </>
          ) : null}
          {task.activity === 'run' ? <IconRun size={15} className="shrink-0 text-muted" /> : null}
          <span className={cx('truncate text-[15px] font-medium', done && 'text-muted line-through decoration-1')}>{task.title}</span>
        </div>
        {meta.length || inactive ? (
          <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[12px] text-muted">
            {cancelled ? <span>בוטלה להיום</span> : null}
            {movedAway ? (
              <span className="inline-flex items-center gap-1">
                <IconMove size={13} /> הועברה{log?.movedTo ? ` ל־${log.movedTo.slice(8, 10)}.${+log.movedTo.slice(5, 7)}` : ''}
                {log?.counted ? ' · נספרה כ־0' : ''}
              </span>
            ) : null}
            {meta}
          </div>
        ) : null}
      </button>

      {task.measure !== 'binary' && !inactive ? (
        <form
          className="flex shrink-0 items-center gap-1.5"
          onSubmit={(e) => {
            e.preventDefault();
            const n = Number(quick);
            if (!quick.trim() || !Number.isFinite(n) || n < 0) return;
            void setLog(ctx, task, date, { value: (log?.value ?? 0) + n }, today);
            setQuick('');
          }}
        >
          <div className="text-end text-[12px] leading-tight text-muted">
            <div className="num text-[14px] font-semibold text-ink">{fmtNum(log?.value ?? 0, 2)}</div>
            <div className="num">/ {fmtNum(task.target, 2)}</div>
          </div>
          <input
            value={quick}
            onChange={(e) => setQuick(e.target.value)}
            inputMode="decimal"
            placeholder="+"
            aria-label={`הוסף כמות ל${task.title}`}
            className="field num h-9 w-16 px-2 py-1 text-center text-[14px]"
          />
        </form>
      ) : null}
    </div>
  );
}
