/**
 * Component smoke tests in jsdom (local mode, no Supabase env):
 * the app boots, shows Hebrew UI, and a task added via quick add appears on Today.
 */
import { act, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { beforeAll, describe, expect, it, vi } from 'vitest';
import { App } from '../../App';

beforeAll(() => {
  // jsdom gaps
  window.matchMedia ??= ((q: string) => ({ matches: false, media: q, addEventListener: () => {}, removeEventListener: () => {} })) as never;
  window.scrollTo = vi.fn() as never;
  globalThis.ResizeObserver ??= class {
    observe() {}
    unobserve() {}
    disconnect() {}
  } as never;
});


describe('app', () => {
  it('boots in local mode, onboards, and adds a task to today', async () => {
    render(<App />);
    // Onboarding sheet on first run
    const start = await screen.findByRole('button', { name: 'מתחילים' }, { timeout: 4000 });
    await act(async () => fireEvent.click(start));
    expect(await screen.findByRole('heading', { name: 'היום' })).toBeInTheDocument();
    expect(await screen.findByText('אין משימות מתוכננות')).toBeInTheDocument();

    fireEvent.click(screen.getAllByRole('button', { name: /הוסף משימה/ })[0]);
    const input = await screen.findByLabelText('שם המשימה');
    fireEvent.change(input, { target: { value: 'אימון כוח' } });
    await act(async () => fireEvent.click(screen.getByRole('button', { name: 'הוסף' })));

    await waitFor(() => expect(screen.getByText('אימון כוח')).toBeInTheDocument(), { timeout: 3000 });
    // Toggle done → score becomes 100
    await act(async () => fireEvent.click(screen.getByRole('button', { name: 'סמן כבוצע: אימון כוח' })));
    await waitFor(() => expect(screen.getByRole('img', { name: /ציון יומי: 100/ })).toBeInTheDocument());
  });
});
