/**
 * RTL guard: UI code must use logical Tailwind utilities (ms/me/ps/pe/start/end,
 * text-start/text-end, border-s/e, rounded-s/e) so layout mirrors correctly.
 * Physical left/right utilities are rejected.
 */
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const ROOT = resolve(process.cwd(), 'src');
const PHYSICAL = /(?<![\w-])(-?(?:ml|mr|pl|pr|left|right|border-l|border-r|rounded-l|rounded-r|rounded-tl|rounded-tr|rounded-bl|rounded-br)-[\w./[\]-]+|text-left|text-right|float-left|float-right)(?![\w-])/g;

function files(dir: string): string[] {
  return readdirSync(dir).flatMap((f) => {
    const p = join(dir, f);
    if (statSync(p).isDirectory()) return f === '__tests__' ? [] : files(p);
    return /\.tsx$/.test(f) ? [p] : [];
  });
}

describe('RTL-safe styling', () => {
  it('no physical left/right Tailwind classes in components', () => {
    const offenders: string[] = [];
    for (const f of files(ROOT)) {
      const src = readFileSync(f, 'utf8');
      for (const m of src.matchAll(/className=(?:"([^"]*)"|\{`([^`]*)`\}|\{cx\(([^)]*)\))/g)) {
        const cls = m[1] ?? m[2] ?? m[3] ?? '';
        for (const hit of cls.matchAll(PHYSICAL)) offenders.push(`${f.replace(ROOT, 'src')}: ${hit[0]}`);
      }
    }
    expect(offenders).toEqual([]);
  });

  it('document is Hebrew RTL', () => {
    const html = readFileSync(resolve(process.cwd(), 'index.html'), 'utf8');
    expect(html).toContain('<html lang="he" dir="rtl">');
  });
});
