/** Inline stroke icons (no icon dependency). 24px grid, currentColor. */
import type { ReactNode, SVGProps } from 'react';

type P = SVGProps<SVGSVGElement> & { size?: number };

function Base({ size = 20, children, ...rest }: P & { children: ReactNode }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...rest}
    >
      {children}
    </svg>
  );
}

export const IconToday = (p: P) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7.5V12l3 2" />
  </Base>
);
export const IconWeek = (p: P) => (
  <Base {...p}>
    <rect x="3.5" y="5" width="17" height="15" rx="2.5" />
    <path d="M3.5 10h17M8 3v4M16 3v4" />
  </Base>
);
export const IconList = (p: P) => (
  <Base {...p}>
    <path d="M9 6.5h11M9 12h11M9 17.5h11" />
    <path d="M4 6.5h.01M4 12h.01M4 17.5h.01" strokeWidth={2.6} />
  </Base>
);
export const IconTarget = (p: P) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <circle cx="12" cy="12" r="4.5" />
    <circle cx="12" cy="12" r="0.8" fill="currentColor" />
  </Base>
);
export const IconChart = (p: P) => (
  <Base {...p}>
    <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
  </Base>
);
export const IconSettings = (p: P) => (
  <Base {...p}>
    <path d="M4 7h10M18 7h2M4 17h4M12 17h8" />
    <circle cx="16" cy="7" r="2" />
    <circle cx="10" cy="17" r="2" />
  </Base>
);
export const IconSummary = (p: P) => (
  <Base {...p}>
    <path d="M6 3.5h9l3.5 3.5v13.5H6z" />
    <path d="M9 11h6M9 15h6M14.5 3.5V7H18" />
  </Base>
);
export const IconPlus = (p: P) => (
  <Base {...p}>
    <path d="M12 5v14M5 12h14" />
  </Base>
);
export const IconCheck = (p: P) => (
  <Base {...p}>
    <path d="M5 12.5l4.5 4.5L19 7.5" />
  </Base>
);
export const IconX = (p: P) => (
  <Base {...p}>
    <path d="M6 6l12 12M18 6L6 18" />
  </Base>
);
/** Points to the logical "forward" side: left in RTL. */
export const IconChevronForward = (p: P) => (
  <Base {...p} className={`rtl:-scale-x-100 ${p.className ?? ''}`}>
    <path d="M9 6l6 6-6 6" />
  </Base>
);
export const IconChevronBack = (p: P) => (
  <Base {...p} className={`rtl:-scale-x-100 ${p.className ?? ''}`}>
    <path d="M15 6l-6 6 6 6" />
  </Base>
);
export const IconClock = (p: P) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 8v4.5l2.5 1.5" />
  </Base>
);
export const IconFlag = (p: P) => (
  <Base {...p}>
    <path d="M5 21V4M5 4h11l-2 4 2 4H5" />
  </Base>
);
/** Arrow toward the logical "forward" side (left in RTL). */
export const IconMove = (p: P) => (
  <Base {...p} className={`rtl:-scale-x-100 ${p.className ?? ''}`}>
    <path d="M4 12h13M13 7l5 5-5 5" />
  </Base>
);
export const IconTrash = (p: P) => (
  <Base {...p}>
    <path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3" />
  </Base>
);
export const IconEdit = (p: P) => (
  <Base {...p}>
    <path d="M4 20h4L19 9l-4-4L4 16z" />
  </Base>
);
export const IconCloud = (p: P) => (
  <Base {...p}>
    <path d="M7 18h10a4 4 0 0 0 .5-7.97A5.5 5.5 0 0 0 7 9.5 4.25 4.25 0 0 0 7 18z" />
  </Base>
);
export const IconCloudOff = (p: P) => (
  <Base {...p}>
    <path d="M3 3l18 18M8.5 8.4A5.5 5.5 0 0 1 17.5 10a4 4 0 0 1 2.1 7M17 18H7a4.25 4.25 0 0 1-1.1-8.36" />
  </Base>
);
export const IconDevice = (p: P) => (
  <Base {...p}>
    <rect x="6" y="2.5" width="12" height="19" rx="2.5" />
    <path d="M11 18.5h2" />
  </Base>
);
export const IconRun = (p: P) => (
  <Base {...p}>
    <circle cx="14.5" cy="4.5" r="1.8" />
    <path d="M8 21l3-6 3 2.5V21M6.5 11.5l3-3.5 4 1 2.5 3 3 .5M11 15l-1.5-4" />
  </Base>
);
export const IconFlame = (p: P) => (
  <Base {...p}>
    <path d="M12 21c4 0 6.5-2.6 6.5-6.2 0-4.3-4-6.3-4.5-10.8-2.5 1.6-4 4-4 6.6-1-.6-1.6-1.6-1.8-2.8C6.5 9.6 5.5 11.8 5.5 14.8 5.5 18.4 8 21 12 21z" />
  </Base>
);
export const IconAlert = (p: P) => (
  <Base {...p}>
    <path d="M12 3.5L2.5 20h19z" />
    <path d="M12 10v4.5M12 17.5h.01" />
  </Base>
);
export const IconMore = (p: P) => (
  <Base {...p}>
    <path d="M5 12h.01M12 12h.01M19 12h.01" strokeWidth={3} />
  </Base>
);
export const IconSearch = (p: P) => (
  <Base {...p}>
    <circle cx="11" cy="11" r="6.5" />
    <path d="M20 20l-4.2-4.2" />
  </Base>
);
