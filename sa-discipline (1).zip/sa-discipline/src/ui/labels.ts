import { formatShortDate, hebrewWeekday } from '../core/dates';
import type { GoalHorizon, Importance, Measure, Recurrence, TaskKind, Urgency } from '../core/types';

export const IMPORTANCE_LABEL: Record<Importance, string> = { normal: 'רגילה', important: 'חשובה', critical: 'קריטית' };
export const URGENCY_LABEL: Record<Urgency, string> = { low: 'נמוכה', medium: 'בינונית', high: 'גבוהה' };
export const KIND_LABEL: Record<TaskKind, string> = { one_time: 'חד־פעמית', recurring: 'חוזרת', habit: 'הרגל' };
export const MEASURE_LABEL: Record<Measure, string> = { binary: 'בוצע / לא בוצע', numeric: 'יעד מספרי', duration: 'משך זמן' };
export const HORIZON_LABEL: Record<GoalHorizon, string> = { month: 'חודשית', quarter: 'רבעונית', year: 'שנתית', custom: 'מותאמת' };

export function recurrenceText(r: Recurrence | null): string {
  if (!r) return '';
  switch (r.type) {
    case 'daily':
      return 'כל יום';
    case 'weekly': {
      const days = [...(r.weekdays ?? [])].sort();
      if (days.length === 7) return 'כל יום';
      return 'ימים ' + days.map((d) => hebrewWeekday(`2026-10-${String(11 + d).padStart(2, '0')}`, true)).join(' ');
    }
    case 'interval':
      return r.interval === 1 ? 'כל יום' : `כל ${r.interval} ימים`;
    case 'monthly':
      return `ב־${r.monthDay} לכל חודש`;
  }
}

export function minutesText(min: number): string {
  if (min < 60) return `${min} ד׳`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m ? `${h}:${String(m).padStart(2, '0')} ש׳` : `${h} ש׳`;
}

export function relDay(date: string, today: string): string {
  if (date === today) return 'היום';
  const d = (Date.parse(date) - Date.parse(today)) / 86_400_000;
  if (d === 1) return 'מחר';
  if (d === -1) return 'אתמול';
  return `${hebrewWeekday(date)} ${formatShortDate(date)}`;
}

export function fmtNum(n: number | null | undefined, digits = 1): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return '—';
  return new Intl.NumberFormat('he-IL', { maximumFractionDigits: digits }).format(n);
}
