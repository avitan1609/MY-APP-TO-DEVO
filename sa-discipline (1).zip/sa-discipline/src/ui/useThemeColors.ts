import { useEffect, useState } from 'react';

const KEYS = ['accent', 'line', 'muted', 'faint', 'ink', 'surface', 'danger', 'warn', 'raised'] as const;
export type ThemeColors = Record<(typeof KEYS)[number], string>;

function read(): ThemeColors {
  const cs = getComputedStyle(document.documentElement);
  const out = {} as ThemeColors;
  for (const k of KEYS) out[k] = `rgb(${cs.getPropertyValue(`--${k}`).trim().split(/\s+/).join(',')})`;
  return out;
}

/** Resolved theme colors for SVG/chart attributes (CSS variables are not reliable there). */
export function useThemeColors(): ThemeColors {
  const [c, setC] = useState(read);
  useEffect(() => {
    const mo = new MutationObserver(() => setC(read()));
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    return () => mo.disconnect();
  }, []);
  return c;
}
