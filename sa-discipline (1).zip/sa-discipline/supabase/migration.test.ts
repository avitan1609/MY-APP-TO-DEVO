/**
 * Static checks on the SQL migration: every table must be covered by the RLS loop,
 * owner policies and the sync trigger. Runs in CI without a database.
 * Live RLS behaviour is verified by supabase/tests/rls_check.sql.
 */
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const sql = readFileSync(resolve(process.cwd(), 'supabase/migrations/0001_init.sql'), 'utf8');

describe('migration security', () => {
  const tables = [...sql.matchAll(/create table if not exists public\.(\w+)/g)].map((m) => m[1]);
  const loop = /foreach t in array array\[([^\]]+)\]/.exec(sql)?.[1] ?? '';

  it('defines the expected tables', () => {
    expect(tables.sort()).toEqual(['categories', 'days', 'goals', 'settings', 'task_logs', 'tasks']);
  });

  it('every table is in the RLS/policy loop', () => {
    for (const t of tables) expect(loop).toContain(`'${t}'`);
  });

  it('RLS is enabled and forced, with owner-only policies for all four operations', () => {
    expect(sql).toContain('enable row level security');
    expect(sql).toContain('force row level security');
    for (const op of ['select', 'insert', 'update', 'delete']) expect(sql).toContain(`for ${op} to authenticated`);
    expect(sql).toContain("revoke all on public.%I from anon");
  });

  it('every table is owned by an auth user with cascade delete', () => {
    const n = sql.match(/references auth\.users \(id\) on delete cascade/g)?.length ?? 0;
    expect(n).toBe(tables.length);
  });

  it('account deletion only deletes the caller', () => {
    expect(sql).toContain('delete from auth.users where id = uid');
    expect(sql).toContain('revoke all on function public.delete_my_account() from public, anon');
  });
});
