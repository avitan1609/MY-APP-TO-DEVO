-- SA Discipline — initial schema
-- Every table: composite PK (user_id, id), RLS enforced, soft-delete tombstones,
-- client `updated_at` for last-write-wins and server `server_updated_at` for pull cursors.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- Shared trigger: server timestamp + last-write-wins guard + immutable owner
-- ---------------------------------------------------------------------------
create or replace function public.sync_guard()
returns trigger
language plpgsql
security invoker
set search_path = public
as $$
begin
  if tg_op = 'UPDATE' then
    -- Ownership can never change.
    if new.user_id <> old.user_id then
      raise exception 'user_id is immutable';
    end if;
    -- Last write wins: ignore stale writes from an older client copy.
    if new.updated_at < old.updated_at then
      return null;
    end if;
  end if;
  new.server_updated_at := clock_timestamp();
  return new;
end;
$$;

-- ---------------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------------
create table if not exists public.categories (
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id text not null check (char_length(id) between 1 and 80),
  name text not null check (char_length(name) between 1 and 60),
  color text not null default '#64748B' check (color ~ '^#[0-9A-Fa-f]{6}$'),
  sort_order integer not null default 0,
  is_default boolean not null default false,
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted boolean not null default false,
  server_updated_at timestamptz not null default clock_timestamp(),
  primary key (user_id, id)
);

create table if not exists public.goals (
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id text not null check (char_length(id) between 1 and 80),
  title text not null check (char_length(title) between 1 and 120),
  description text not null default '' check (char_length(description) <= 2000),
  category_id text,
  horizon text not null check (horizon in ('month', 'quarter', 'year', 'custom')),
  start_date date not null,
  end_date date not null,
  progress_mode text not null check (progress_mode in ('manual', 'linked_sum', 'linked_completion')),
  target numeric check (target is null or target > 0),
  unit text check (unit is null or char_length(unit) <= 30),
  current_value numeric not null default 0 check (current_value >= 0),
  status text not null default 'active' check (status in ('active', 'done', 'archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted boolean not null default false,
  server_updated_at timestamptz not null default clock_timestamp(),
  primary key (user_id, id),
  check (end_date >= start_date)
);

create table if not exists public.tasks (
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id text not null check (char_length(id) between 1 and 80),
  title text not null check (char_length(title) between 1 and 120),
  description text not null default '' check (char_length(description) <= 2000),
  category_id text,
  goal_id text,
  kind text not null check (kind in ('one_time', 'recurring', 'habit')),
  measure text not null check (measure in ('binary', 'numeric', 'duration')),
  importance text not null check (importance in ('normal', 'important', 'critical')),
  urgency text not null check (urgency in ('low', 'medium', 'high')),
  weight_override numeric check (weight_override is null or (weight_override > 0 and weight_override <= 10)),
  date date,
  deadline date,
  recurrence jsonb,
  est_minutes integer check (est_minutes is null or est_minutes between 0 and 1440),
  target numeric check (target is null or target > 0),
  unit text check (unit is null or char_length(unit) <= 30),
  activity text not null default 'none' check (activity in ('none', 'run')),
  subtasks jsonb not null default '[]'::jsonb check (jsonb_typeof(subtasks) = 'array'),
  notes text not null default '' check (char_length(notes) <= 5000),
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted boolean not null default false,
  server_updated_at timestamptz not null default clock_timestamp(),
  primary key (user_id, id)
);

create table if not exists public.task_logs (
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id text not null check (char_length(id) between 1 and 120),
  task_id text not null,
  date date not null,
  status text not null check (status in ('pending', 'done', 'partial', 'not_relevant', 'moved')),
  value numeric check (value is null or value >= 0),
  distance_km numeric check (distance_km is null or distance_km >= 0),
  duration_min numeric check (duration_min is null or duration_min >= 0),
  subtask_done jsonb not null default '[]'::jsonb check (jsonb_typeof(subtask_done) = 'array'),
  moved_to date,
  counted boolean not null default false,
  extra boolean not null default false,
  note text not null default '' check (char_length(note) <= 2000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted boolean not null default false,
  server_updated_at timestamptz not null default clock_timestamp(),
  primary key (user_id, id)
);

create table if not exists public.days (
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id text not null check (char_length(id) between 1 and 40),
  date date not null,
  journal text not null default '' check (char_length(journal) <= 10000),
  blockers text not null default '' check (char_length(blockers) <= 2000),
  score_snapshot jsonb,
  summary_generated_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted boolean not null default false,
  server_updated_at timestamptz not null default clock_timestamp(),
  primary key (user_id, id)
);

create table if not exists public.settings (
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  id text not null default 'settings' check (id = 'settings'),
  weights jsonb not null,
  summary_time text not null check (summary_time ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'),
  timezone text not null,
  week_start smallint not null default 0 check (week_start between 0 and 6),
  daily_capacity_min integer not null default 360 check (daily_capacity_min between 0 and 1440),
  streak_threshold numeric not null default 70 check (streak_threshold between 0 and 100),
  theme text not null default 'system' check (theme in ('system', 'light', 'dark')),
  reminders_enabled boolean not null default false,
  onboarded boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted boolean not null default false,
  server_updated_at timestamptz not null default clock_timestamp(),
  primary key (user_id, id)
);

-- Pull-cursor indexes
create index if not exists categories_sync_idx on public.categories (user_id, server_updated_at);
create index if not exists goals_sync_idx on public.goals (user_id, server_updated_at);
create index if not exists tasks_sync_idx on public.tasks (user_id, server_updated_at);
create index if not exists task_logs_sync_idx on public.task_logs (user_id, server_updated_at);
create index if not exists task_logs_date_idx on public.task_logs (user_id, date);
create index if not exists days_sync_idx on public.days (user_id, server_updated_at);
create index if not exists settings_sync_idx on public.settings (user_id, server_updated_at);

-- ---------------------------------------------------------------------------
-- Triggers + Row Level Security (owner-only, all operations)
-- ---------------------------------------------------------------------------
do $$
declare
  t text;
begin
  foreach t in array array['categories', 'goals', 'tasks', 'task_logs', 'days', 'settings'] loop
    execute format('drop trigger if exists %I_sync_guard on public.%I', t, t);
    execute format('create trigger %I_sync_guard before insert or update on public.%I for each row execute function public.sync_guard()', t, t);

    execute format('alter table public.%I enable row level security', t);
    execute format('alter table public.%I force row level security', t);

    execute format('drop policy if exists %I_select_own on public.%I', t, t);
    execute format('drop policy if exists %I_insert_own on public.%I', t, t);
    execute format('drop policy if exists %I_update_own on public.%I', t, t);
    execute format('drop policy if exists %I_delete_own on public.%I', t, t);

    execute format('create policy %I_select_own on public.%I for select to authenticated using ((select auth.uid()) = user_id)', t, t);
    execute format('create policy %I_insert_own on public.%I for insert to authenticated with check ((select auth.uid()) = user_id)', t, t);
    execute format('create policy %I_update_own on public.%I for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id)', t, t);
    execute format('create policy %I_delete_own on public.%I for delete to authenticated using ((select auth.uid()) = user_id)', t, t);

    -- Anonymous role gets nothing.
    execute format('revoke all on public.%I from anon', t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
  end loop;
end;
$$;

-- ---------------------------------------------------------------------------
-- Account deletion — the caller can only delete themselves. Cascades to all rows.
-- ---------------------------------------------------------------------------
create or replace function public.delete_my_account()
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  uid uuid := auth.uid();
begin
  if uid is null then
    raise exception 'not authenticated';
  end if;
  delete from auth.users where id = uid;
end;
$$;

revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;
