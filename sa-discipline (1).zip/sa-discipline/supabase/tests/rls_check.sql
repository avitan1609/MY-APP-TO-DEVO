-- RLS verification script. Run in the Supabase SQL editor (as postgres) AFTER the migration.
-- It creates two throwaway users, proves isolation, then rolls everything back.
-- Expected output: a single row "RLS OK". Any failure raises an exception.

begin;

insert into auth.users (id, email, aud, role, instance_id)
values
  ('00000000-0000-0000-0000-00000000000a', 'rls-a@test.local', 'authenticated', 'authenticated', '00000000-0000-0000-0000-000000000000'),
  ('00000000-0000-0000-0000-00000000000b', 'rls-b@test.local', 'authenticated', 'authenticated', '00000000-0000-0000-0000-000000000000');

-- Act as user A
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-00000000000a","role":"authenticated"}', true);

insert into public.tasks (user_id, id, title, kind, measure, importance, urgency)
values ('00000000-0000-0000-0000-00000000000a', 't-a', 'A task', 'one_time', 'binary', 'normal', 'medium');

-- A cannot write rows owned by B
do $$
begin
  begin
    insert into public.tasks (user_id, id, title, kind, measure, importance, urgency)
    values ('00000000-0000-0000-0000-00000000000b', 't-x', 'forged', 'one_time', 'binary', 'normal', 'medium');
    raise exception 'FAIL: inserted a row for another user';
  exception when insufficient_privilege or check_violation then
    null; -- expected (RLS violation)
  end;
end $$;

-- Act as user B
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-00000000000b","role":"authenticated"}', true);

do $$
declare n int;
begin
  select count(*) into n from public.tasks;
  if n <> 0 then raise exception 'FAIL: user B can see % rows of user A', n; end if;

  update public.tasks set title = 'hacked' where id = 't-a';
  get diagnostics n = row_count;
  if n <> 0 then raise exception 'FAIL: user B updated user A row'; end if;

  delete from public.tasks where id = 't-a';
  get diagnostics n = row_count;
  if n <> 0 then raise exception 'FAIL: user B deleted user A row'; end if;
end $$;

-- Anonymous sees nothing
set local role anon;
do $$
begin
  begin
    perform 1 from public.tasks limit 1;
    raise exception 'FAIL: anon can read tasks';
  exception when insufficient_privilege then null;
  end;
end $$;

-- Back to A: row intact, stale write ignored (last-write-wins guard)
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-00000000000a","role":"authenticated"}', true);
do $$
declare t text;
begin
  select title into t from public.tasks where id = 't-a';
  if t <> 'A task' then raise exception 'FAIL: row was modified (%).', t; end if;
  update public.tasks set title = 'stale', updated_at = now() - interval '1 day' where id = 't-a';
  select title into t from public.tasks where id = 't-a';
  if t <> 'A task' then raise exception 'FAIL: stale write applied'; end if;
end $$;

select 'RLS OK' as result;

rollback;
