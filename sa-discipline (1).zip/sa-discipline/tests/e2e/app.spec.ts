/**
 * End-to-end: RTL, responsiveness (no horizontal scroll), both themes, offline persistence.
 * Runs against the production build in local mode (no Supabase env needed).
 */
import { expect, test, type Page } from '@playwright/test';

async function start(page: Page) {
  await page.goto('/');
  const go = page.getByRole('button', { name: 'מתחילים' });
  if (await go.isVisible({ timeout: 5000 }).catch(() => false)) await go.click();
  await expect(page.getByRole('heading', { name: 'היום' })).toBeVisible();
}

async function noHorizontalScroll(page: Page) {
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  expect(overflow).toBeLessThanOrEqual(0);
}

test('RTL document and layout', async ({ page }) => {
  await start(page);
  await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
  await expect(page.locator('html')).toHaveAttribute('lang', 'he');
  for (const path of ['/', '/week', '/tasks', '/goals', '/stats', '/summary', '/settings']) {
    await page.goto(path);
    await page.waitForLoadState('networkidle');
    await noHorizontalScroll(page);
  }
});

test('dark and light themes', async ({ page }) => {
  await start(page);
  await page.goto('/settings');
  await page.getByRole('radio', { name: 'כהה' }).click();
  await expect(page.locator('html')).toHaveClass(/dark/);
  await page.getByRole('radio', { name: 'בהיר' }).click();
  await expect(page.locator('html')).not.toHaveClass(/dark/);
});

test('works offline and persists across reloads', async ({ page, context }) => {
  await start(page);
  // Wait until the service worker controls the page, so the app shell is cached.
  await page.evaluate(() => navigator.serviceWorker.ready.then(() => true));
  await page.reload();
  await expect(page.getByRole('heading', { name: 'היום' })).toBeVisible();
  await context.setOffline(true);
  await page.getByRole('button', { name: /הוסף משימה/ }).first().click();
  await page.getByLabel('שם המשימה').fill('משימה אופליין');
  await page.getByRole('button', { name: 'הוסף', exact: true }).click();
  await expect(page.getByText('משימה אופליין')).toBeVisible();
  await page.reload();
  await expect(page.getByText('משימה אופליין')).toBeVisible();
  await context.setOffline(false);
});
