/** Shared UI state, clock and action registries (avoids circular imports between views). */
import { minutesNowIn, todayIn } from '../../src/core/dates';
import type { ISODate } from '../../src/core/types';
import type { Errors } from '../../src/core/validation';
import { S } from './store';

export type Route =
  | { name: 'day'; date: ISODate | null }
  | { name: 'week' }
  | { name: 'tasks' }
  | { name: 'goals' }
  | { name: 'stats' }
  | { name: 'summary'; date: ISODate | null }
  | { name: 'settings' };

export const A = {
  today: '' as ISODate,
  minutesNow: 0,
  route: { name: 'day', date: null } as Route,
  weekOff: 0,
  taskTab: 'active' as 'active' | 'habits' | 'backlog' | 'done' | 'archived',
  taskQuery: '',
  taskCat: '',
  goalStatus: 'active' as 'active' | 'done' | 'archived',
  statRange: '30' as '7' | '30' | '90',
  /** Unsaved summary text, so periodic re-renders never wipe what is being typed. */
  sum: { date: '' as ISODate, journal: null as string | null, blockers: null as string | null, picked: {} as Record<string, string> },
  settingsErrors: {} as Errors,
};

export function tick(): boolean {
  const tz = S.settings.timezone;
  const today = todayIn(tz);
  const m = minutesNowIn(tz);
  const changedDay = today !== A.today;
  A.today = today;
  A.minutesNow = m;
  return changedDay;
}

type Handler = (el: HTMLElement, e: Event) => void;
export const actions: Record<string, Handler> = {};
export const segs: Record<string, (value: string, el: HTMLElement) => void> = {};
export const binds: Record<string, (value: string, el: HTMLInputElement) => void> = {};
export const submits: Record<string, (form: HTMLFormElement) => void> = {};

let refreshFn: () => void = () => {};
export const setRefresh = (f: () => void) => (refreshFn = f);
/** Re-render the current screen (and the open sheet if it registered a refresher). */
export const refresh = () => refreshFn();

let sheetRefresher: (() => void) | null = null;
export const setSheetRefresher = (f: (() => void) | null) => (sheetRefresher = f);
export const refreshSheet = () => {
  if (document.getElementById('sheet-body')) sheetRefresher?.();
  else sheetRefresher = null;
};

export function routeHash(r: Route): string {
  switch (r.name) {
    case 'day':
      return r.date ? `#/day/${r.date}` : '#/';
    case 'summary':
      return r.date ? `#/summary/${r.date}` : '#/summary';
    default:
      return `#/${r.name}`;
  }
}
export function go(r: Route) {
  const h = routeHash(r);
  if (location.hash === h) refresh();
  else location.hash = h;
}
