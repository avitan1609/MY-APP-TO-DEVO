/** Entry point: boot, routing, event delegation, theme, reminders, offline. */
import { parseBackup } from '../../src/core/backup';
import { isISODate, parseHHMM } from '../../src/core/dates';
import { newCategory } from '../../src/core/factories';
import { isAfterTheFact } from '../../src/core/planning';
import { isScheduledOn } from '../../src/core/recurrence';
import type { Settings, ThemePref } from '../../src/core/types';
import { validateSettings } from '../../src/core/validation';
import { A, actions, binds, refreshSheet, segs, setRefresh, submits, tick, type Route } from './app';
import { openDetail, openEditor, openGoal, openOnboarding, openOverload, openQuick, saveDetailNote } from './sheets';
import {
  S,
  applyMove,
  bindStore,
  dayEntry,
  exportAll,
  finalizePastDays,
  importAll,
  initStore,
  liveCategories,
  logsArr,
  saveCategory,
  saveDay,
  saveSettings,
  saveTask,
  setLog,
  setMeta,
  snapshotDay,
  taskById,
  toggleDone,
  wipeAll,
} from './store';
import { $, closeSheet, confirmSheet, download, keepFocus, sheetIsOpen, sheetKeys, takeConfirm, toast } from './ui';
import { viewDay, viewGoals, viewSettings, viewStats, viewSummary, viewTasks, viewWeek } from './views';

// ---------------------------------------------------------------------------
// Routing (hash based: works on any static host with no server config)
// ---------------------------------------------------------------------------
function parseRoute(): Route {
  const h = location.hash.replace(/^#\/?/, '');
  const [a, b] = h.split('/');
  const date = b && isISODate(b) ? b : null;
  switch (a) {
    case 'day':
      return { name: 'day', date };
    case 'summary':
      return { name: 'summary', date };
    case 'week':
    case 'tasks':
    case 'goals':
    case 'stats':
    case 'settings':
      return { name: a };
    default:
      return { name: 'day', date: null };
  }
}

function renderNav() {
  const cur = A.route.name;
  for (const a of document.querySelectorAll<HTMLAnchorElement>('[data-nav]')) {
    if (a.dataset.nav === cur) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  }
}

let renderQueued = false;
function render() {
  renderQueued = false;
  const view = $('#view')!;
  const r = A.route;
  let html = '';
  let title = 'SA · משמעת';
  switch (r.name) {
    case 'day':
      html = viewDay(r.date ?? A.today);
      break;
    case 'week':
      html = viewWeek();
      title = 'שבוע · SA';
      break;
    case 'tasks':
      html = viewTasks();
      title = 'משימות · SA';
      break;
    case 'goals':
      html = viewGoals();
      title = 'מטרות · SA';
      break;
    case 'stats':
      html = viewStats();
      title = 'נתונים · SA';
      break;
    case 'summary':
      html = viewSummary(r.date ?? A.today);
      title = 'סיכום יום · SA';
      break;
    case 'settings':
      html = viewSettings();
      title = 'הגדרות · SA';
      break;
  }
  keepFocus(() => (view.innerHTML = html));
  document.title = title;
  document.body.dataset.route = r.name;
  renderNav();
}
function scheduleRender() {
  if (renderQueued) return;
  renderQueued = true;
  queueMicrotask(() => {
    render();
    refreshSheet();
  });
}
setRefresh(scheduleRender);

window.addEventListener('hashchange', () => {
  A.route = parseRoute();
  if (sheetIsOpen()) closeSheet();
  render();
  window.scrollTo(0, 0);
  $('#view')?.focus({ preventScroll: true });
});

// ---------------------------------------------------------------------------
// Theme
// ---------------------------------------------------------------------------
const mq = matchMedia('(prefers-color-scheme: dark)');
function applyTheme(pref: ThemePref) {
  const dark = pref === 'dark' || (pref === 'system' && mq.matches);
  document.documentElement.classList.toggle('dark', dark);
  $('meta[name="theme-color"]')?.setAttribute('content', dark ? '#0C0E11' : '#F5F6F7');
  try {
    localStorage.setItem('sa-theme', pref);
  } catch {
    /* ignore */
  }
}
mq.addEventListener('change', () => applyTheme(S.settings.theme));

// ---------------------------------------------------------------------------
// Event delegation
// ---------------------------------------------------------------------------
document.addEventListener('click', (e) => {
  const target = e.target as HTMLElement;
  const scrim = target.closest('[data-scrim]');
  if (scrim && target === scrim) return closeSheet();
  const el = target.closest<HTMLElement>('[data-a]');
  if (!el || (el as HTMLButtonElement).disabled) return;
  const name = el.dataset.a!;
  if (name === 'seg') return segs[el.dataset.seg!]?.(el.dataset.v!, el);
  actions[name]?.(el, e);
});

function onBind(e: Event) {
  const el = e.target as HTMLInputElement;
  const key = el.dataset?.bind;
  if (key && binds[key]) binds[key](el.value, el);
}
document.addEventListener('input', onBind);
document.addEventListener('change', (e) => {
  const el = e.target as HTMLInputElement;
  // Selects and date pickers only fire "change" in some browsers.
  if (el.tagName === 'SELECT' || el.type === 'date' || el.type === 'time') onBind(e);
  if (el.dataset?.change === 'd-note') saveDetailNote(el.value);
  if (el.dataset?.bind === 'catName') {
    const c = S.categories.find((x) => x.id === el.dataset.cat);
    const v = el.value.trim();
    if (c && v && v !== c.name) saveCategory({ ...c, name: v.slice(0, 60) });
    else if (c && !v) el.value = c.name;
  }
});
document.addEventListener('submit', (e) => {
  const f = e.target as HTMLFormElement;
  const key = f.dataset.submit;
  if (!key) return;
  e.preventDefault();
  submits[key]?.(f);
});
document.addEventListener('keydown', (e) => {
  if (sheetKeys(e)) return;
  const t = e.target as HTMLElement;
  if (e.key === 'Enter' && t.dataset?.enter) {
    e.preventDefault();
    actions[t.dataset.enter]?.(t, e);
    return;
  }
  const typing = /INPUT|TEXTAREA|SELECT/.test(t.tagName) || t.isContentEditable;
  if (!typing && !sheetIsOpen() && !e.metaKey && !e.ctrlKey && !e.altKey && e.key === 'n') {
    e.preventDefault();
    openQuick(A.route.name === 'day' ? (A.route.date ?? A.today) : null);
  }
});

// ---------------------------------------------------------------------------
// Actions: navigation-level
// ---------------------------------------------------------------------------
actions['sheet-close'] = () => closeSheet();
actions['confirm-ok'] = async () => {
  const f = takeConfirm();
  await f?.();
};
actions['quick'] = (el) => openQuick(el.dataset.date ?? (A.route.name === 'day' ? (A.route.date ?? A.today) : null));
actions['new-task'] = (el) => {
  const p = el.dataset.preset;
  if (p === 'habits') openEditor('new', { kind: 'habit', date: null, recurrence: { type: 'daily', startDate: A.today } });
  else if (p === 'backlog') openEditor('new', { date: null });
  else openEditor('new');
};
actions['edit-task'] = (el) => openEditor(el.dataset.task!);
actions['open-item'] = (el) => openDetail(el.dataset.task!, el.dataset.date!);
actions['toggle'] = (el) => {
  const t = taskById(el.dataset.task!);
  if (t) toggleDone(t, el.dataset.date!, A.today);
};
actions['overload'] = (el) => openOverload(el.dataset.date!);
actions['week'] = (el) => {
  const d = Number(el.dataset.d);
  A.weekOff = d === 0 ? 0 : A.weekOff + d;
  render();
};
actions['schedule-today'] = (el) => {
  const t = taskById(el.dataset.task!);
  if (!t) return;
  saveTask({ ...t, date: A.today });
  toast('שובץ להיום');
};
actions['archive'] = (el) => {
  const t = taskById(el.dataset.task!);
  if (!t) return;
  const on = el.dataset.v === '1';
  saveTask({ ...t, archived: on });
  toast(on ? 'הועבר לארכיון' : 'הוחזר מהארכיון');
};
actions['new-goal'] = () => openGoal('new');
actions['edit-goal'] = (el) => openGoal(el.dataset.goal!);

segs['taskTab'] = (v) => {
  A.taskTab = v as typeof A.taskTab;
  render();
};
segs['goalStatus'] = (v) => {
  A.goalStatus = v as typeof A.goalStatus;
  render();
};
segs['statRange'] = (v) => {
  A.statRange = v as typeof A.statRange;
  render();
};
binds['taskQuery'] = (v) => {
  A.taskQuery = v;
  render();
};
binds['taskCat'] = (v) => {
  A.taskCat = v;
  render();
};

// Quick numeric add on a task row: "+" field adds to the day's value
submits['qty'] = (f) => {
  const t = taskById(f.dataset.task!);
  const inp = f.querySelector('input')!;
  const n = Number(inp.value);
  if (!t || !inp.value.trim() || !Number.isFinite(n)) return;
  const date = f.dataset.date!;
  const cur = logsArr().find((l) => l.taskId === t.id && l.date === date)?.value ?? 0;
  setLog(t, date, { value: Math.max(0, cur + n) }, A.today);
};

// ---------------------------------------------------------------------------
// Summary
// ---------------------------------------------------------------------------
binds['sumJournal'] = (v) => (A.sum.journal = v);
binds['sumBlockers'] = (v) => (A.sum.blockers = v);
binds['sumDate'] = (v, el) => (A.sum.picked[el.dataset.task!] = v);
actions['sum-pick'] = (el) => {
  const id = el.dataset.task!;
  A.sum.picked[id] = A.sum.picked[id] ? '' : el.dataset.sug!;
  render();
};
actions['sum-move'] = (el) => {
  const date = el.dataset.date!;
  const after = isAfterTheFact(date, A.today, A.minutesNow, S.settings.summaryTime);
  let n = 0;
  for (const [id, to] of Object.entries(A.sum.picked)) {
    const t = taskById(id);
    if (!t || !to || !isISODate(to) || to <= date) continue;
    if (t.kind !== 'one_time' && isScheduledOn(t, to)) continue;
    applyMove(t, date, to, after, A.today);
    n++;
  }
  A.sum.picked = {};
  toast(n ? `הועברו ${n} משימות` : 'לא נבחרו תאריכים תקינים', n ? 'ok' : 'error');
  render();
};
actions['close-day'] = (el) => {
  const date = el.dataset.date!;
  const d = dayEntry(date);
  saveDay({ ...d, journal: A.sum.journal ?? d.journal, blockers: A.sum.blockers ?? d.blockers });
  snapshotDay(date, true);
  A.sum.journal = null;
  A.sum.blockers = null;
  toast('היום נסגר. הציון נשמר עם פירוט מלא.');
  scheduleRender();
};

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
segs['theme'] = (v) => {
  saveSettings({ ...S.settings, theme: v as ThemePref });
  applyTheme(v as ThemePref);
};
submits['settings'] = (f) => {
  const fd = new FormData(f);
  const num = (k: string) => {
    const raw = String(fd.get(k) ?? '').trim();
    return raw === '' ? NaN : Number(raw);
  };
  const next: Settings = {
    ...S.settings,
    summaryTime: String(fd.get('summaryTime') ?? ''),
    dailyCapacityMin: Math.round(num('capacity') * 60),
    streakThreshold: num('threshold'),
    timezone: String(fd.get('timezone') ?? S.settings.timezone),
    weights: { normal: num('w-normal'), important: num('w-important'), critical: num('w-critical') },
  };
  A.settingsErrors = validateSettings(next);
  if (Object.keys(A.settingsErrors).length) {
    render();
    toast('יש ערכים לא תקינים', 'error');
    return;
  }
  saveSettings(next);
  tick();
  toast('ההגדרות נשמרו');
};
actions['reminders'] = async () => {
  const on = !S.settings.remindersEnabled;
  if (on) {
    if (!('Notification' in window)) return toast('הדפדפן לא תומך בהתראות', 'error');
    let p = Notification.permission;
    if (p === 'default') p = await Notification.requestPermission();
    if (p !== 'granted') return toast('לא ניתנה הרשאה להתראות. אפשר לשנות בהגדרות הדפדפן.', 'error');
  }
  saveSettings({ ...S.settings, remindersEnabled: on });
};
binds['catColor'] = (v, el) => {
  const c = S.categories.find((x) => x.id === el.dataset.cat);
  if (c && /^#[0-9A-Fa-f]{6}$/.test(v)) saveCategory({ ...c, color: v });
};
binds['catName'] = () => {
  /* saved on change (blur) */
};
actions['cat-archive'] = (el) => {
  const c = S.categories.find((x) => x.id === el.dataset.cat);
  if (c) saveCategory({ ...c, archived: !c.archived });
};
submits['new-cat'] = (f) => {
  const name = String(new FormData(f).get('name') ?? '').trim();
  if (!name) return;
  const colors = ['#2DB5A3', '#3B82F6', '#8B5CF6', '#F59E0B', '#EC4899', '#22C55E', '#EF4444'];
  saveCategory(newCategory(S.settings.userId, name.slice(0, 60), colors[liveCategories(true).length % colors.length], liveCategories(true).length + 1));
  toast('הקטגוריה נוספה');
};
actions['export-json'] = () => {
  download(`sa-backup-${A.today}.json`, JSON.stringify(exportAll(), null, 2), 'application/json');
  setMeta('lastBackup', A.today);
  toast('קובץ הגיבוי ירד למכשיר');
};
actions['export-csv'] = () => {
  const b = exportAll();
  const title = new Map(b.tasks.map((t) => [t.id, t.title]));
  const q = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const rows = ['date,task,status,value,distance_km,duration_min,note'];
  for (const l of [...b.logs].sort((x, y) => x.date.localeCompare(y.date)))
    rows.push([l.date, title.get(l.taskId) ?? '', l.status, l.value, l.distanceKm, l.durationMin, l.note].map(q).join(','));
  download(`sa-logs-${A.today}.csv`, '﻿' + rows.join('\n'), 'text/csv;charset=utf-8');
};
actions['import'] = () => $<HTMLInputElement>('#import-file')?.click();
document.addEventListener('change', async (e) => {
  const el = e.target as HTMLInputElement;
  if (el.id !== 'import-file' || !el.files?.[0]) return;
  const file = el.files[0];
  el.value = '';
  if (file.size > 20 * 1024 * 1024) return toast('הקובץ גדול מדי', 'error');
  try {
    const b = parseBackup(await file.text());
    confirmSheet({
      title: 'שחזור מגיבוי',
      body: `הגיבוי מ־${new Date(b.exportedAt).toLocaleDateString('he-IL')} כולל ${b.tasks.length} משימות, ${b.logs.length} רישומי ביצוע ו־${b.goals.length} מטרות. הנתונים ימוזגו לנתונים הקיימים, ורשומות עם אותו מזהה יוחלפו.`,
      confirm: 'שחזר',
      onConfirm: async () => {
        await importAll(b);
        applyTheme(S.settings.theme);
        closeSheet();
        toast('השחזור הושלם');
      },
    });
  } catch (err) {
    toast((err as Error).message, 'error');
  }
});
actions['wipe'] = () =>
  confirmSheet({
    title: 'מחיקה לצמיתות',
    body: 'כל המשימות, ההרגלים, המטרות וההיסטוריה במכשיר הזה יימחקו. אי אפשר לבטל את הפעולה. כדי לאשר, הקלד "מחק".',
    extraInput: '<input class="field mt" id="wipe-confirm" aria-label=\'הקלד "מחק" לאישור\' autocomplete="off">',
    confirm: 'מחק לצמיתות',
    danger: true,
    onConfirm: async () => {
      if ($<HTMLInputElement>('#wipe-confirm')?.value.trim() !== 'מחק') {
        toast('יש להקליד "מחק"', 'error');
        // keep the dialog usable
        actions['wipe']($('#view')!, new Event('click'));
        return;
      }
      await wipeAll();
      location.replace(location.pathname);
    },
  });

// ---------------------------------------------------------------------------
// Clock, day rollover, reminders
// ---------------------------------------------------------------------------
async function notify(title: string, body: string) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  try {
    const reg = await navigator.serviceWorker?.getRegistration();
    if (reg) await reg.showNotification(title, { body, icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', tag: 'daily-summary', lang: 'he', dir: 'rtl' });
    else new Notification(title, { body, icon: 'icons/icon-192.png', lang: 'he', dir: 'rtl' });
  } catch {
    /* ignore */
  }
}

let lastSummaryState = false;
function everyMinute() {
  const newDay = tick();
  if (newDay) finalizePastDays(A.today);
  const at = parseHHMM(S.settings.summaryTime) ?? 1290;
  const past = A.minutesNow >= at;
  if (newDay || past !== lastSummaryState) scheduleRender();
  lastSummaryState = past;
  if (past && S.settings.remindersEnabled && !dayEntry(A.today).summaryGeneratedAt && S.meta.get('notified') !== A.today) {
    setMeta('notified', A.today);
    void notify('הגיע זמן הסיכום היומי', 'שתי דקות: סגור את היום ותכנן את מחר.');
  }
}

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------
async function boot() {
  const started = performance.now();
  let tz = 'Asia/Jerusalem';
  try {
    tz = Intl.DateTimeFormat().resolvedOptions().timeZone || tz;
  } catch {
    /* ignore */
  }
  await initStore(tz);
  bindStore(scheduleRender, (msg) => toast(msg, 'error'));
  applyTheme(S.settings.theme);
  tick();
  lastSummaryState = A.minutesNow >= (parseHHMM(S.settings.summaryTime) ?? 1290);
  finalizePastDays(A.today);
  A.route = parseRoute();
  render();

  // Splash: keep the logo up briefly so it doesn't flicker
  const wait = Math.max(0, 600 - (performance.now() - started));
  setTimeout(() => {
    document.body.classList.add('ready');
    setTimeout(() => $('#splash')?.remove(), 400);
    if (!S.persistent) toast('הדפדפן חוסם שמירה מקומית. הנתונים יישמרו רק עד סגירת הלשונית.', 'error');
    if (!S.settings.onboarded) openOnboarding();
  }, wait);

  setInterval(everyMinute, 30_000);
  document.addEventListener('visibilitychange', () => document.visibilityState === 'visible' && everyMinute());

  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    navigator.serviceWorker.register('sw.js').catch(() => undefined);
  }
}

window.addEventListener('error', () => {
  // Never leave the user staring at the splash.
  document.body.classList.add('ready');
});
void boot().catch((err) => {
  console.error(err);
  document.body.classList.add('ready');
  const v = $('#view');
  if (v) v.innerHTML = '<div class="card empty"><p class="e-t">משהו השתבש בטעינה</p><p class="e-b">נסה לרענן את הדף. אם זה חוזר, ייצא גיבוי מההגדרות ושלח את הודעת השגיאה.</p></div>';
});

