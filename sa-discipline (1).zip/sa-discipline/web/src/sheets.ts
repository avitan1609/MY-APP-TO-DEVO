/** Bottom sheets: quick add, task editor, task detail, goal editor, overload, onboarding. */
import { addDays, startOfMonth, weekday } from '../../src/core/dates';
import { formatPace, newGoal, newTask, paceMinPerKm, uid } from '../../src/core/factories';
import { isAfterTheFact, loadForFactory, overloadAlternatives, suggestDate } from '../../src/core/planning';
import { isScheduledOn, plannedItemsForDate } from '../../src/core/recurrence';
import { completionRatio, isComplete, taskWeight } from '../../src/core/score';
import type { Goal, GoalHorizon, GoalProgressMode, GoalStatus, Importance, ISODate, Measure, Recurrence, RecurrenceType, Task, TaskKind, Urgency } from '../../src/core/types';
import { validateGoal, validateSettings, validateTask, type Errors } from '../../src/core/validation';
import { HORIZON_LABEL, IMPORTANCE_LABEL, KIND_LABEL, MEASURE_LABEL, URGENCY_LABEL, fmtNum, minutesText, recurrenceText, relDay } from '../../src/ui/labels';
import { A, actions, binds, segs, setSheetRefresher, submits } from './app';
import {
  S,
  applyMove,
  deleteGoal,
  deleteTask,
  getLog,
  liveCategories,
  liveGoals,
  liveTasks,
  logsArr,
  saveGoal,
  saveSettings,
  saveTask,
  setLog,
  taskById,
  toggleDone,
  toggleSubtask,
} from './store';
import { I, closeSheet, confirmSheet, esc, field, numVal, openSheet, seg, toast, updateSheet, $ } from './ui';

const opt = (v: string, label: string, cur: string | null | undefined) => `<option value="${esc(v)}" ${v === (cur ?? '') ? 'selected' : ''}>${esc(label)}</option>`;
const catOptions = (cur: string | null, none = 'ללא') => opt('', none, cur) + liveCategories().map((c) => opt(c.id, c.name, cur)).join('');

// ===========================================================================
// Quick add
// ===========================================================================
const Q = { title: '', when: 'today' as 'today' | 'tomorrow' | 'backlog', imp: 'normal' as Importance, cat: '', est: '', forDay: null as ISODate | null, error: '' };

function quickBody() {
  const custom = Q.forDay && Q.forDay !== A.today && Q.forDay !== addDays(A.today, 1);
  return `<form class="stack" data-submit="quick" novalidate>
    <div class="fld"><input class="field" id="q-title" placeholder="מה צריך לעשות?" aria-label="שם המשימה" maxlength="120" value="${esc(Q.title)}" data-bind="q.title" data-autofocus autocomplete="off">${Q.error ? `<p class="err" role="alert">${esc(Q.error)}</p>` : ''}</div>
    ${seg('q.when', Q.when, [
      ['today', custom ? `ב${relDay(Q.forDay!, A.today)}` : 'היום'],
      ['tomorrow', 'מחר'],
      ['backlog', 'ללא תאריך'],
    ])}
    ${seg('q.imp', Q.imp, [
      ['normal', 'רגילה'],
      ['important', 'חשובה'],
      ['critical', 'קריטית'],
    ])}
    <div class="grid2"><select class="field" id="q-cat" data-bind="q.cat" aria-label="קטגוריה">${catOptions(Q.cat, 'ללא קטגוריה')}</select>
    <input class="field num" id="q-est" type="number" inputmode="numeric" min="0" max="1440" placeholder="דקות משוערות" aria-label="זמן משוער בדקות" value="${esc(Q.est)}" data-bind="q.est"></div>
    <button type="submit" hidden></button></form>`;
}
const quickFoot = `<button type="button" class="btn primary" data-a="q-add">הוסף</button><button type="button" class="btn" data-a="q-add-more">הוסף ועוד</button><button type="button" class="btn ghost ms-auto" data-a="q-more">פרטים נוספים</button>`;

export function openQuick(day?: ISODate | null) {
  Object.assign(Q, { title: '', when: 'today', imp: 'normal', cat: '', est: '', forDay: day ?? null, error: '' });
  if (day && day === addDays(A.today, 1)) Q.when = 'tomorrow';
  setSheetRefresher(null);
  openSheet({ title: 'הוספה מהירה', body: quickBody(), footer: quickFoot });
}

function quickTask(): Task {
  const base = Q.forDay && Q.forDay !== A.today ? Q.forDay : A.today;
  const date = Q.when === 'today' ? base : Q.when === 'tomorrow' ? addDays(A.today, 1) : null;
  const est = Q.est.trim() ? Math.round(Number(Q.est)) : null;
  return newTask(S.settings.userId, A.today, { title: Q.title.trim(), date, importance: Q.imp, categoryId: Q.cat || null, estMinutes: Number.isFinite(est) ? est : null });
}

function quickAdd(keepOpen: boolean) {
  const t = quickTask();
  const e = validateTask(t);
  if (Object.keys(e).length) {
    Q.error = e.title ?? e.estMinutes ?? 'בדוק את הפרטים';
    return updateSheet(quickBody());
  }
  saveTask(t);
  toast('נוסף');
  if (keepOpen) {
    Q.title = '';
    Q.error = '';
    updateSheet(quickBody());
    $<HTMLInputElement>('#q-title')?.focus();
  } else closeSheet();
}

segs['q.when'] = (v) => {
  Q.when = v as typeof Q.when;
  updateSheet(quickBody());
};
segs['q.imp'] = (v) => {
  Q.imp = v as Importance;
  updateSheet(quickBody());
};
binds['q.title'] = (v) => {
  Q.title = v;
  if (Q.error && v.trim()) {
    Q.error = '';
    updateSheet(quickBody());
  }
};
binds['q.cat'] = (v) => (Q.cat = v);
binds['q.est'] = (v) => (Q.est = v);
actions['q-add'] = () => quickAdd(false);
actions['q-add-more'] = () => quickAdd(true);
submits['quick'] = () => quickAdd(false);
actions['q-more'] = () => {
  const t = quickTask();
  openEditor('new', { title: t.title, date: t.date, importance: t.importance, categoryId: t.categoryId, estMinutes: t.estMinutes });
};

// ===========================================================================
// Task editor
// ===========================================================================
let draft: Task | null = null;
let draftNew = false;
let draftMore = false;
let draftErrors: Errors = {};
const DAYS = ['א׳', 'ב׳', 'ג׳', 'ד׳', 'ה׳', 'ו׳', 'ש׳'];

export function openEditor(id: string | 'new', preset?: Partial<Task>) {
  if (id === 'new') {
    draft = newTask(S.settings.userId, A.today, preset);
    draftNew = true;
  } else {
    const t = taskById(id);
    if (!t) return toast('המשימה לא נמצאה', 'error');
    draft = structuredClone(t);
    draftNew = false;
  }
  draftErrors = {};
  draftMore = !!(draft.description || draft.notes || draft.subtasks.length || draft.weightOverride || draft.goalId || (draft.kind !== 'one_time' && draft.deadline));
  setSheetRefresher(null);
  openSheet({ title: draftNew ? 'משימה חדשה' : 'עריכת משימה', body: editorBody(), footer: editorFoot(), wide: true });
}

const editorFoot = () =>
  `<button type="button" class="btn primary" data-a="ed-save">שמירה</button><button type="button" class="btn ghost" data-a="sheet-close">ביטול</button>${
    draftNew ? '' : `<button type="button" class="btn danger ms-auto" data-a="ed-delete">${I.trash()} מחיקה</button>`
  }`;

function editorBody(): string {
  const d = draft!;
  const e = draftErrors;
  const rec = d.recurrence;
  const goals = liveGoals().filter((g) => g.status === 'active' || g.id === d.goalId);
  const recBlock =
    d.kind === 'one_time'
      ? `<div class="grid2">${field({ id: 'ed-date', label: 'תאריך מתוכנן', error: e.date, hint: d.date ? undefined : 'ללא תאריך: נשמר ברשימת ההמתנה', input: `<input class="field" id="ed-date" type="date" value="${esc(d.date ?? '')}" data-bind="ed.date">` })}
         ${field({ id: 'ed-deadline', label: 'דדליין (אופציונלי)', error: e.deadline, input: `<input class="field" id="ed-deadline" type="date" value="${esc(d.deadline ?? '')}" data-bind="ed.deadline">` })}</div>`
      : `<div class="card pad stack inner">
          ${seg('ed.recType', rec?.type ?? 'daily', [
            ['daily', 'כל יום'],
            ['weekly', 'ימים בשבוע'],
            ['interval', 'כל X ימים'],
            ['monthly', 'חודשי'],
          ], 'תדירות', true)}
          ${
            rec?.type === 'weekly'
              ? `<div class="days" role="group" aria-label="ימים בשבוע">${DAYS.map((n, i) => {
                  const on = rec.weekdays?.includes(i) ?? false;
                  return `<button type="button" class="${on ? 'on' : ''}" aria-pressed="${on}" data-a="ed-wd" data-v="${i}">${n}</button>`;
                }).join('')}</div>`
              : ''
          }
          ${rec?.type === 'interval' ? field({ id: 'ed-int', label: 'כל כמה ימים', input: `<input class="field num" id="ed-int" type="number" inputmode="numeric" min="1" max="365" value="${rec.interval ?? ''}" data-bind="ed.interval">` }) : ''}
          ${rec?.type === 'monthly' ? field({ id: 'ed-md', label: 'יום בחודש', hint: '31 = היום האחרון בחודש', input: `<input class="field num" id="ed-md" type="number" inputmode="numeric" min="1" max="31" value="${rec.monthDay ?? ''}" data-bind="ed.monthDay">` }) : ''}
          <div class="grid2">${field({ id: 'ed-rs', label: 'מתאריך', input: `<input class="field" id="ed-rs" type="date" value="${esc(rec?.startDate ?? A.today)}" data-bind="ed.recStart">` })}
          ${field({ id: 'ed-re', label: 'עד תאריך (אופציונלי)', input: `<input class="field" id="ed-re" type="date" value="${esc(rec?.endDate ?? '')}" data-bind="ed.recEnd">` })}</div>
          ${e.recurrence ? `<p class="err" role="alert">${esc(e.recurrence)}</p>` : ''}
        </div>`;

  return `<div class="stack">
    ${field({ id: 'ed-title', label: 'שם המשימה', error: e.title, input: `<input class="field" id="ed-title" maxlength="120" placeholder="לדוגמה: אימון כוח — רגליים" value="${esc(d.title)}" data-bind="ed.title" data-autofocus autocomplete="off">` })}
    <div>${seg('ed.kind', d.kind, (['one_time', 'recurring', 'habit'] as const).map((k) => [k, KIND_LABEL[k]]), 'סוג')}</div>
    ${recBlock}
    <div class="grid2">
      ${field({ id: 'ed-imp', label: 'חשיבות', input: `<select class="field" id="ed-imp" data-bind="ed.importance">${(['normal', 'important', 'critical'] as const).map((k) => opt(k, IMPORTANCE_LABEL[k], d.importance)).join('')}</select>` })}
      ${field({ id: 'ed-urg', label: 'דחיפות', input: `<select class="field" id="ed-urg" data-bind="ed.urgency">${(['low', 'medium', 'high'] as const).map((k) => opt(k, URGENCY_LABEL[k], d.urgency)).join('')}</select>` })}
      ${field({ id: 'ed-cat', label: 'קטגוריה', input: `<select class="field" id="ed-cat" data-bind="ed.categoryId">${catOptions(d.categoryId)}</select>` })}
      ${field({ id: 'ed-est', label: 'זמן משוער (דקות)', error: e.estMinutes, input: `<input class="field num" id="ed-est" type="number" inputmode="numeric" min="0" max="1440" value="${d.estMinutes ?? ''}" data-bind="ed.est">` })}
    </div>
    ${field({ id: 'ed-measure', label: 'מדידה', input: `<select class="field" id="ed-measure" data-bind="ed.measure">${(['binary', 'numeric', 'duration'] as const).map((k) => opt(k, MEASURE_LABEL[k], d.measure)).join('')}</select>` })}
    ${
      d.measure !== 'binary'
        ? `<div class="grid2">${field({ id: 'ed-target', label: d.measure === 'duration' ? 'יעד (דקות)' : 'יעד', error: e.target, input: `<input class="field num" id="ed-target" type="number" inputmode="decimal" min="0" step="any" value="${d.target ?? ''}" data-bind="ed.target">` })}
          ${d.measure === 'numeric' ? field({ id: 'ed-unit', label: 'יחידה', error: e.unit, input: `<input class="field" id="ed-unit" maxlength="30" list="units" placeholder='צעדים / עמודים / ק"מ' value="${esc(d.unit ?? '')}" data-bind="ed.unit"><datalist id="units">${['צעדים', 'עמודים', 'ק"מ', 'דקות', 'שעות', 'חזרות', 'כוסות מים', 'ספרים'].map((u) => `<option value="${esc(u)}">`).join('')}</datalist>` }) : ''}</div>`
        : ''
    }
    <button type="button" class="toggle-row" role="switch" aria-checked="${d.activity === 'run'}" data-a="ed-run"><span><span class="d">מעקב ריצה</span><span class="d small mu">רישום מרחק וזמן, וחישוב קצב אוטומטי</span></span><span class="sw ${d.activity === 'run' ? 'on' : ''}"></span></button>
    ${
      !draftMore
        ? `<button type="button" class="btn ghost sm self-start" data-a="ed-more">${I.plus()} עוד אפשרויות: תתי־משימות, מטרה, תיאור, משקל</button>`
        : `<div class="stack">
        ${field({ id: 'ed-goal', label: 'קישור למטרה', input: `<select class="field" id="ed-goal" data-bind="ed.goalId">${opt('', 'ללא', d.goalId)}${goals.map((g) => opt(g.id, g.title, d.goalId)).join('')}</select>` })}
        ${d.kind !== 'one_time' ? field({ id: 'ed-deadline2', label: 'דדליין (אופציונלי)', error: e.deadline, input: `<input class="field" id="ed-deadline2" type="date" value="${esc(d.deadline ?? '')}" data-bind="ed.deadline">` }) : ''}
        ${field({ id: 'ed-w', label: 'משקל מותאם לציון (אופציונלי)', hint: 'ריק = לפי החשיבות', error: e.weightOverride, input: `<input class="field num" id="ed-w" type="number" inputmode="decimal" min="0.1" max="10" step="0.5" value="${d.weightOverride ?? ''}" data-bind="ed.weight">` })}
        <div><span class="label">תתי־משימות</span>
          <ul class="subs-edit">${d.subtasks
            .map(
              (s, i) =>
                `<li><input class="field" id="ed-sub-${s.id}" value="${esc(s.title)}" maxlength="120" aria-label="תת־משימה ${i + 1}" data-bind="ed.sub" data-id="${s.id}"><button type="button" class="icon-btn" data-a="ed-sub-del" data-id="${s.id}" aria-label="הסר תת־משימה">${I.x(16)}</button></li>`,
            )
            .join('')}</ul>
          <div class="inl gap"><input class="field grow" id="ed-sub-new" placeholder="הוסף תת־משימה" aria-label="תת־משימה חדשה" maxlength="120" data-enter="ed-sub-add" autocomplete="off"><button type="button" class="btn" data-a="ed-sub-add">הוסף</button></div>
          ${e.subtasks ? `<p class="err">${esc(e.subtasks)}</p>` : ''}</div>
        ${field({ id: 'ed-desc', label: 'תיאור', error: e.description, input: `<textarea class="field" id="ed-desc" rows="2" maxlength="2000" data-bind="ed.description">${esc(d.description)}</textarea>` })}
        ${field({ id: 'ed-notes', label: 'הערות', error: e.notes, input: `<textarea class="field" id="ed-notes" rows="2" maxlength="5000" data-bind="ed.notes">${esc(d.notes)}</textarea>` })}
      </div>`
    }
  </div>`;
}

const rerenderEditor = () => updateSheet(editorBody());
const setRec = (p: Partial<Recurrence>) => {
  const d = draft!;
  d.recurrence = { ...(d.recurrence ?? { type: 'daily', startDate: A.today }), ...p };
};
const numOrNull = (v: string) => {
  if (!v.trim()) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

segs['ed.kind'] = (v) => {
  const d = draft!;
  const kind = v as TaskKind;
  if (kind === 'one_time') Object.assign(d, { kind, recurrence: null, date: d.date ?? A.today });
  else Object.assign(d, { kind, date: null, recurrence: d.recurrence ?? { type: 'daily', startDate: A.today } });
  rerenderEditor();
};
segs['ed.recType'] = (v) => {
  const r = draft!.recurrence;
  const type = v as RecurrenceType;
  setRec({
    type,
    weekdays: type === 'weekly' ? (r?.weekdays?.length ? r.weekdays : [weekday(A.today)]) : r?.weekdays,
    interval: type === 'interval' ? (r?.interval ?? 2) : r?.interval,
    monthDay: type === 'monthly' ? (r?.monthDay ?? Number(A.today.slice(8, 10))) : r?.monthDay,
  });
  rerenderEditor();
};
actions['ed-wd'] = (el) => {
  const i = Number(el.dataset.v);
  const cur = draft!.recurrence?.weekdays ?? [];
  setRec({ weekdays: cur.includes(i) ? cur.filter((x) => x !== i) : [...cur, i].sort() });
  rerenderEditor();
};
binds['ed.title'] = (v) => (draft!.title = v);
binds['ed.date'] = (v) => (draft!.date = v || null);
binds['ed.deadline'] = (v) => (draft!.deadline = v || null);
binds['ed.interval'] = (v) => setRec({ interval: numOrNull(v) ?? undefined });
binds['ed.monthDay'] = (v) => setRec({ monthDay: numOrNull(v) ?? undefined });
binds['ed.recStart'] = (v) => setRec({ startDate: v });
binds['ed.recEnd'] = (v) => setRec({ endDate: v || null });
binds['ed.importance'] = (v) => (draft!.importance = v as Importance);
binds['ed.urgency'] = (v) => (draft!.urgency = v as Urgency);
binds['ed.categoryId'] = (v) => (draft!.categoryId = v || null);
binds['ed.est'] = (v) => {
  const n = numOrNull(v);
  draft!.estMinutes = n === null ? null : Math.round(n);
};
binds['ed.measure'] = (v) => {
  draft!.measure = v as Measure;
  rerenderEditor();
};
binds['ed.target'] = (v) => (draft!.target = numOrNull(v));
binds['ed.unit'] = (v) => (draft!.unit = v);
binds['ed.goalId'] = (v) => (draft!.goalId = v || null);
binds['ed.weight'] = (v) => (draft!.weightOverride = numOrNull(v));
binds['ed.description'] = (v) => (draft!.description = v);
binds['ed.notes'] = (v) => (draft!.notes = v);
binds['ed.sub'] = (v, el) => {
  const s = draft!.subtasks.find((x) => x.id === el.dataset.id);
  if (s) s.title = v;
};
actions['ed-run'] = () => {
  draft!.activity = draft!.activity === 'run' ? 'none' : 'run';
  rerenderEditor();
};
actions['ed-more'] = () => {
  draftMore = true;
  rerenderEditor();
};
actions['ed-sub-add'] = () => {
  const inp = $<HTMLInputElement>('#ed-sub-new');
  const t = inp?.value.trim();
  if (!t) return;
  draft!.subtasks.push({ id: uid(), title: t.slice(0, 120) });
  rerenderEditor();
  $<HTMLInputElement>('#ed-sub-new')?.focus();
};
actions['ed-sub-del'] = (el) => {
  draft!.subtasks = draft!.subtasks.filter((s) => s.id !== el.dataset.id);
  rerenderEditor();
};
actions['ed-save'] = () => {
  const d = draft!;
  const clean: Task = { ...d, title: d.title.trim(), unit: d.unit?.trim() || null, subtasks: d.subtasks.map((s) => ({ ...s, title: s.title.trim() })) };
  if (clean.measure === 'binary') {
    clean.target = null;
    clean.unit = null;
  }
  if (clean.measure === 'duration') clean.unit = 'דקות';
  if (clean.kind === 'one_time') clean.recurrence = null;
  draftErrors = validateTask(clean);
  if (Object.keys(draftErrors).length) {
    rerenderEditor();
    (document.querySelector('#sheet-body .err') as HTMLElement | null)?.scrollIntoView({ block: 'center', behavior: 'smooth' });
    return;
  }
  saveTask(clean);
  toast(draftNew ? 'המשימה נוספה' : 'המשימה עודכנה');
  closeSheet();
};
actions['ed-delete'] = () => {
  const t = draft!;
  confirmSheet({
    title: 'למחוק את המשימה?',
    body: 'המשימה תוסר מכל הימים הבאים. ציונים של ימים שכבר נסגרו נשמרים בהיסטוריה.',
    confirm: 'מחק',
    danger: true,
    onConfirm: () => {
      deleteTask(t);
      toast('המשימה נמחקה');
      closeSheet();
    },
  });
};

// ===========================================================================
// Task detail (log progress, move, cancel)
// ===========================================================================
let detail: { taskId: string; date: ISODate; moveTo: string; moveErr: string } | null = null;

export function openDetail(taskId: string, date: ISODate) {
  const t = taskById(taskId);
  if (!t) return;
  detail = { taskId, date, moveTo: '', moveErr: '' };
  const sug = suggestDate(t, date, loadForFactory(liveTasks(), logsArr()), S.settings.dailyCapacityMin);
  detail.moveTo = t.kind === 'one_time' || !isScheduledOn(t, sug.date) ? sug.date : '';
  setSheetRefresher(() => {
    if (!detail) return;
    const tt = taskById(detail.taskId);
    if (!tt) return closeSheet();
    updateSheet(detailBody());
  });
  openSheet({ title: t.title, body: detailBody() });
}

function detailBody(): string {
  const { taskId, date } = detail!;
  const t = taskById(taskId)!;
  const l = getLog(taskId, date);
  const done = isComplete(t, l);
  const cancelled = l?.status === 'not_relevant';
  const movedAway = l?.status === 'moved';
  const inactive = cancelled || movedAway;
  const chips = [
    KIND_LABEL[t.kind],
    `חשיבות ${IMPORTANCE_LABEL[t.importance]} · משקל ${fmtNum(taskWeight(t, S.settings.weights))}`,
    t.recurrence ? recurrenceText(t.recurrence) : '',
    t.estMinutes ? minutesText(t.estMinutes) : '',
    relDay(date, A.today),
  ]
    .filter(Boolean)
    .map((c) => `<span class="chip">${esc(c)}</span>`)
    .join('');

  let progress = '';
  if (!inactive) {
    if (t.activity === 'run') {
      progress = `<div class="grid2">${field({ id: 'run-d', label: 'מרחק (ק"מ)', input: `<input class="field num" id="run-d" type="number" inputmode="decimal" min="0" step="0.01" value="${l?.distanceKm ?? ''}" data-bind="run.calc">` })}
        ${field({ id: 'run-t', label: 'זמן (דקות)', input: `<input class="field num" id="run-t" type="number" inputmode="decimal" min="0" step="0.5" value="${l?.durationMin ?? ''}" data-bind="run.calc">` })}</div>
        <div class="row-between pill"><span class="mu">קצב</span><b class="num" id="run-pace">${formatPace(paceMinPerKm(l?.distanceKm ?? null, l?.durationMin ?? null))} דק׳/ק"מ</b></div>
        <button type="button" class="btn primary full" data-a="run-save">שמור ריצה</button>`;
    } else if (t.measure === 'binary') {
      progress = `<button type="button" class="btn ${done ? '' : 'primary'} full lg" data-a="d-toggle">${I.check(18)} ${done ? 'בטל סימון ביצוע' : 'סמן כבוצע'}</button>`;
    } else {
      progress = `<div class="inl gap end-align"><div class="grow">${field({
        id: 'd-val',
        label: `בוצע (${t.measure === 'duration' ? 'דקות' : (t.unit ?? '')}) · יעד ${fmtNum(t.target, 2)}`,
        input: `<input class="field num" id="d-val" type="number" inputmode="decimal" min="0" step="any" value="${l?.value ?? ''}" data-enter="d-val-save">`,
      })}</div><button type="button" class="btn primary" data-a="d-val-save">שמור</button></div>
      <p class="small mu">התקדמות: <b class="num c-ink">${Math.round(completionRatio(t, l) * 100)}%</b></p>`;
    }
    if (t.subtasks.length)
      progress += `<div>${t.subtasks
        .map((s) => {
          const on = (l?.subtaskDone ?? []).includes(s.id);
          return `<button type="button" class="sub ${on ? 'on' : ''}" role="checkbox" aria-checked="${on}" data-a="d-sub" data-id="${s.id}"><span class="bx">${on ? I.check(12) : ''}</span><span class="t">${esc(s.title)}</span></button>`;
        })
        .join('')}</div>`;
    progress += field({ id: 'd-note', label: 'הערה ליום הזה', input: `<textarea class="field" id="d-note" rows="2" maxlength="2000" placeholder="מה עבד, מה עצר אותך" data-change="d-note">${esc(l?.note ?? '')}</textarea>` });
  } else {
    progress = `<p class="pill small mu">${cancelled ? 'המשימה סומנה כלא רלוונטית ליום הזה ואינה נכללת בציון.' : `המשימה הועברה ל${esc(l?.movedTo ? relDay(l.movedTo, A.today) : '')}.`}</p>`;
  }

  let move = '';
  if (!inactive && !done) {
    const sug = suggestDate(t, date, loadForFactory(liveTasks(), logsArr()), S.settings.dailyCapacityMin);
    const after = isAfterTheFact(date, A.today, A.minutesNow, S.settings.summaryTime);
    const movable = t.kind === 'one_time' || !isScheduledOn(t, sug.date);
    if (!movable)
      move = `<p class="pill small mu">משימה שחוזרת כל יום אי אפשר להעביר ליום אחר. אם היום היא לא רלוונטית, סמן "לא רלוונטי היום" והיא לא תיספר בציון.</p>`;
    else move = `<section class="card pad stack inner"><h3 class="h3">${I.move()} העברה למועד אחר</h3>
      <p class="small mu">הצעה: ${esc(relDay(sug.date, A.today))}${sug.fits ? '. יש מקום ביום הזה.' : '. אין יום פנוי לגמרי, וזה היום הכי פחות עמוס.'}${!sug.beforeDeadline ? ' שים לב: אחרי הדדליין.' : ''}</p>
      <div class="inl gap end-align"><div class="grow">${field({
        id: 'd-move',
        label: 'תאריך יעד',
        error: detail!.moveErr,
        input: `<input class="field" id="d-move" type="date" min="${addDays(date, 1)}" value="${esc(detail!.moveTo)}" data-bind="d.moveTo">`,
      })}</div><button type="button" class="btn primary" data-a="d-move">אשר העברה</button></div>
      ${after ? '<p class="small c-warn">היום כבר עבר את שעת הסיכום, ולכן המשימה תיספר כ־0 ביום הזה.</p>' : ''}</section>`;
  }

  const bottom = `<div class="inl wrap gap">${
    cancelled
      ? '<button type="button" class="btn" data-a="d-restore">החזר ליום</button>'
      : !inactive
        ? '<button type="button" class="btn" data-a="d-nr">לא רלוונטי היום</button>'
        : ''
  }<button type="button" class="btn ghost" data-a="d-edit">${I.edit()} עריכת משימה</button></div>`;

  return `<div class="stack"><div class="chips-row">${chips}</div>${t.description ? `<p class="pre small mu">${esc(t.description)}</p>` : ''}${progress}${move}${bottom}</div>`;
}

const D = () => {
  const t = taskById(detail!.taskId)!;
  return { t, date: detail!.date };
};
actions['d-toggle'] = () => {
  const { t, date } = D();
  toggleDone(t, date, A.today);
};
actions['d-sub'] = (el) => {
  const { t, date } = D();
  toggleSubtask(t, date, el.dataset.id!, A.today);
};
actions['d-val-save'] = () => {
  const { t, date } = D();
  const v = numVal($<HTMLInputElement>('#d-val'));
  setLog(t, date, { value: v === null ? null : Math.max(0, v) }, A.today);
  toast('נשמר');
};
binds['run.calc'] = () => {
  const d = numVal($<HTMLInputElement>('#run-d'));
  const m = numVal($<HTMLInputElement>('#run-t'));
  const p = $('#run-pace');
  if (p) p.textContent = `${formatPace(paceMinPerKm(d, m))} דק׳/ק"מ`;
};
actions['run-save'] = () => {
  const { t, date } = D();
  const dist = numVal($<HTMLInputElement>('#run-d'));
  const dur = numVal($<HTMLInputElement>('#run-t'));
  if ((dist !== null && dist < 0) || (dur !== null && dur < 0)) return toast('ערכים לא תקינים', 'error');
  const patch: Parameters<typeof setLog>[2] = { distanceKm: dist, durationMin: dur };
  if (t.measure === 'binary') patch.status = dist || dur ? 'done' : 'pending';
  else patch.value = t.measure === 'duration' || (t.unit ?? '').includes('דק') ? dur : dist;
  setLog(t, date, patch, A.today);
  toast('הריצה נשמרה');
};
actions['d-nr'] = () => {
  const { t, date } = D();
  setLog(t, date, { status: 'not_relevant' }, A.today);
  toast('סומן כלא רלוונטי להיום');
};
actions['d-restore'] = () => {
  const { t, date } = D();
  setLog(t, date, { status: 'pending' }, A.today);
};
actions['d-edit'] = () => openEditor(detail!.taskId);
binds['d.moveTo'] = (v) => {
  detail!.moveTo = v;
  detail!.moveErr = '';
};
actions['d-move'] = () => {
  const { t, date } = D();
  const to = detail!.moveTo;
  let err = '';
  if (!to) err = 'יש לבחור תאריך';
  else if (to <= date) err = 'יש לבחור תאריך אחרי היום הנוכחי';
  else if (t.kind !== 'one_time' && isScheduledOn(t, to)) err = 'המשימה כבר מתוכננת בתאריך הזה';
  if (err) {
    detail!.moveErr = err;
    return updateSheet(detailBody());
  }
  applyMove(t, date, to, isAfterTheFact(date, A.today, A.minutesNow, S.settings.summaryTime), A.today);
  toast(`הועבר ל${relDay(to, A.today)}`);
  closeSheet();
};
export function saveDetailNote(value: string) {
  if (!detail) return;
  const { t, date } = D();
  if ((getLog(t.id, date)?.note ?? '') !== value) setLog(t, date, { note: value }, A.today);
}

// ===========================================================================
// Overload alternatives
// ===========================================================================
let overloadDate: ISODate = '';
let overloadPicked = new Set<string>();
export function openOverload(date: ISODate) {
  overloadDate = date;
  overloadPicked = new Set();
  setSheetRefresher(null);
  openSheet({ title: 'חלופות לעומס', body: overloadBody(), footer: overloadFoot() });
}
function overloadProposals() {
  const tasks = liveTasks();
  const logs = logsArr();
  const loadFor = loadForFactory(tasks, logs);
  return overloadAlternatives(plannedItemsForDate(tasks, logs, overloadDate), S.settings.dailyCapacityMin).map((i) => ({
    item: i,
    to: suggestDate(i.task, overloadDate, loadFor, S.settings.dailyCapacityMin).date,
  }));
}
function overloadBody() {
  const ps = overloadProposals();
  if (!ps.length) return '<p class="mu">אין משימות שאפשר להזיז בלי לפגוע בקריטי או בדדליין של היום. שקול לבטל משימה פחות חשובה.</p>';
  return `<p class="small mu">אלה המשימות הפחות חשובות, וליד כל אחת המועד הפנוי הקרוב. שום דבר לא זז בלי אישורך.</p><div class="stack-s">${ps
    .map((p) => {
      const on = overloadPicked.has(p.item.task.id);
      return `<button type="button" class="card pick ${on ? 'on' : ''}" role="checkbox" aria-checked="${on}" data-a="ov-pick" data-id="${p.item.task.id}"><span class="box ${on ? 'on' : ''}">${on ? I.check(12) : ''}</span><span class="grow"><span class="d strong">${esc(p.item.task.title)}</span><span class="d small mu">${minutesText(p.item.task.estMinutes ?? 0)} · אל ${esc(relDay(p.to, A.today))}</span></span></button>`;
    })
    .join('')}</div>`;
}
const overloadFoot = () =>
  `<button type="button" class="btn primary" data-a="ov-apply" ${overloadPicked.size ? '' : 'disabled'}>אשר העברה (${overloadPicked.size})</button><button type="button" class="btn ghost" data-a="sheet-close">סגור</button>`;
actions['ov-pick'] = (el) => {
  const id = el.dataset.id!;
  if (overloadPicked.has(id)) overloadPicked.delete(id);
  else overloadPicked.add(id);
  updateSheet(overloadBody(), overloadFoot());
};
actions['ov-apply'] = () => {
  const after = isAfterTheFact(overloadDate, A.today, A.minutesNow, S.settings.summaryTime);
  let n = 0;
  for (const p of overloadProposals()) {
    if (!overloadPicked.has(p.item.task.id)) continue;
    applyMove(p.item.task, overloadDate, p.to, after, A.today);
    n++;
  }
  toast(`הועברו ${n} משימות`);
  closeSheet();
};

// ===========================================================================
// Goal editor
// ===========================================================================
let gDraft: Goal | null = null;
let gNew = false;
let gErrors: Errors = {};
const endOfMonth = (d: ISODate) => addDays(startOfMonth(addDays(startOfMonth(d), 32)), -1);

export function openGoal(id: string | 'new') {
  if (id === 'new') {
    gDraft = newGoal(S.settings.userId, A.today, { endDate: endOfMonth(A.today) });
    gNew = true;
  } else {
    const g = liveGoals().find((x) => x.id === id);
    if (!g) return;
    gDraft = { ...g };
    gNew = false;
  }
  gErrors = {};
  setSheetRefresher(null);
  openSheet({
    title: gNew ? 'מטרה חדשה' : 'עריכת מטרה',
    body: goalBody(),
    footer: `<button type="button" class="btn primary" data-a="g-save">שמירה</button><button type="button" class="btn ghost" data-a="sheet-close">ביטול</button>${
      gNew ? '' : `<button type="button" class="btn danger ms-auto" data-a="g-delete" aria-label="מחיקת מטרה">${I.trash()}</button>`
    }`,
  });
}
function goalBody() {
  const g = gDraft!;
  const e = gErrors;
  return `<div class="stack">
    ${field({ id: 'g-title', label: 'שם המטרה', error: e.title, input: `<input class="field" id="g-title" maxlength="120" placeholder='לדוגמה: לרוץ 100 ק"מ באוקטובר' value="${esc(g.title)}" data-bind="g.title" data-autofocus autocomplete="off">` })}
    <div>${seg('g.horizon', g.horizon, (['month', 'quarter', 'year', 'custom'] as const).map((h) => [h, HORIZON_LABEL[h]]), 'טווח', true)}</div>
    <div class="grid2">${field({ id: 'g-start', label: 'התחלה', error: e.startDate, input: `<input class="field" id="g-start" type="date" value="${esc(g.startDate)}" data-bind="g.start">` })}
      ${field({ id: 'g-end', label: 'סיום', error: e.endDate, input: `<input class="field" id="g-end" type="date" value="${esc(g.endDate)}" data-bind="g.end">` })}</div>
    ${field({
      id: 'g-mode',
      label: 'מדידת התקדמות',
      input: `<select class="field" id="g-mode" data-bind="g.mode">${opt('linked_completion', 'אחוז ביצוע של המשימות המקושרות', g.progressMode)}${opt('linked_sum', 'סכום ערכים מהמשימות המקושרות', g.progressMode)}${opt('manual', 'עדכון ידני', g.progressMode)}</select>`,
    })}
    ${
      g.progressMode !== 'linked_completion'
        ? `<div class="grid2">${field({ id: 'g-target', label: 'יעד', error: e.target, input: `<input class="field num" id="g-target" type="number" inputmode="decimal" min="0" step="any" value="${g.target ?? ''}" data-bind="g.target">` })}
          ${field({ id: 'g-unit', label: 'יחידה', input: `<input class="field" id="g-unit" maxlength="30" value="${esc(g.unit ?? '')}" data-bind="g.unit">` })}</div>`
        : '<p class="small mu">את המשימות מקשרים מתוך עריכת משימה ← "קישור למטרה".</p>'
    }
    ${g.progressMode === 'manual' ? field({ id: 'g-cur', label: 'מצב נוכחי', error: e.currentValue, input: `<input class="field num" id="g-cur" type="number" inputmode="decimal" min="0" step="any" value="${g.currentValue}" data-bind="g.cur">` }) : ''}
    <div class="grid2">${field({ id: 'g-cat', label: 'קטגוריה', input: `<select class="field" id="g-cat" data-bind="g.cat">${catOptions(g.categoryId)}</select>` })}
      ${field({ id: 'g-status', label: 'סטטוס', input: `<select class="field" id="g-status" data-bind="g.status">${opt('active', 'פעילה', g.status)}${opt('done', 'הושגה', g.status)}${opt('archived', 'בארכיון', g.status)}</select>` })}</div>
    ${field({ id: 'g-desc', label: 'תיאור / למה זה חשוב', input: `<textarea class="field" id="g-desc" rows="2" maxlength="2000" data-bind="g.desc">${esc(g.description)}</textarea>` })}
  </div>`;
}
const gNum = (v: string) => numOrNull(v);
segs['g.horizon'] = (v) => {
  const g = gDraft!;
  const h = v as GoalHorizon;
  const start = g.startDate || A.today;
  const end = h === 'month' ? endOfMonth(start) : h === 'quarter' ? endOfMonth(addDays(startOfMonth(start), 62)) : h === 'year' ? `${start.slice(0, 4)}-12-31` : g.endDate;
  Object.assign(g, { horizon: h, endDate: end });
  updateSheet(goalBody());
};
binds['g.title'] = (v) => (gDraft!.title = v);
binds['g.start'] = (v) => (gDraft!.startDate = v);
binds['g.end'] = (v) => Object.assign(gDraft!, { endDate: v, horizon: 'custom' });
binds['g.mode'] = (v) => {
  gDraft!.progressMode = v as GoalProgressMode;
  updateSheet(goalBody());
};
binds['g.target'] = (v) => (gDraft!.target = gNum(v));
binds['g.unit'] = (v) => (gDraft!.unit = v || null);
binds['g.cur'] = (v) => (gDraft!.currentValue = gNum(v) ?? 0);
binds['g.cat'] = (v) => (gDraft!.categoryId = v || null);
binds['g.status'] = (v) => (gDraft!.status = v as GoalStatus);
binds['g.desc'] = (v) => (gDraft!.description = v);
actions['g-save'] = () => {
  const clean = { ...gDraft!, title: gDraft!.title.trim() };
  gErrors = validateGoal(clean);
  if (Object.keys(gErrors).length) return updateSheet(goalBody());
  saveGoal(clean);
  toast('נשמר');
  closeSheet();
};
actions['g-delete'] = () => {
  const g = gDraft!;
  confirmSheet({
    title: 'למחוק את המטרה?',
    body: 'המשימות המקושרות יישארו, ורק הקישור יוסר.',
    confirm: 'מחק',
    danger: true,
    onConfirm: () => {
      deleteGoal(g);
      closeSheet();
    },
  });
};

// ===========================================================================
// Onboarding (first run)
// ===========================================================================
export function openOnboarding() {
  const s = S.settings;
  setSheetRefresher(null);
  openSheet({
    title: 'שלושה דברים לפני שמתחילים',
    body: `<form class="stack" data-submit="onboard" novalidate><p class="mu">את הכול אפשר לשנות אחר כך בהגדרות.</p>
      ${field({ id: 'ob-time', label: 'באיזו שעה תסגור את היום?', hint: 'בשעה הזו יופיע הסיכום היומי', input: `<input class="field" id="ob-time" type="time" value="${esc(s.summaryTime)}">` })}
      ${field({ id: 'ob-cap', label: 'כמה שעות עבודה אמיתיות יש לך ביום?', hint: 'משמש לזיהוי עומס יתר. 0 = ללא בדיקה', input: `<input class="field num" id="ob-cap" type="number" inputmode="decimal" min="0" max="24" step="0.5" value="${s.dailyCapacityMin / 60}">` })}
      ${field({ id: 'ob-thr', label: 'מאיזה ציון יום נחשב מוצלח?', hint: 'ימים מעל הסף נספרים ברצף', input: `<input class="field num" id="ob-thr" type="number" inputmode="numeric" min="0" max="100" value="${s.streakThreshold}">` })}
      <p class="err" id="ob-err" role="alert" hidden></p><button type="submit" hidden></button></form>`,
    footer: '<button type="button" class="btn primary" data-a="ob-done">מתחילים</button>',
    onClose: () => {
      if (!S.settings.onboarded) saveSettings({ ...S.settings, onboarded: true });
    },
  });
}
function finishOnboarding() {
  const cap = numVal($<HTMLInputElement>('#ob-cap'));
  const thr = numVal($<HTMLInputElement>('#ob-thr'));
  const next = {
    ...S.settings,
    summaryTime: $<HTMLInputElement>('#ob-time')?.value ?? S.settings.summaryTime,
    dailyCapacityMin: Math.round((cap ?? 0) * 60),
    streakThreshold: thr ?? 70,
    onboarded: true,
  };
  const e = validateSettings(next);
  if (Object.keys(e).length) {
    const el = $('#ob-err')!;
    el.textContent = Object.values(e)[0] ?? 'בדוק את הערכים';
    el.hidden = false;
    return;
  }
  saveSettings(next);
  closeSheet();
}
actions['ob-done'] = finishOnboarding;
submits['onboard'] = finishOnboarding;

