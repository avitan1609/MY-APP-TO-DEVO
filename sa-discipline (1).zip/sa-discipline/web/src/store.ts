/**
 * Local-first store for the static build: everything lives in memory and is
 * written through to IndexedDB. Mirrors src/data/repo.ts semantics so the
 * React/Supabase build and this build behave the same.
 */
import { makeBackup, reownBackup, type BackupData, type BackupFile } from '../../src/core/backup';
import { addDays } from '../../src/core/dates';
import { defaultCategories, defaultSettings, newDayEntry, newLog } from '../../src/core/factories';
import { planMove } from '../../src/core/planning';
import { logId, plannedItemsForDate } from '../../src/core/recurrence';
import { computeDailyScore } from '../../src/core/score';
import type { Category, DayEntry, Goal, ISODate, Settings, Task, TaskLog } from '../../src/core/types';

export const USER = 'local';
const DB_NAME = 'sa-discipline';
const STORES = ['tasks', 'logs', 'goals', 'categories', 'days', 'settings', 'meta'] as const;
type StoreName = (typeof STORES)[number];

export const S = {
  tasks: [] as Task[],
  logs: new Map<string, TaskLog>(),
  goals: [] as Goal[],
  categories: [] as Category[],
  days: new Map<ISODate, DayEntry>(),
  settings: defaultSettings(USER, 'Asia/Jerusalem'),
  meta: new Map<string, unknown>(),
  persistent: true,
};

let db: IDBDatabase | null = null;
let onChange: () => void = () => {};
let onError: (msg: string) => void = () => {};
export function bindStore(change: () => void, error: (msg: string) => void) {
  onChange = change;
  onError = error;
}
const changed = () => {
  logsCache = null;
  onChange();
};
const now = () => new Date().toISOString();

// ---------------------------------------------------------------------------
// IndexedDB plumbing
// ---------------------------------------------------------------------------
function openIDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const d = req.result;
      for (const s of STORES) if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: s === 'meta' ? 'key' : 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
    req.onblocked = () => reject(new Error('blocked'));
  });
}

function getAll<T>(store: StoreName): Promise<T[]> {
  return new Promise((resolve, reject) => {
    const req = db!.transaction(store).objectStore(store).getAll();
    req.onsuccess = () => resolve(req.result as T[]);
    req.onerror = () => reject(req.error);
  });
}

function put(store: StoreName, value: unknown) {
  if (!db) return;
  try {
    const tx = db.transaction(store, 'readwrite');
    tx.objectStore(store).put(value);
    tx.onerror = () => onError('השמירה במכשיר נכשלה. בדוק שיש מקום פנוי בדפדפן.');
  } catch {
    onError('השמירה במכשיר נכשלה.');
  }
}

function putMany(store: StoreName, values: unknown[]): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!db || !values.length) return resolve();
    const tx = db.transaction(store, 'readwrite');
    const os = tx.objectStore(store);
    for (const v of values) os.put(v);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function initStore(timezone: string): Promise<void> {
  try {
    db = await openIDB();
    const [tasks, logs, goals, cats, days, settings, meta] = await Promise.all([
      getAll<Task>('tasks'),
      getAll<TaskLog>('logs'),
      getAll<Goal>('goals'),
      getAll<Category>('categories'),
      getAll<DayEntry>('days'),
      getAll<Settings>('settings'),
      getAll<{ key: string; value: unknown }>('meta'),
    ]);
    S.tasks = tasks;
    S.logs = new Map(logs.map((l) => [l.id, l]));
    S.goals = goals;
    S.categories = cats;
    S.days = new Map(days.map((d) => [d.date, d]));
    S.meta = new Map(meta.map((m) => [m.key, m.value]));
    if (settings[0]) S.settings = { ...defaultSettings(USER, timezone), ...settings[0] };
    else {
      S.settings = defaultSettings(USER, timezone);
      put('settings', S.settings);
    }
    if (!S.categories.length) {
      S.categories = defaultCategories(USER);
      await putMany('categories', S.categories);
    }
  } catch {
    // Private mode or storage disabled: run in memory for this session.
    S.persistent = false;
    db = null;
    S.settings = defaultSettings(USER, timezone);
    S.categories = defaultCategories(USER);
  }
  try {
    await navigator.storage?.persist?.();
  } catch {
    /* best effort */
  }
}

// ---------------------------------------------------------------------------
// Reads
// ---------------------------------------------------------------------------
let logsCache: TaskLog[] | null = null;
export function logsArr(): TaskLog[] {
  if (!logsCache) logsCache = [...S.logs.values()].filter((l) => !l.deleted);
  return logsCache;
}
export const liveTasks = () => S.tasks.filter((t) => !t.deleted);
export const liveGoals = () => S.goals.filter((g) => !g.deleted);
export const liveCategories = (withArchived = false) =>
  S.categories.filter((c) => !c.deleted && (withArchived || !c.archived)).sort((a, b) => a.sortOrder - b.sortOrder);
export const taskById = (id: string) => S.tasks.find((t) => t.id === id && !t.deleted);
export const categoryById = (id: string | null) => (id ? S.categories.find((c) => c.id === id) : undefined);
export function snapshotMap(): Map<ISODate, number | null> {
  const m = new Map<ISODate, number | null>();
  for (const d of S.days.values()) if (!d.deleted && d.scoreSnapshot) m.set(d.date, d.scoreSnapshot.score);
  return m;
}
export const dayEntry = (date: ISODate): DayEntry => {
  const d = S.days.get(date);
  return d && !d.deleted ? d : newDayEntry(USER, date);
};

// ---------------------------------------------------------------------------
// Writes
// ---------------------------------------------------------------------------
function upsert<T extends { id: string }>(arr: T[], row: T) {
  const i = arr.findIndex((x) => x.id === row.id);
  if (i >= 0) arr[i] = row;
  else arr.push(row);
}

export function saveTask(t: Task) {
  const row = { ...t, updatedAt: now() };
  upsert(S.tasks, row);
  put('tasks', row);
  changed();
}
export function deleteTask(t: Task) {
  saveTask({ ...t, deleted: true });
}
export function saveGoal(g: Goal) {
  const row = { ...g, updatedAt: now() };
  upsert(S.goals, row);
  put('goals', row);
  changed();
}
export function deleteGoal(g: Goal) {
  for (const t of S.tasks.filter((x) => x.goalId === g.id)) {
    const row = { ...t, goalId: null, updatedAt: now() };
    upsert(S.tasks, row);
    put('tasks', row);
  }
  saveGoal({ ...g, deleted: true });
}
export function saveCategory(c: Category) {
  const row = { ...c, updatedAt: now() };
  upsert(S.categories, row);
  put('categories', row);
  changed();
}
export function saveSettings(s: Settings) {
  S.settings = { ...s, id: 'settings', updatedAt: now() };
  put('settings', S.settings);
  changed();
}
export function saveDay(d: DayEntry) {
  const row = { ...d, updatedAt: now() };
  S.days.set(row.date, row);
  put('days', row);
  changed();
}
export function setMeta(key: string, value: unknown) {
  S.meta.set(key, value);
  put('meta', { key, value });
}

export function statusForValue(task: Task, value: number | null): TaskLog['status'] {
  if (value === null || value <= 0) return 'pending';
  if (task.target && value >= task.target) return 'done';
  return 'partial';
}

function writeLog(task: Task, date: ISODate, patch: Partial<TaskLog>): TaskLog {
  const id = logId(task.id, date);
  const ex = S.logs.get(id);
  const base = ex && !ex.deleted ? ex : newLog(USER, task.id, date);
  const next: TaskLog = { ...base, ...patch, id, taskId: task.id, date, deleted: false, updatedAt: now() };
  if (task.measure !== 'binary' && 'value' in patch && !('status' in patch)) next.status = statusForValue(task, next.value);
  S.logs.set(id, next);
  logsCache = null;
  put('logs', next);
  return next;
}

export function setLog(task: Task, date: ISODate, patch: Partial<TaskLog>, today: ISODate): TaskLog {
  const next = writeLog(task, date, patch);
  if (date < today && S.days.get(date)?.scoreSnapshot) snapshotDay(date);
  changed();
  return next;
}

export function getLog(taskId: string, date: ISODate): TaskLog | null {
  const l = S.logs.get(logId(taskId, date));
  return l && !l.deleted ? l : null;
}

export function toggleDone(task: Task, date: ISODate, today: ISODate) {
  const l = getLog(task.id, date);
  return setLog(task, date, { status: l?.status === 'done' ? 'pending' : 'done' }, today);
}

export function toggleSubtask(task: Task, date: ISODate, subId: string, today: ISODate) {
  const l = getLog(task.id, date);
  const done = new Set(l?.subtaskDone ?? []);
  if (done.has(subId)) done.delete(subId);
  else done.add(subId);
  const all = task.subtasks.length > 0 && task.subtasks.every((s) => done.has(s.id));
  const patch: Partial<TaskLog> = { subtaskDone: [...done] };
  if (task.measure === 'binary') {
    if (all) patch.status = 'done';
    else if (l?.status === 'done') patch.status = 'pending';
  }
  return setLog(task, date, patch, today);
}

export function applyMove(task: Task, from: ISODate, to: ISODate, afterTheFact: boolean, today: ISODate) {
  const plan = planMove(task, from, to, afterTheFact);
  if (plan.taskPatch) {
    const row = { ...task, ...plan.taskPatch, updatedAt: now() };
    upsert(S.tasks, row);
    put('tasks', row);
  }
  for (const l of plan.logs) {
    const { id: _id, taskId: _t, date, ...patch } = l;
    void _id;
    void _t;
    writeLog(task, date, { ...patch, deleted: false });
  }
  if (from < today && S.days.get(from)?.scoreSnapshot) snapshotDay(from);
  changed();
}

/** Freeze the score of a day (with full breakdown and formula version). */
export function snapshotDay(date: ISODate, markSummary = false): DayEntry {
  const snap = computeDailyScore(plannedItemsForDate(liveTasks(), logsArr(), date), S.settings.weights);
  const d = dayEntry(date);
  const row: DayEntry = { ...d, scoreSnapshot: snap, summaryGeneratedAt: markSummary ? now() : d.summaryGeneratedAt, updatedAt: now() };
  S.days.set(date, row);
  put('days', row);
  return row;
}

/** Freeze scores for past days that have none yet (up to 60 days back). */
export function finalizePastDays(today: ISODate) {
  const last = (S.meta.get('finalizedThrough') as ISODate | undefined) ?? addDays(today, -1);
  let from = addDays(last, 1);
  const floor = addDays(today, -60);
  if (from < floor) from = floor;
  let any = false;
  for (let d = from; d < today; d = addDays(d, 1)) {
    if (!S.days.get(d)?.scoreSnapshot) {
      snapshotDay(d);
      any = true;
    }
  }
  setMeta('finalizedThrough', addDays(today, -1));
  if (any) changed();
}

// ---------------------------------------------------------------------------
// Backup
// ---------------------------------------------------------------------------
export function exportAll(): BackupFile {
  const live = <T extends { deleted: boolean }>(rows: T[]) => rows.filter((r) => !r.deleted);
  return makeBackup({
    categories: live(S.categories),
    goals: live(S.goals),
    tasks: live(S.tasks),
    logs: live([...S.logs.values()]),
    days: live([...S.days.values()]),
    settings: S.settings,
  });
}

export async function importAll(data: BackupData) {
  const b = reownBackup(data, USER);
  for (const r of b.categories) upsert(S.categories, r);
  for (const r of b.goals) upsert(S.goals, r);
  for (const r of b.tasks) upsert(S.tasks, r);
  for (const r of b.logs) S.logs.set(r.id, r);
  for (const r of b.days) S.days.set(r.date, r);
  if (b.settings) S.settings = { ...S.settings, ...b.settings };
  await Promise.all([
    putMany('categories', b.categories),
    putMany('goals', b.goals),
    putMany('tasks', b.tasks),
    putMany('logs', b.logs),
    putMany('days', b.days),
    putMany('settings', [S.settings]),
  ]);
  changed();
}

export async function wipeAll() {
  if (db) {
    db.close();
    db = null;
  }
  await new Promise<void>((resolve) => {
    const req = indexedDB.deleteDatabase(DB_NAME);
    req.onsuccess = req.onerror = req.onblocked = () => resolve();
  });
  try {
    localStorage.removeItem('sa-theme');
  } catch {
    /* ignore */
  }
}
