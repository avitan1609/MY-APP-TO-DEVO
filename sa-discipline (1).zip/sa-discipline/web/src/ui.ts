/** DOM helpers, icons and small components rendered as HTML strings. */

export const $ = <T extends HTMLElement = HTMLElement>(sel: string, root: ParentNode = document) => root.querySelector<T>(sel);
export const $$ = <T extends HTMLElement = HTMLElement>(sel: string, root: ParentNode = document) => [...root.querySelectorAll<T>(sel)];

export function esc(s: unknown): string {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);
}

/** `cls('a', cond && 'b')` */
export const cls = (...c: Array<string | false | null | undefined>) => c.filter(Boolean).join(' ');

// ---------------------------------------------------------------------------
// Icons (24px grid, currentColor)
// ---------------------------------------------------------------------------
const svg = (d: string, s: number, extra = '') =>
  `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" ${extra}>${d}</svg>`;

export const I = {
  today: (s = 20) => svg('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>', s),
  week: (s = 20) => svg('<rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>', s),
  list: (s = 20) => svg('<path d="M9 6.5h11M9 12h11M9 17.5h11"/><path d="M4 6.5h.01M4 12h.01M4 17.5h.01" stroke-width="2.6"/>', s),
  target: (s = 20) => svg('<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r=".8" fill="currentColor"/>', s),
  chart: (s = 20) => svg('<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>', s),
  summary: (s = 20) => svg('<path d="M6 3.5h9l3.5 3.5v13.5H6z"/><path d="M9 11h6M9 15h6M14.5 3.5V7H18"/>', s),
  settings: (s = 20) => svg('<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>', s),
  check: (s = 16) => svg('<path d="M5 12.5l4.5 4.5L19 7.5"/>', s, 'stroke-width="2.8"'),
  flag: (s = 14) => svg('<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>', s),
  clock: (s = 13) => svg('<circle cx="12" cy="12" r="8.5"/><path d="M12 8v4.5l2.5 1.5"/>', s),
  flame: (s = 15) => svg('<path d="M12 21c4 0 6.5-2.6 6.5-6.2 0-4.3-4-6.3-4.5-10.8-2.5 1.6-4 4-4 6.6-1-.6-1.6-1.6-1.8-2.8C6.5 9.6 5.5 11.8 5.5 14.8 5.5 18.4 8 21 12 21z"/>', s),
  run: (s = 15) => svg('<circle cx="14.5" cy="4.5" r="1.8"/><path d="M8 21l3-6 3 2.5V21M6.5 11.5l3-3.5 4 1 2.5 3 3 .5M11 15l-1.5-4"/>', s),
  x: (s = 20) => svg('<path d="M6 6l12 12M18 6L6 18"/>', s),
  alert: (s = 18) => svg('<path d="M12 3.5L2.5 20h19z"/><path d="M12 10v4.5M12 17.5h.01"/>', s),
  plus: (s = 16) => svg('<path d="M12 5v14M5 12h14"/>', s),
  /** RTL: "previous" points right, "next" points left. */
  prev: (s = 20) => svg('<path d="M9 6l6 6-6 6"/>', s),
  next: (s = 20) => svg('<path d="M15 6l-6 6 6 6"/>', s),
  move: (s = 16) => svg('<path d="M20 12H7M11 7l-5 5 5 5"/>', s),
  edit: (s = 16) => svg('<path d="M4 20h4L19 9l-4-4L4 16z"/>', s),
  trash: (s = 16) => svg('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>', s),
  search: (s = 17) => svg('<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>', s),
  device: (s = 16) => svg('<rect x="6" y="2.5" width="12" height="19" rx="2.5"/><path d="M11 18.5h2"/>', s),
};

// ---------------------------------------------------------------------------
// Components
// ---------------------------------------------------------------------------
export function ring(score: number | null, size = 116, label = 'ציון יומי'): string {
  const st = 9;
  const r = (size - st) / 2;
  const c = 2 * Math.PI * r;
  const p = score === null ? 0 : Math.max(0, Math.min(100, score)) / 100;
  return `<div class="ring" style="width:${size}px;height:${size}px" role="img" aria-label="${label}: ${score === null ? 'אין נתונים' : Math.round(score)}">
    <svg width="${size}" height="${size}" aria-hidden="true"><circle class="ring-track" cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke-width="${st}"/>
    <circle class="ring-fill" cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke-width="${st}" stroke-linecap="round" stroke-dasharray="${c.toFixed(2)}" stroke-dashoffset="${(c * (1 - p)).toFixed(2)}"/></svg>
    <div class="c"><b class="num" style="font-size:${Math.round(size * 0.3)}px">${score === null ? '—' : Math.round(score)}</b><span>${label}</span></div></div>`;
}

export function miniRing(ratio: number, done: boolean): string {
  const c = 75.4;
  return `<span class="mini-ring" aria-hidden="true"><svg viewBox="0 0 28 28" width="28" height="28"><circle class="ring-track" cx="14" cy="14" r="12" fill="none" stroke-width="3"/><circle class="ring-fill" cx="14" cy="14" r="12" fill="none" stroke-width="3" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${(c * (1 - Math.min(1, ratio))).toFixed(2)}"/></svg>${done ? `<span class="mini-check">${I.check(13)}</span>` : ''}</span>`;
}

export function bar(v: number, max: number, tone: '' | 'danger' | 'warn' = ''): string {
  const pct = max > 0 ? Math.max(0, Math.min(100, (100 * v) / max)) : 0;
  return `<div class="bar ${tone}" role="progressbar" aria-valuenow="${Math.round(pct)}" aria-valuemin="0" aria-valuemax="100"><i style="width:${pct}%"></i></div>`;
}

export function seg(name: string, value: string, options: Array<[string, string]>, label?: string, small = false): string {
  return `${label ? `<span class="label">${esc(label)}</span>` : ''}<div class="seg ${small ? 'sm' : ''}" role="radiogroup" ${label ? `aria-label="${esc(label)}"` : ''}>${options
    .map(([v, l]) => `<button type="button" role="radio" aria-checked="${v === value}" data-a="seg" data-seg="${name}" data-v="${esc(v)}">${esc(l)}</button>`)
    .join('')}</div>`;
}

export function field(opts: { id: string; label: string; error?: string; hint?: string; input: string }): string {
  return `<div class="fld"><label class="label" for="${opts.id}">${esc(opts.label)}</label>${opts.input}${
    opts.error ? `<p class="err" role="alert">${esc(opts.error)}</p>` : opts.hint ? `<p class="hint">${esc(opts.hint)}</p>` : ''
  }</div>`;
}

export const numVal = (el: HTMLInputElement | null): number | null => {
  if (!el) return null;
  const raw = el.value.trim();
  if (!raw) return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
};

export function stat(label: string, value: string | number, sub?: string): string {
  return `<div class="card stat"><div class="k">${esc(label)}</div><div class="v num">${esc(value)}</div>${sub ? `<div class="s">${esc(sub)}</div>` : ''}</div>`;
}

export function toast(msg: string, tone: 'ok' | 'error' = 'ok') {
  const el = document.createElement('div');
  el.className = `toast ${tone}`;
  el.setAttribute('role', 'status');
  el.textContent = msg;
  $('#toasts')!.appendChild(el);
  setTimeout(() => el.remove(), 2800);
}

// ---------------------------------------------------------------------------
// Sheet (bottom sheet on phones, dialog on desktop)
// ---------------------------------------------------------------------------
let sheetOnClose: (() => void) | null = null;
let sheetReturnFocus: HTMLElement | null = null;
export const sheetIsOpen = () => !!$('#layer')?.firstElementChild;

export function openSheet(o: { title: string; body: string; footer?: string; wide?: boolean; onClose?: () => void }) {
  const layer = $('#layer')!;
  if (!sheetIsOpen()) sheetReturnFocus = document.activeElement as HTMLElement | null;
  sheetOnClose = o.onClose ?? null;
  layer.innerHTML = `<div class="scrim" data-scrim><div class="sheet ${o.wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-labelledby="sheet-title">
    <header><h2 id="sheet-title">${esc(o.title)}</h2><button type="button" class="icon-btn" data-a="sheet-close" aria-label="סגירה">${I.x()}</button></header>
    <div class="sb" id="sheet-body">${o.body}</div>${o.footer ? `<footer id="sheet-foot">${o.footer}</footer>` : ''}</div></div>`;
  document.body.classList.add('locked');
  setTimeout(() => {
    const target = $('#layer [data-autofocus]') ?? $('#sheet-body input, #sheet-body textarea, #sheet-body select, #sheet-body button') ?? $('#layer button');
    (target as HTMLElement | null)?.focus();
  }, 30);
}

/** Re-render the body/footer of the open sheet, keeping focus and caret where they were. */
export function updateSheet(body?: string, footer?: string) {
  if (!$('#sheet-body')) return;
  keepFocus(() => {
    if (body !== undefined) $('#sheet-body')!.innerHTML = body;
    if (footer !== undefined && $('#sheet-foot')) $('#sheet-foot')!.innerHTML = footer;
  });
}

export function closeSheet() {
  if (!sheetIsOpen()) return;
  $('#layer')!.innerHTML = '';
  document.body.classList.remove('locked');
  const cb = sheetOnClose;
  sheetOnClose = null;
  cb?.();
  sheetReturnFocus?.focus?.();
  sheetReturnFocus = null;
}

/** Run a DOM replacement and restore focus/caret to the element with the same id. */
export function keepFocus(fn: () => void) {
  const a = document.activeElement as HTMLInputElement | null;
  const id = a?.id;
  let start: number | null = null;
  let end: number | null = null;
  try {
    start = a?.selectionStart ?? null;
    end = a?.selectionEnd ?? null;
  } catch {
    /* not a text input */
  }
  fn();
  if (id) {
    const el = document.getElementById(id) as HTMLInputElement | null;
    if (el && el !== document.activeElement) {
      el.focus({ preventScroll: true });
      try {
        if (start !== null && end !== null) el.setSelectionRange(start, end);
      } catch {
        /* not a text input */
      }
    }
  }
}

/** Keyboard: Escape closes, Tab stays inside the sheet. */
export function sheetKeys(e: KeyboardEvent) {
  if (!sheetIsOpen()) return false;
  if (e.key === 'Escape') {
    closeSheet();
    return true;
  }
  if (e.key === 'Tab') {
    const f = $$('#layer button:not([disabled]), #layer input, #layer select, #layer textarea, #layer [href]');
    if (!f.length) return false;
    const first = f[0];
    const last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }
  return false;
}

export function confirmSheet(o: { title: string; body: string; confirm: string; danger?: boolean; onConfirm: () => void | Promise<void>; extraInput?: string }) {
  pendingConfirm = o.onConfirm;
  openSheet({
    title: o.title,
    body: `<div class="muted-text">${o.body}</div>${o.extraInput ?? ''}`,
    footer: `<button type="button" class="btn ${o.danger ? 'danger' : 'primary'}" data-a="confirm-ok">${esc(o.confirm)}</button><button type="button" class="btn ghost" data-a="sheet-close">ביטול</button>`,
  });
}
export let pendingConfirm: (() => void | Promise<void>) | null = null;
export function takeConfirm() {
  const f = pendingConfirm;
  pendingConfirm = null;
  return f;
}

/** Trigger a file download (works on a real site; blocked only inside sandboxed previews). */
export function download(name: string, content: string, type: string) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
